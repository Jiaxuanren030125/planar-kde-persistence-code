"""Write FREEZE.json for a run directory (preflight_v2).  It never writes AUTHORIZATION.json: that file is written only after an explicit coordinator
instruction naming the hash of this freeze, so preparing a freeze starts nothing.

Task 57, R3.1.

The freeze binds: every engine and script file the run, the verification and the analysis execute, the design, the preregistration, the analysis
plan, the numerical policy, the figure captions, the environment lock and requirements.lock (release.FROZEN_FILES), plus the environment lock's
content and the expected identity counts.  It also stores the exact commands of the sequence.  --fixture-only writes a freeze stamped
FIXTURE_ONLY, for engineering tests; the runner refuses to start a formal run from it.
"""
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from tda_numerics import release as rl  # noqa: E402


def commands(design_path, run_dir, fixture_only=False):
    py = '"$PY"'
    d, r = '"%s"' % design_path, '"%s"' % run_dir
    if fixture_only:
        head = ["# FIXTURE_ONLY engineering run: no authorization, deterministic lattice rows, never results",
                "%s scripts/run_candidate.py --design %s --run-dir %s --fixture --workers 4" % (py, d, r)]
    else:
        head = ["# 1 freeze (done when this file exists): %s scripts/make_freeze.py --design %s --run-dir %s" % (py, d, r),
                "# 2 coordinator only: write %s/AUTHORIZATION.json = {\"freeze_sha256\": <sha256 of FREEZE.json>, \"formal_run_authorized\": true}" % r,
                "%s scripts/run_candidate.py --design %s --run-dir %s --formal --workers 4" % (py, d, r)]
    return ["cd \"%s\"" % ROOT,
            "export PYTHONDONTWRITEBYTECODE=1 VECLIB_MAXIMUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1"] + head + [
            "%s scripts/verify_run.py --run-dir %s" % (py, r),
            "%s scripts/analyze_candidate.py --run-dir %s --figures" % (py, r),
            "%s scripts/verify_run.py --run-dir %s --write" % (py, r),
            "%s scripts/verify_run.py --run-dir %s --check" % (py, r)]


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--design", required=True, type=Path)
    ap.add_argument("--run-dir", required=True, type=Path)
    ap.add_argument("--fixture-only", action="store_true", help="engineering tests only; the freeze is stamped FIXTURE_ONLY and cannot start a formal run")
    a = ap.parse_args(argv)
    a.run_dir.mkdir(parents=True, exist_ok=True)
    fz = a.run_dir / "FREEZE.json"
    if fz.exists():
        print("REFUSED: FREEZE.json already exists; a freeze is never overwritten", file=sys.stderr)
        return 3
    design = json.loads(a.design.read_text())
    if rl.digest(design) != rl.digest(json.loads((ROOT / "candidate/DESIGN_CANDIDATE.json").read_text())) and not a.fixture_only:
        print("REFUSED: a formal freeze uses candidate/DESIGN_CANDIDATE.json", file=sys.stderr)
        return 3
    lock = rl.load_env_lock()
    mism = rl.env_mismatches(lock, rl.env_probe())
    if mism:
        print("REFUSED: environment differs from ENV_LOCK.json: " + "; ".join(mism), file=sys.stderr)
        return 3
    jobs = rl.expected_jobs(design)
    body = dict(schema=rl.FREEZE_SCHEMA, written_utc=rl.utc(), external_timestamp=False, fixture_only=bool(a.fixture_only),
                stamp="FIXTURE_ONLY: engineering test object, never a formal freeze" if a.fixture_only else "candidate freeze; runs only with a coordinator AUTHORIZATION.json naming its hash",
                frozen_files=rl.frozen_hashes(), design=design, design_sha256=rl.digest(design), env_lock=lock, env_lock_sha256=rl.digest(lock),
                row_schema=rl.ROW_SCHEMA, block_schema=rl.BLOCK_SCHEMA, numeric_scope=rl.NUMERIC_SCOPE,
                expected=dict(blocks=len(jobs), identities=sum(c["reps"] for c in design["cells"]), cells=len(design["cells"])),
                commands=commands(a.design, a.run_dir, a.fixture_only))
    fz.write_text(json.dumps(body, indent=1, ensure_ascii=False))
    print("FREEZE sha256", rl.sha(fz))
    print("\n".join(body["commands"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
