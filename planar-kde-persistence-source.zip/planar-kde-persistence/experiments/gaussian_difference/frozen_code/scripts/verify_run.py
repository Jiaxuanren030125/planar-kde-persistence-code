"""Overall status of a run directory from the evidence actually present: INVALID, PENDING or VALID (release.verify_run).

Task 57, R2.2-R2.4.

  verify_run.py --run-dir RUN            print the status; writes nothing
  verify_run.py --run-dir RUN --write    write RUN/release_status.json (takes the single-writer lock)
  verify_run.py --run-dir RUN --check    recompute and compare with the stored release_status.json; any changed binding fails (exit 5)

Exit codes: 0 VALID, 1 PENDING, 2 INVALID, 3 refused (environment differs from the lock, or another writer holds the lock), 5 --check failed.
"""
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from tda_numerics import release as rl  # noqa: E402

CODES = dict(VALID=0, PENDING=1, INVALID=2)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", required=True, type=Path)
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--write", action="store_true")
    g.add_argument("--check", action="store_true")
    a = ap.parse_args(argv)
    freeze, _, _ = rl.read_freeze(a.run_dir)
    if freeze is not None:
        mism = rl.env_mismatches(freeze["env_lock"], rl.env_probe())
        if mism:
            print("REFUSED: environment differs from the frozen lock: " + "; ".join(mism), file=sys.stderr)
            return 3
    res = rl.verify_run(a.run_dir)
    if a.check:
        diffs = rl.compare_with_stored(a.run_dir, res)
        print(json.dumps(dict(status=res["status"], check_differences=diffs, reasons_invalid=res["reasons_invalid"], reasons_pending=res["reasons_pending"]), indent=1, ensure_ascii=False))
        return 5 if (diffs or res["status"] != "VALID") else 0
    if a.write:
        try:
            with rl.RunLock(a.run_dir, "verifier"):
                (a.run_dir / "release_status.json").write_text(json.dumps(res, indent=1, ensure_ascii=False))
        except rl.Refusal as why:
            print("REFUSED:", why, file=sys.stderr)
            return 3
    print(json.dumps({k: res.get(k) for k in ("status", "fixture_only", "formal_release", "reasons_invalid", "reasons_pending", "notes", "blocks", "rows")}, indent=1, ensure_ascii=False))
    return CODES[res["status"]]


if __name__ == "__main__":
    sys.exit(main())
