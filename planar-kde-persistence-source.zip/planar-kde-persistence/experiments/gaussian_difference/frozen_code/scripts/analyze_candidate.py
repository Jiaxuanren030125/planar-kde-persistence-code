"""Candidate analysis for the two predeclared displays (preflight_v2).

Task 57, R1.2, R2 and R4.

Every primary display reads one statistic, rescaled_L_primary (the noise-filtered PL6 bar of the row), and its row budget
numerical_budget.rescaled.B_total, an empirical/conditional numerical budget.  The search value L_polished_diagnostic and the floating-point
minimum_diagnostic appear only in the diagnostic section; they never enter a primary count, CDF, error or figure.

Display 1: the rate of rescaled_L_primary > tau with the limit Pr(Psi_s(G) > tau); tau = 0.05 is the main curve, all six thresholds are reported;
the CDF of rescaled_L_primary against the limit CDF.
Display 2: same-sample errors of the leading Psi_s(G_n) and the full-matrix quartic L(Qtilde_n) against rescaled_L_primary; three auxiliary
comparisons in the tables only.  Correlation is secondary.

Denominators.  Every cell has its planned number of rows.  A row with no primary value (error row, or missing in a preview) is unknown: it is never
counted as "no bar".  Paired comparisons use one common finite mask per comparator and report m_used and m_missing; every 2x2 table sums to m_used.
Exact Clopper-Pearson intervals are attached only to named binomial indicators.  The threshold envelope [k_certain, k_possible] uses the empirical
budget and is a sensitivity range, not a confidence interval for a continuous probability.

  analyze_candidate.py --run-dir RUN [--figures]             final analysis; refused unless verify_run finds every block present and legal
  analyze_candidate.py --run-dir RUN --preview [--figures]   PENDING engineering preview into RUN/analysis_preview, stamped, never a result
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

import numpy as np  # noqa: E402
from scipy.stats import beta as beta_dist  # noqa: E402

from tda_numerics import release as rl  # noqa: E402
from tda_numerics.model import Model  # noqa: E402

# Predeclared; fixed before any target-experiment result exists.
THRESHOLDS = (0.005, 0.01, 0.02, 0.05, 0.1, 0.2)
MAIN_TAU = 0.05
QUANTILES = (0.1, 0.25, 0.5, 0.75, 0.9)
ERROR_QUANTILES = (0.5, 0.9, 0.95)
CUSP_STRATA = ((0.0, 0.5), (0.5, 0.9), (0.9, 1.1), (1.1, float("inf")))
COMPARATORS_PRIMARY = ("Psi_leading", "L_Qtilde")
COMPARATORS_AUXILIARY = ("L_Qcentered", "L_Qbeta", "L_Qtrace")
MIN_CATEGORIES = ("MIN_FOUND_FLOAT", "NO_MIN_FOUND_FLOAT", "UNDETERMINED_FLOAT", "NOT_RUN", "ERROR", "MISSING")
ANALYSIS_FILES = ("scripts/analyze_candidate.py", "src/tda_numerics/release.py", "src/tda_numerics/model.py")
EXIT_REFUSED = 3


def cp_interval(k, m, level=0.95):
    """Clopper-Pearson; endpoints 0 and 1 at k=0 and k=m; None when m=0."""
    if m == 0:
        return [None, None]
    a = 1.0 - level
    lo = 0.0 if k == 0 else float(beta_dist.ppf(a / 2.0, k, m - k + 1))
    hi = 1.0 if k == m else float(beta_dist.ppf(1.0 - a / 2.0, k + 1, m - k))
    return [lo, hi]


def _finite(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def primary_of(r):
    return float(r["rescaled_L_primary"]) if r.get("status") == "ok" and _finite(r.get("rescaled_L_primary")) else np.nan


def budget_of(r):
    try:
        v = r["numerical_budget"]["rescaled"]["B_total"]
    except (KeyError, TypeError):
        return np.nan
    return float(v) if r.get("status") == "ok" and _finite(v) else np.nan


def comparator_of(r, name):
    v = r.get(name)
    v = v["L"] if isinstance(v, dict) else v
    return float(v) if r.get("status") == "ok" and _finite(v) else np.nan


def paired(y, c, planned):
    """Errors and the presence table on one common finite mask."""
    ok = np.isfinite(y) & np.isfinite(c)
    m_used = int(ok.sum())
    out = dict(m_planned=int(planned), m_used=m_used, m_missing=int(planned - m_used))
    d = y[ok] - c[ok]
    if m_used:
        a = np.abs(d)
        out.update(mean_signed=float(d.mean()), mae=float(a.mean()), rmse=float(math.sqrt(float((d * d).mean()))))
        out.update({"q%d" % int(q * 100): float(np.quantile(a, q)) for q in ERROR_QUANTILES})
        sy, sc = float(np.std(y[ok])), float(np.std(c[ok]))
        out["corr_secondary"] = float(np.corrcoef(y[ok], c[ok])[0, 1]) if (sy > 0 and sc > 0) else "NA"
    py, pc = y[ok] > 0, c[ok] > 0
    out["presence_2x2_on_mask"] = dict(both=int(np.sum(py & pc)), only_primary=int(np.sum(py & ~pc)), only_comparator=int(np.sum(~py & pc)), neither=int(np.sum(~py & ~pc)))
    out["invariant_table_sums_to_m_used"] = sum(out["presence_2x2_on_mask"].values()) == m_used
    return out


def _quantile_bounds(ys, miss, p):
    """Order-statistic bounds with the missing rows placed below or above every value; None where the missing rows leave a side unbounded."""
    m = len(ys) + miss
    if m == 0:
        return dict(empirical_low=None, empirical_high=None)
    idx = max(int(math.ceil(p * m)) - 1, 0)
    return dict(empirical_low=float(ys[idx - miss]) if idx >= miss else None, empirical_high=float(ys[idx]) if idx < len(ys) else None)


def _count(rows, key):
    c = {}
    for r in rows:
        for f in r.get(key, []) or []:
            c[f] = c.get(f, 0) + 1
    return c


def analyze_cell(rows, model, cell):
    """One (n, s) cell.  rows: every row found for the cell (ok and error).  Returns (result, invariants)."""
    n, s, planned = cell["n"], cell["s"], cell["reps"]
    ok = [r for r in rows if r.get("status") == "ok"]
    err = [r for r in rows if r.get("status") == "error"]
    absent = planned - len(rows)
    y_all = np.array([primary_of(r) for r in rows], dtype=float)
    B_all = np.array([budget_of(r) for r in rows], dtype=float)
    have = np.isfinite(y_all)
    y, B = y_all[have], B_all[have]
    B = np.where(np.isfinite(B), B, np.inf)          # a value without a budget cannot be certain either way
    with_value = int(have.sum())
    unknown = planned - with_value
    res = dict(n=n, s=s, cell=cell["cell"], planned=planned, rows_found=len(rows), rows_ok=len(ok), rows_error=len(err), rows_missing=absent,
               with_primary_value=with_value, unknown_primary=unknown)
    inv = [("found_plus_missing_equals_planned", len(rows) + absent == planned), ("ok_plus_error_equals_found", len(ok) + len(err) == len(rows))]
    # ------------------------------------------------------------------ display 1: threshold events of the primary statistic
    te = {}
    for t in THRESHOLDS:
        kn, kc, kp = int(np.sum(y > t)), int(np.sum(y - B > t)), int(np.sum(y + B > t)) + unknown
        lo_env, hi_env = cp_interval(kc, planned)[0], cp_interval(kp, planned)[1]
        te[str(t)] = dict(k_nominal=kn, m_with_value=with_value, rate_nominal=(kn / with_value if with_value else None), cp95_nominal=cp_interval(kn, with_value),
                          binomial_indicator="1{rescaled_L_primary > tau} among the rows that have a primary value",
                          k_certain=kc, k_possible=kp, m_planned=planned, k_unknown=unknown, k_undecided_by_budget=kp - unknown - kc,
                          rows_budget_at_least_tau=int(np.sum(B >= t)),
                          sensitivity_envelope=[lo_env, hi_env],
                          sensitivity_envelope_meaning="[CP lower of k_certain/m_planned, CP upper of k_possible/m_planned]; rests on the empirical budget; not a confidence interval of a continuous probability",
                          limit=model.limit_tail(s, t))
        inv.append(("threshold_%s_certain_le_nominal_le_possible" % t, kc <= kn <= kp - unknown and kp <= planned))
    res["threshold_events"] = te
    res["main_tau"] = MAIN_TAU
    # ------------------------------------------------------------------ display 1: distribution of the primary statistic
    ys = np.sort(y)
    miss = planned - len(ys)
    res["quantiles"] = {str(p): dict(empirical=float(np.quantile(ys, p, method="inverted_cdf")) if len(ys) else None, limit=model.limit_quantile(s, p),
                                     m_used=len(ys), m_missing=miss, **_quantile_bounds(ys, miss, p)) for p in QUANTILES}
    if len(ys):
        u = np.unique(ys)
        right = np.searchsorted(ys, u, side="right") / len(ys)
        left = np.searchsorted(ys, u, side="left") / len(ys)
        Fr = np.array([model.limit_cdf(s, v) for v in u])
        Fl = np.array([0.0 if v <= 0.0 else model.limit_cdf(s, v) for v in u])
        res["sup_cdf_gap_descriptive"] = dict(value=float(max(np.abs(right - Fr).max(), np.abs(left - Fl).max())), m_used=len(ys), m_missing=miss)
    res["zero_atom"] = dict(k_zero=int(np.sum(ys == 0.0)), m_used=len(ys), meaning="rescaled_L_primary is 0 when no PL6 bar exceeds the declared noise floor; the zero point of the empirical CDF is this resolution, not a certified absence")
    loc_central = np.array([float(r.get("L_PL6_central") or 0.0) > 0.0 for r in rows])[have] if len(rows) else np.zeros(0, bool)
    loc_tail = np.array([float(r.get("L_PL6_tail") or 0.0) > 0.0 for r in rows])[have] if len(rows) else np.zeros(0, bool)
    res["location"] = dict(m_used=with_value, any_central_bar=int(loc_central.sum()), any_tail_bar=int(loc_tail.sum()), tail_only=int((loc_tail & ~loc_central).sum()),
                           primary_bar_tail=sum(r.get("primary_bar_location") == "tail" for r in ok))
    # ------------------------------------------------------------------ display 2: same-sample errors against the primary statistic
    comp = {}
    tc = model.t_c(s)
    g_all = np.array([float(r["G_norm"]) if r.get("status") == "ok" and _finite(r.get("G_norm")) else np.nan for r in rows], dtype=float)
    for name in COMPARATORS_PRIMARY + COMPARATORS_AUXILIARY:
        c_all = np.array([comparator_of(r, name) for r in rows], dtype=float)
        e = paired(y_all, c_all, planned)
        e["role"] = "primary comparison" if name in COMPARATORS_PRIMARY else "auxiliary, predeclared"
        inv.append(("paired_%s_table_sums_to_m_used" % name, e["invariant_table_sums_to_m_used"]))
        inv.append(("paired_%s_used_plus_missing_equals_planned" % name, e["m_used"] + e["m_missing"] == planned))
        if tc > 0:
            strata = {}
            for lo, hi in CUSP_STRATA:
                sel = (g_all / tc >= lo) & (g_all / tc < hi)
                strata["%.1f-%s" % (lo, "inf" if math.isinf(hi) else "%.1f" % hi)] = paired(np.where(sel, y_all, np.nan), np.where(sel, c_all, np.nan), int(sel.sum()))
            e["strata_tilt_over_tc"] = strata
        comp[name] = e
    res["same_sample_errors"] = comp
    tr = np.array([r["M_trace_half"] for r in ok if _finite(r.get("M_trace_half"))])
    an = np.array([r["M_aniso_norm"] for r in ok if _finite(r.get("M_aniso_norm"))])
    res["hessian_components"] = dict(m_used=len(tr), trace_half_mean=float(tr.mean()) if len(tr) else None, trace_half_sd=(float(tr.std(ddof=1)) if len(tr) > 1 else "NA"),
                                     aniso_norm_mean=float(an.mean()) if len(an) else None, aniso_norm_q90=float(np.quantile(an, 0.9)) if len(an) else None,
                                     U_leading=model.a * s, leading_trace_sd_formula_at_e=model.trace_sd_coefficient() * n ** (-1.0 / 6.0))
    # ------------------------------------------------------------------ numerical budget and diagnostics, kept apart from the displays
    Bv = B_all[np.isfinite(B_all)]
    md = {k: 0 for k in MIN_CATEGORIES}
    for r in rows:
        k = r.get("minimum_diagnostic") if r.get("status") == "ok" else "ERROR"
        md[k if k in md else "ERROR"] += 1
    md["MISSING"] = absent
    inv.append(("minimum_categories_sum_to_planned", sum(md.values()) == planned))
    gaps = np.array([abs(float(r["rescaled_L_polished_diagnostic"]) - float(r["rescaled_L_primary"])) for r in ok
                     if _finite(r.get("rescaled_L_polished_diagnostic")) and _finite(r.get("rescaled_L_primary"))])
    res["numerical_budget"] = dict(kind="empirical/conditional numerical budget (rescaled B_total per row)", m_used=len(Bv),
                                   median=float(np.median(Bv)) if len(Bv) else None, max=float(Bv.max()) if len(Bv) else None,
                                   primary_flags=_count(ok, "primary_flags"), comparator_flags=_count(ok, "comparator_flags"))
    res["diagnostics"] = dict(note="diagnostics only; nothing here enters a primary display",
                              minimum_diagnostic={k: dict(k=v, m_planned=planned, cp95=cp_interval(v, planned),
                                                          binomial_indicator="1{minimum_diagnostic == %s} over the planned rows (floating-point search; not a certified event)" % k)
                                                  for k, v in md.items()},
                              diagnostic_flags=_count(ok, "diagnostic_flags"), scan_notes=_count(ok, "scan_notes"),
                              polished_sources={str(k): sum(r.get("L_polished_diagnostic_source") == k for r in ok) for k in {r.get("L_polished_diagnostic_source") for r in ok}},
                              abs_polished_minus_primary=dict(m=len(gaps), median=float(np.median(gaps)) if len(gaps) else None, max=float(gaps.max()) if len(gaps) else None))
    res["invariants"] = {k: bool(v) for k, v in inv}
    return res


def analyze(rows, design):
    """All cells of a design; rows of other identities must have been rejected before (release.check_rows)."""
    model = Model(q=design["q"], H=design["H"])
    out = dict(schema=rl.ANALYSIS_SCHEMA, q=design["q"], H=design["H"], thresholds=THRESHOLDS, main_tau=MAIN_TAU, numeric_scope=rl.NUMERIC_SCOPE,
               primary_statistic="rescaled_L_primary", cells=[])
    for c in design["cells"]:
        out["cells"].append(analyze_cell([r for r in rows if r.get("cell") == c["cell"]], model, c))
    out["all_invariants_hold"] = all(all(c["invariants"].values()) for c in out["cells"])
    out["no_primary_value_at_all"] = all(c["with_primary_value"] == 0 for c in out["cells"])
    return out


def figures(res, rows, out, stamp):
    """Display 1 and display 2 from the primary statistic only."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 8.5, "axes.spines.top": False, "axes.spines.right": False})
    model = Model(q=res["q"], H=res["H"])
    cells = res["cells"]
    ns = sorted({c["n"] for c in cells})
    pos_s = sorted({c["s"] for c in cells if c["s"] > 0})
    colors = dict(zip(ns, ("#1f4e79", "#c0792a", "#3a7d44", "#7a1f1f")))
    marks = dict(zip(ns, "os^D"))
    written = []
    fig, ax = plt.subplots(1, 1 + max(1, len(pos_s)), figsize=(3.6 * (1 + max(1, len(pos_s))), 3.3), constrained_layout=True)
    sv = np.linspace(min(c["s"] for c in cells) - 0.2, max(c["s"] for c in cells) + 0.5, 400)
    ax[0].plot(sv, [model.limit_tail(v, MAIN_TAU) for v in sv], color="black", lw=1.1, label="limit $\\Pr(\\Psi_s(G)>%.2f)$" % MAIN_TAU)
    for n in ns:
        cc = [c for c in cells if c["n"] == n]
        xs = np.array([c["s"] for c in cc]) + 0.04 * (ns.index(n) - (len(ns) - 1) / 2)
        ev = [c["threshold_events"][str(MAIN_TAU)] for c in cc]
        rate = np.array([e["rate_nominal"] if e["rate_nominal"] is not None else np.nan for e in ev])
        lo = np.array([e["cp95_nominal"][0] if e["cp95_nominal"][0] is not None else np.nan for e in ev])
        hi = np.array([e["cp95_nominal"][1] if e["cp95_nominal"][1] is not None else np.nan for e in ev])
        elo = np.array([e["sensitivity_envelope"][0] if e["sensitivity_envelope"][0] is not None else np.nan for e in ev])
        ehi = np.array([e["sensitivity_envelope"][1] if e["sensitivity_envelope"][1] is not None else np.nan for e in ev])
        ax[0].vlines(xs, elo, ehi, color=colors[n], lw=4, alpha=0.18)
        ax[0].errorbar(xs, rate, yerr=[rate - lo, hi - rate], fmt=marks[n], ms=3.5, capsize=2, lw=0.8, color=colors[n], label="n=%d" % n)
    ax[0].legend(frameon=False, fontsize=6.5)
    ax[0].set(xlabel="local parameter $s$", ylabel="rate", ylim=(-0.03, 1.03), title="(a) $n^{2/3}L_{\\mathrm{PL}}>%.2f$" % MAIN_TAU)
    for k, s in enumerate(pos_s):
        axk = ax[k + 1]
        yy, F = model.limit_cdf_curve(s)
        axk.plot(np.r_[0.0, 0.0, yy], np.r_[0.0, F[0], F], color="black", lw=1.1, label="limit")
        for n in ns:
            vals = np.sort([primary_of(r) for r in rows if r.get("n") == n and r.get("s") == s and np.isfinite(primary_of(r))])
            if len(vals):
                axk.step(np.r_[0.0, vals], np.r_[0.0, np.arange(1, len(vals) + 1) / len(vals)], where="post", lw=0.9, color=colors[n], label="n=%d" % n)
        axk.legend(frameon=False, fontsize=7)
        axk.set(xlabel="$n^{2/3}L_{\\mathrm{PL}}$", ylabel="distribution function", ylim=(-0.03, 1.03), title="(%s) $s=%g$" % ("bcdefg"[k], s))
    if stamp:
        fig.suptitle(stamp, color="#a00000", fontsize=10)
    p = Path(out) / "display1_threshold_rate_and_cdf.png"
    fig.savefig(p, dpi=170)
    plt.close(fig)
    written.append(p.name)
    cc = [c for c in cells if c["s"] > 0]
    if cc:
        fig, ax = plt.subplots(2, len(cc), figsize=(2.7 * len(cc), 5.0), constrained_layout=True, squeeze=False)
        for j, c in enumerate(cc):
            rr = [r for r in rows if r.get("cell") == c["cell"]]
            y = np.array([primary_of(r) for r in rr])
            for i, (name, lab) in enumerate((("Psi_leading", "leading $\\Psi_s(G_n)$"), ("L_Qtilde", "$L(\\widetilde Q_n)$, full $M_n$"))):
                v = np.array([comparator_of(r, name) for r in rr])
                m = np.isfinite(y) & np.isfinite(v)
                axk = ax[i, j]
                axk.plot(v[m], y[m], ".", ms=2, color=colors[c["n"]], rasterized=True)
                top = float(np.nanmax(np.r_[y[m], v[m], 0.05])) * 1.03
                axk.plot([0, top], [0, top], color="black", lw=0.7)
                e = c["same_sample_errors"][name]
                axk.text(0.03, 0.97, "m=%d of %d\nMAE %s\nRMSE %s" % (e["m_used"], e["m_planned"], "%.3f" % e["mae"] if "mae" in e else "NA", "%.3f" % e["rmse"] if "rmse" in e else "NA"),
                         transform=axk.transAxes, va="top", fontsize=6.5)
                axk.set(xlim=(0, top), ylim=(0, top), xlabel=lab)
                if j == 0:
                    axk.set_ylabel("$n^{2/3}L_{\\mathrm{PL}}$")
                if i == 0:
                    axk.set_title("n=%d, s=%g" % (c["n"], c["s"]), fontsize=8)
        if stamp:
            fig.suptitle(stamp, color="#a00000", fontsize=10)
        p = Path(out) / "display2_same_sample_errors.png"
        fig.savefig(p, dpi=170)
        plt.close(fig)
        written.append(p.name)
    return written


def load_verified_rows(run_dir):
    rows = []
    for p in sorted((Path(run_dir) / "blocks").glob("*.json")):
        rows += json.loads(p.read_text())["rows"]
    return rows


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--run-dir", required=True, type=Path)
    ap.add_argument("--figures", action="store_true")
    ap.add_argument("--preview", action="store_true", help="PENDING engineering preview of an incomplete run; stamped, written to analysis_preview/, never a result")
    a = ap.parse_args(argv)
    freeze, freeze_sha, bad = rl.read_freeze(a.run_dir)
    if freeze is None or bad:
        print("REFUSED: no valid FREEZE.json: %s" % "; ".join(bad), file=sys.stderr)
        return EXIT_REFUSED
    mism = rl.env_mismatches(freeze["env_lock"], rl.env_probe())
    if mism:
        print("REFUSED: environment differs from the frozen lock: " + "; ".join(mism), file=sys.stderr)
        return EXIT_REFUSED
    try:
        lock = rl.RunLock(a.run_dir, "analysis").__enter__()
    except rl.Refusal as why:
        print("REFUSED:", why, file=sys.stderr)
        return EXIT_REFUSED
    try:
        vr = rl.verify_run(a.run_dir, include_analysis=False)
        if vr["status"] == "INVALID":
            print("REFUSED: the run is INVALID: " + "; ".join(vr["reasons_invalid"][:10]), file=sys.stderr)
            return EXIT_REFUSED
        if vr["status"] == "PENDING" and not a.preview:
            print("REFUSED: the run is PENDING (%s); only --preview is possible" % "; ".join(vr["reasons_pending"]), file=sys.stderr)
            return EXIT_REFUSED
        out = a.run_dir / ("analysis_preview" if a.preview else "analysis")
        if out.exists():
            print("REFUSED: %s exists; an analysis is never overwritten" % out.name, file=sys.stderr)
            return EXIT_REFUSED
        rows = load_verified_rows(a.run_dir)
        res = analyze(rows, freeze["design"])
        if not res["all_invariants_hold"]:
            print("REFUSED: an arithmetic invariant failed: " + json.dumps([c["invariants"] for c in res["cells"]]), file=sys.stderr)
            return EXIT_REFUSED
        if res["no_primary_value_at_all"]:
            print("REFUSED: no row has a primary value; there is no valid main result", file=sys.stderr)
            return EXIT_REFUSED
        out.mkdir(parents=True)
        stamp = None
        if a.preview:
            stamp = "PENDING ENGINEERING PREVIEW - INCOMPLETE RUN - NOT A RESULT"
        if freeze.get("fixture_only"):
            stamp = "FIXTURE_ONLY - DETERMINISTIC ENGINEERING ROWS - NOT DATA" + (" - PREVIEW" if a.preview else "")
        written = figures(res, rows, out, stamp) if a.figures else []
        tables = out / "analysis_tables.json"
        tables.write_text(json.dumps(res, indent=1, ensure_ascii=False))
        written.append(tables.name)
        summary = dict(schema=rl.ANALYSIS_SCHEMA, mode="preview" if a.preview else "final", stamp=stamp, fixture_only=bool(freeze.get("fixture_only")),
                       freeze_sha256=freeze_sha, consumed_block_manifest_sha256=vr["block_manifest_sha256"], run_status_at_analysis=vr["status"],
                       analysis_files={f: rl.sha(ROOT / f) for f in ANALYSIS_FILES}, outputs={w: rl.sha(out / w) for w in written},
                       written_utc=rl.utc(), lock_token=lock.token, numeric_scope=rl.NUMERIC_SCOPE,
                       note="Analysis of rescaled_L_primary.  VALID, if the verifier later says so, means complete and bound; not SUPPORTED and not a certified continuous event.")
        (out / "analysis_summary.json").write_text(json.dumps(summary, indent=1, ensure_ascii=False))
        print("analysis written to %s (%s)" % (out, summary["mode"]))
        return 0
    finally:
        lock.__exit__(None, None, None)


if __name__ == "__main__":
    sys.exit(main())
