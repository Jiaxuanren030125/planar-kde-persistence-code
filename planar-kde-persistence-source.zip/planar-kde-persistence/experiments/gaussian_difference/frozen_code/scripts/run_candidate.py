"""Guarded runner for the candidate design (preflight_v2).  It refuses to draw iid data unless a coordinator authorization names this exact freeze.

Task 57, R3.

Modes
  --formal  : iid draws.  Needs <run>/FREEZE.json (not FIXTURE_ONLY) whose frozen files equal the files on disk, and <run>/AUTHORIZATION.json naming that
              freeze's hash, written only after an explicit coordinator instruction.  Otherwise exit 3 before any draw.
  --fixture : deterministic lattice clouds, no RNG.  Needs a FIXTURE_ONLY freeze (make_freeze.py --fixture-only).  Rows are stamped
              data_source="deterministic_lattice_fixture"; they exercise blocks, resume, verification and analysis and are never results.
Both modes check the actual environment against the frozen lock (exit 3 on any difference) and take the run directory's single-writer lock
(exit 3 if another writer holds it).

Rules: seed = seed_base + cell*10000 + rep, one dataset per seed; 20-row blocks written atomically and bound to the freeze hash; a finished block is
verified and never recomputed; an error row is kept and never resampled; a block that fails verification is kept as it is and the run stops
(exit 4), nothing is deleted; an uncommitted .tmp block left by an interruption is moved to blocks/interrupted/ and its rows are computed again
from the same seeds, which the log records.  Changing --workers on a resume changes nothing but the schedule; it is logged.
"""
from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

for _v in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[_v] = "1"

import numpy as np  # noqa: E402

from tda_numerics import release as rl  # noqa: E402
from tda_numerics import sampler  # noqa: E402
from tda_numerics.fixtures import lattice_sample  # noqa: E402
from tda_numerics.model import Model  # noqa: E402
from tda_numerics.pipeline import NumericOptions, analyze_dataset  # noqa: E402

EXIT_REFUSED = 3
EXIT_CORRUPT = 4
MAX_WORKERS = 4


def make_rows(job, design, source):
    """Rows of one block.  The only iid draw in this package is here, on the formal path."""
    model = Model(q=design["q"], H=design["H"])
    opt = NumericOptions(**design.get("numeric_options", {}))
    rows, timings = [], []
    for rep in range(job["start"], job["stop"]):
        n, s = job["n"], job["s"]
        eps = model.e + s * n ** (-1.0 / 3.0)
        seed = rl.seed_of(design, job["cell"], rep)
        try:
            if source == "iid_draw":
                X = sampler.draw_iid(n, eps, design["q"], np.random.default_rng(seed))
            elif source == "deterministic_lattice_fixture":
                X = lattice_sample(n, model, eps)
            else:
                raise ValueError("unknown data source")
            row = analyze_dataset(X, model, n=n, s=s, opt=opt)
        except Exception as exc:   # a failure becomes an error row of the same schema; it is never resampled
            row = dict(schema=rl.ROW_SCHEMA, status="error", error="%s: %s" % (type(exc).__name__, exc), L_primary=None, rescaled_L_primary=None,
                       minimum_diagnostic="ERROR", timings={})
        timings.append(row.pop("timings", {}))
        row.update(cell=job["cell"], rep=rep, seed=seed, data_source=source, n=n, s=s, eps=eps, q=design["q"], H=design["H"])
        rows.append(row)
    return rows, timings


def _worker(args):
    job, design, source = args
    t0 = time.perf_counter()
    rows, timings = make_rows(job, design, source)
    return job, rows, timings, time.perf_counter() - t0


def write_block(run_dir, job, rows, timings, elapsed, freeze_sha, env, writer):
    body = dict(schema=rl.BLOCK_SCHEMA, freeze_sha256=freeze_sha, job=job, rows=rows, rows_sha256=rl.digest(rows),
                timings=timings, elapsed_seconds=elapsed, env=env, writer=writer, written_utc=rl.utc())
    path = run_dir / "blocks" / rl.block_name(job)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(body, ensure_ascii=False))
    os.replace(tmp, path)


def existing_block_ok(path, job, freeze_sha, frozen_files):
    """True for a legal finished block, False if absent.  Anything else raises: the run stops and the file stays as it is."""
    if not path.exists():
        return False
    body = json.loads(path.read_text())
    if body.get("schema") != rl.BLOCK_SCHEMA or body.get("freeze_sha256") != freeze_sha or {k: body.get("job", {}).get(k) for k in job} != job:
        raise RuntimeError("block provenance mismatch: " + path.name)
    if rl.digest(body.get("rows")) != body.get("rows_sha256") or len(body.get("rows") or []) != job["stop"] - job["start"]:
        raise RuntimeError("block rows changed after writing: " + path.name)
    if (body.get("env") or {}).get("frozen_files") != frozen_files:
        raise RuntimeError("block written by other source versions: " + path.name)
    return True


def preconditions(run_dir, design_path, formal):
    """Everything that must hold before the first draw.  Raises rl.Refusal."""
    freeze, freeze_sha, bad = rl.read_freeze(run_dir)
    if freeze is None and not bad:
        raise rl.Refusal("no FREEZE.json in the run directory")
    if bad:
        raise rl.Refusal("; ".join(bad))
    design = json.loads(Path(design_path).read_text())
    if rl.digest(design) != freeze["design_sha256"]:
        raise rl.Refusal("the design file differs from the frozen design")
    probe = rl.env_probe()
    mism = rl.env_mismatches(freeze["env_lock"], probe)
    if mism:
        raise rl.Refusal("environment differs from the frozen lock: " + "; ".join(mism))
    if formal:
        if freeze.get("fixture_only"):
            raise rl.Refusal("a FIXTURE_ONLY freeze cannot start a formal run")
        present, abad = rl.read_authorization(run_dir, freeze, freeze_sha)
        if not present:
            raise rl.Refusal("no AUTHORIZATION.json in the run directory")
        if abad:
            raise rl.Refusal("; ".join(abad))
    elif not freeze.get("fixture_only"):
        raise rl.Refusal("--fixture needs a FIXTURE_ONLY freeze; it never writes into a formal run directory")
    return freeze, freeze_sha, design, probe


def log(run_dir, **event):
    event.setdefault("utc", rl.utc())
    with (run_dir / "run_events.jsonl").open("a") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--design", required=True, type=Path)
    ap.add_argument("--run-dir", required=True, type=Path)
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--fixture", action="store_true")
    g.add_argument("--formal", action="store_true")
    ap.add_argument("--workers", type=int, default=1)
    ap.add_argument("--stop-after-blocks", type=int, default=None, help="engineering only: stop after this many new blocks (simulates an interruption)")
    a = ap.parse_args(argv)
    run_dir = a.run_dir
    if not run_dir.exists():
        print("REFUSED: run directory does not exist (make_freeze.py creates it)", file=sys.stderr)
        return EXIT_REFUSED
    try:
        freeze, freeze_sha, design, probe = preconditions(run_dir, a.design, a.formal)
    except rl.Refusal as why:
        print("REFUSED:", why, file=sys.stderr)
        return EXIT_REFUSED
    workers = max(1, min(a.workers, MAX_WORKERS))
    source = "iid_draw" if a.formal else "deterministic_lattice_fixture"
    try:
        lock = rl.RunLock(run_dir, "runner").__enter__()
    except rl.Refusal as why:
        print("REFUSED:", why, file=sys.stderr)
        return EXIT_REFUSED
    try:
        (run_dir / "blocks").mkdir(exist_ok=True)
        frozen_now = rl.frozen_hashes()
        env = dict(probe=probe, frozen_files=frozen_now, engine_digest=rl.digest(frozen_now))
        writer = dict(pid=os.getpid(), lock_token=lock.token)
        moved = []
        for t in sorted((run_dir / "blocks").glob("*.tmp")):
            dest = run_dir / "blocks" / "interrupted"
            dest.mkdir(exist_ok=True)
            target = dest / ("%s.%s" % (t.name, time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())))
            os.replace(t, target)
            moved.append(target.name)
        jobs = rl.expected_jobs(design)
        try:
            done_before = [j for j in jobs if existing_block_ok(run_dir / "blocks" / rl.block_name(j), j, freeze_sha, frozen_now)]
        except Exception as exc:
            log(run_dir, event="stopped_corrupt_block", error=str(exc), pid=os.getpid(), lock_token=lock.token)
            print("STOPPED: %s; the file is kept as it is and nothing was recomputed" % exc, file=sys.stderr)
            return EXIT_CORRUPT
        pending = [j for j in jobs if j not in done_before]
        log(run_dir, event="start", mode=source, freeze_sha256=freeze_sha, engine_digest=env["engine_digest"], pid=os.getpid(), lock_token=lock.token,
            workers=workers, expected_blocks=len(jobs), completed_blocks=len(done_before), pending_blocks=len(pending),
            resumed=bool(done_before or moved), interrupted_tmp_moved=moved)
        if a.stop_after_blocks is not None:
            pending = pending[:a.stop_after_blocks]
        done = len(done_before)
        payload = [(j, design, source) for j in pending]
        if workers > 1 and len(payload) > 1:
            with mp.get_context("spawn").Pool(workers) as pool:
                results = pool.imap_unordered(_worker, payload, chunksize=1)
                for job, rows, timings, elapsed in results:
                    write_block(run_dir, job, rows, timings, elapsed, freeze_sha, env, writer)
                    done += 1
                    log(run_dir, event="block_done", block=rl.block_name(job), done=done, total=len(jobs), elapsed=elapsed, errors=sum(r["status"] == "error" for r in rows))
        else:
            for args in payload:
                job, rows, timings, elapsed = _worker(args)
                write_block(run_dir, job, rows, timings, elapsed, freeze_sha, env, writer)
                done += 1
                log(run_dir, event="block_done", block=rl.block_name(job), done=done, total=len(jobs), elapsed=elapsed, errors=sum(r["status"] == "error" for r in rows))
        log(run_dir, event="finish", done=done, total=len(jobs), remaining=len(jobs) - done, pid=os.getpid(), lock_token=lock.token)
        print("blocks done %d of %d; source = %s" % (done, len(jobs), source))
        return 0
    finally:
        lock.__exit__(None, None, None)


if __name__ == "__main__":
    sys.exit(main())
