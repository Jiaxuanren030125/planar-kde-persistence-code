"""Critical points of the continuous KDE: Newton polishing and an a-posteriori existence certificate.

Exact-event facts used (fhat is a finite Gaussian mixture on the plane):
  (a) No critical point lies outside conv{X_i}: outside the hull a separating direction makes every kernel derivative strict.
  (b) A bounded component of {fhat<c} attains its minimum in its interior, so {L_n>0} implies a local minimum exists.
      Conversely a strict local minimum gives a small enclosing level curve and hence a positive bar.  For almost every sample fhat is a
      Morse function, and then L_n>0 <=> fhat has a strict local minimum.  The certificates do not rely on this equivalence:
      NONE_CERT excludes every point with grad=0 and D^2>=0, and EXIST_CERT proves a strict minimum.
  (c) Local minima satisfy grad=0 and D^2 >= 0.

Certificate of absence (NONE_CERT): cover conv{X_i} by squares of half-diagonal rho; for each square centred at c show either
  A:  |g(c)| > rho||H(c)|| + rho^2/2 ||T(c)|| + rho^3/6 L4      (no critical point in the square), or
  B:  lambda_min(H(c)) + rho||T(c)|| + rho^2/2 L4 < 0            (Hessian has a negative direction throughout),
with L4 an upper bound of the fourth-derivative operator norm on the square.  Failed squares are subdivided.

Certificate of presence (EXIST_CERT): at a Newton limit x* with lambda*=lambda_min(H(x*))>0 put
  r = min(lambda*/(4||T||), sqrt(lambda*/(4 L4))).  On B(x*,r), lambda_min(D^2) >= 5 lambda*/8, so fhat is strictly convex there;
  if |g(x*)| < (5/8) lambda* r the ball contains a unique critical point and it is a strict local minimum.

These are numerically evaluated certificates.  Every comparison includes a rounding allowance, but that allowance is calibrated by
measurement (QA Q19), not proved, and ordinary floating arithmetic is used.  They are not interval-arithmetic or formal proofs.

preflight_v2 (task 57): the pipeline reports these outcomes only as a floating-point minimum diagnostic (MIN_FOUND_FLOAT, NO_MIN_FOUND_FLOAT,
UNDETERMINED_FLOAT); they are not certified continuous events and never change the primary statistic.  In the presence test the radius and the
convexity margin use lambda_eff = lambda - n2.
"""
from __future__ import annotations

import math

import numpy as np
from scipy.signal import fftconvolve
from scipy.spatial import ConvexHull, QhullError

from .spectral_kde import EPS, TWO_PI

JET1 = [(1, 0), (0, 1)]
JET2 = [(2, 0), (1, 1), (0, 2)]
JET3 = [(3, 0), (2, 1), (1, 2), (0, 3)]


# ------------------------------------------------------------------------------------------------------- envelopes
def _he4_abs_envelope(z):
    """max_{|t|<=z} |t^4-6t^2+3|, computed in closed form piecewise."""
    z = np.asarray(z, dtype=float)
    out = np.full(z.shape, 3.0)
    s3 = math.sqrt(3.0)
    he = np.abs(z ** 4 - 6.0 * z ** 2 + 3.0)
    out = np.where(z >= s3, np.maximum(6.0, he), np.maximum(3.0, he))
    return out


def d4_kernel_envelope(r, H):
    """Upper bound of ||D^4 phi_H(y)||_op at |y|=r (symmetric-tensor norm = sup_u |d_u^4 phi_H|)."""
    z = np.asarray(r, dtype=float) / math.sqrt(H)
    return _he4_abs_envelope(z) * np.exp(-np.asarray(r, dtype=float) ** 2 / (2.0 * H)) / (TWO_PI * H * H * H)


def d4_global(H):
    r = np.linspace(0.0, 12.0 * math.sqrt(H), 20001)
    return float(d4_kernel_envelope(r, H).max()) * (1.0 + 1e-9)


class L4Field:
    """Tile-wise upper bound of sup||D^4 fhat||_op, using no cancellation between kernels.  The formula is an upper bound; the table is computed
    in floating point by FFT, with a margin scaled to the rounding of that convolution.

    The window is tiled with squares of side tau; each observation is assigned to its tile.  For x within rho of a cell centre in
    tile T and X_i in tile T', |x-X_i| >= |c_T-c_T'| - tau*sqrt(2) - rho."""

    def __init__(self, X, H, W, tau=0.125, rho=0.05):
        self.H, self.tau, self.rho = H, tau, rho
        self.W = W
        nt = int(math.ceil(2.0 * W / tau)) + 2
        self.nt = nt
        self.origin = -W - tau
        edges = self.origin + tau * np.arange(nt + 1)
        Hist, _, _ = np.histogram2d(X[:, 0], X[:, 1], bins=[edges, edges])
        if int(Hist.sum()) != len(X):
            raise RuntimeError("L4Field histogram lost observations")
        # non-increasing envelope table in distance
        rtab = np.linspace(0.0, 2.0 * (2.0 * W + 2.0) + 12.0 * math.sqrt(H), 40001)
        env = d4_kernel_envelope(rtab, H)
        env = np.maximum.accumulate(env[::-1])[::-1]
        k = np.arange(-(nt - 1), nt) * tau
        dist = np.hypot(k[:, None], k[None, :])
        reff = np.maximum(dist - tau * math.sqrt(2.0) - rho, 0.0)
        K = np.interp(reff, rtab, env)
        L = fftconvolve(Hist, K, mode="same") / len(X)
        # 0.1% margin covers linear interpolation of the envelope table; the second term covers FFT rounding, which scales with ||Hist||_2 ||K||_2
        fft_margin = 64.0 * EPS * math.sqrt(float(np.sum(Hist * Hist))) * math.sqrt(float(np.sum(K * K))) / len(X)
        self.table = np.maximum(L, 0.0) * 1.001 + fft_margin

    def __call__(self, pts):
        pts = np.atleast_2d(pts)
        i = np.clip(((pts[:, 0] - self.origin) / self.tau).astype(int), 0, self.nt - 1)
        j = np.clip(((pts[:, 1] - self.origin) / self.tau).astype(int), 0, self.nt - 1)
        return self.table[i, j]


class ConstantL4:
    def __init__(self, value):
        self.value = float(value)

    def __call__(self, pts):
        return np.full(len(np.atleast_2d(pts)), self.value)


# ------------------------------------------------------------------------------------------------------ jets on arrays
def _hess_eigs(h11, h12, h22):
    tr = 0.5 * (h11 + h22)
    dt = np.hypot(0.5 * (h11 - h22), h12)
    return tr - dt, tr + dt


def _t_frob(t111, t112, t122, t222):
    return np.sqrt(t111 ** 2 + 3.0 * t112 ** 2 + 3.0 * t122 ** 2 + t222 ** 2)


class Allowances:
    """Allowances for the norms used by the tests, from component allowances: gradient 2-norm (factor sqrt 2), Hessian operator norm (factor 2,
    through the Frobenius norm) and third-derivative Frobenius norm with multiplicities 1,3,3,1 (factor sqrt 8).  Each component allowance is the
    calibrated rounding allowance plus the aliasing and wrap bounds."""

    def __init__(self, field):
        n1 = max(field.noise_allowance(d) for d in JET1)
        n2 = max(field.noise_allowance(d) for d in JET2)
        n3 = max(field.noise_allowance(d) for d in JET3)
        m = field.meta
        if m.get("kind") == "kde_direct_sum":
            n1 += m["aliasing_bound"]["1"] + m["wrap_bound"]["1"]
            n2 += m["aliasing_bound"]["2"] + m["wrap_bound"]["2"]
            n3 += m["aliasing_bound"]["3"] + m["wrap_bound"]["3"]
        self.n1 = math.sqrt(2.0) * n1
        self.n2 = 2.0 * n2
        self.n3 = math.sqrt(8.0) * n3


def eval_tests(values, rho, L4vals, al):
    """Vectorized tests A and B."""
    g = np.hypot(values[(1, 0)], values[(0, 1)])
    lmin, lmax = _hess_eigs(values[(2, 0)], values[(1, 1)], values[(0, 2)])
    Hop = np.maximum(np.abs(lmin), np.abs(lmax)) + al.n2
    Tf = _t_frob(values[(3, 0)], values[(2, 1)], values[(1, 2)], values[(0, 3)]) + al.n3
    test_a = (g - al.n1) > rho * Hop + 0.5 * rho * rho * Tf + rho ** 3 / 6.0 * L4vals
    test_b = (lmin + al.n2 + rho * Tf + 0.5 * rho * rho * L4vals) < 0.0
    return test_a, test_b, lmin, Tf, g


def newton_to_critical(field, x0, max_iter=40, tol=1e-15, max_move=None, want=None, step_tol_sd=1e-4):
    """Plain Newton on the gradient with backtracking on |grad|.  Returns dict; never raises for non-convergence.

    A small |grad| alone is not convergence: far in the tail of a kernel |grad| is below any absolute tolerance at points that are not critical.
    converged therefore also requires the final Newton step |grad|/min|eig| to be below step_tol_sd kernel standard deviations.
    Whether the Hessian itself rises above rounding is checked by the caller, which holds the allowances."""
    x = np.array(x0, dtype=float)
    start = x.copy()
    derivs = JET1 + JET2
    vals = field.points_many(x[None, :], derivs)
    g = np.array([vals[(1, 0)][0], vals[(0, 1)][0]])
    H = np.array([[vals[(2, 0)][0], vals[(1, 1)][0]], [vals[(1, 1)][0], vals[(0, 2)][0]]])
    gn = float(np.hypot(*g))
    ok = False
    for it in range(max_iter):
        if gn <= tol:
            ok = True
            break
        try:
            step = -np.linalg.solve(H, g)
        except np.linalg.LinAlgError:
            break
        if max_move is not None:
            sl = float(np.hypot(*step))
            if sl > max_move:
                step *= max_move / sl
        t = 1.0
        accepted = False
        for _ in range(8):
            xn = x + t * step
            v2 = field.points_many(xn[None, :], derivs)
            g2 = np.array([v2[(1, 0)][0], v2[(0, 1)][0]])
            gn2 = float(np.hypot(*g2))
            if gn2 < gn or gn2 <= tol:
                x, g, gn = xn, g2, gn2
                H = np.array([[v2[(2, 0)][0], v2[(1, 1)][0]], [v2[(1, 1)][0], v2[(0, 2)][0]]])
                accepted = True
                break
            t *= 0.5
        if not accepted:
            # gradient cannot be reduced further at this precision
            ok = gn <= 1e-12 * max(1.0, float(np.abs(H).max()))
            break
    else:
        ok = gn <= 1e-12
    lam = np.linalg.eigvalsh(H)
    smin = float(np.min(np.abs(lam)))
    newton_step = gn / smin if smin > 0.0 else math.inf
    small_step = newton_step <= step_tol_sd * math.sqrt(field.H)
    return dict(x=x, grad_norm=gn, H=H, eig=lam, converged=bool((ok or gn <= tol) and small_step), newton_step=newton_step, iterations=it + 1 if max_iter else 0,
                moved=float(np.hypot(*(x - start))))


def certify_min_at(field, res, L4fn, al):
    """Presence certificate at a Newton limit.  Returns (certified?, record)."""
    x = res["x"]
    lam = float(res["eig"][0])
    v3 = field.points_many(x[None, :], JET3)
    Tf = float(_t_frob(v3[(3, 0)], v3[(2, 1)], v3[(1, 2)], v3[(0, 3)])[0]) + al.n3
    L4 = float(L4fn(x[None, :])[0])
    # the computed eigenvalue may exceed the true one by the allowance n2, so the radius and the 5/8 convexity margin use lambda - n2 (task 57, R1.5)
    lam_eff = lam - al.n2
    rec = dict(x=x.tolist(), lambda_min=lam, lambda_eff=lam_eff, grad_norm=res["grad_norm"], T=Tf, L4=L4, radius=0.0, certified=False)
    if lam_eff <= 0.0:
        return False, rec
    r = min(lam_eff / (4.0 * Tf) if Tf > 0 else math.inf, math.sqrt(lam_eff / (4.0 * L4)) if L4 > 0 else math.inf)
    r = min(r, getattr(L4fn, "rho", math.inf))      # the tile bound is valid only within rho of a point of that tile
    rec["radius"] = r
    if res["grad_norm"] + al.n1 < 0.625 * lam_eff * r:
        rec["certified"] = True
    return rec["certified"], rec


def kantorovich_saddle(field, res, L4fn, al):
    """Existence/uniqueness near a nondegenerate indefinite Newton limit.  h=|H^-1|^2 |g| L3 <= 1/2 with L3 local bound."""
    x = res["x"]
    v3 = field.points_many(x[None, :], JET3)
    Tf = float(_t_frob(v3[(3, 0)], v3[(2, 1)], v3[(1, 2)], v3[(0, 3)])[0]) + al.n3
    L4 = float(L4fn(x[None, :])[0])
    lam = res["eig"]
    smin = float(np.min(np.abs(lam)))
    if smin <= al.n2:
        return dict(certified=False, reason="near singular", smin=smin)
    beta = 1.0 / smin
    # a tube of radius r0 around x: the Lipschitz constant of the Hessian is at most Tf + r0 L4
    r0 = smin / (4.0 * max(Tf, 1e-300))
    L3 = Tf + r0 * L4
    h = beta * beta * (res["grad_norm"] + al.n1) * L3
    radius = 2.0 * beta * (res["grad_norm"] + al.n1)
    indefinite = lam[0] < 0.0 < lam[1]
    return dict(certified=bool(h <= 0.5 and radius <= r0 and indefinite), h=h, radius=radius, smin=smin, indefinite=bool(indefinite))


# --------------------------------------------------------------------------------------------------- hull utilities
def hull_equations(X):
    """Half-plane description of conv{X_i}; if the sample is degenerate fall back to the bounding box."""
    X = np.asarray(X, dtype=float)
    lo, hi = X.min(axis=0), X.max(axis=0)
    box = np.array([[1.0, 0.0, -hi[0]], [-1.0, 0.0, lo[0]], [0.0, 1.0, -hi[1]], [0.0, -1.0, lo[1]]])
    if len(X) >= 3:
        try:
            return ConvexHull(X).equations, lo, hi
        except QhullError:
            pass
    return box, lo, hi


def certify_minima(field, eqs, lo, hi, L4fn, d0=0.0625, max_level=14, max_cells=200000, newton_per_level=64):
    """Inventory of local minima of the field on the hull with the absence/presence tests above.

    Returns status NONE_CERT (no local minimum anywhere), EXIST_CERT (>=1 certified strict minimum; list given) or UNDETERMINED,
    plus the number of squares left unresolved at the depth limit."""
    al = Allowances(field)
    xs = np.arange(lo[0] - d0 / 2.0, hi[0] + d0, d0)
    ys = np.arange(lo[1] - d0 / 2.0, hi[1] + d0, d0)
    derivs = JET1 + JET2 + JET3
    vals = field.tensor_many(xs, ys, derivs)
    XX, YY = np.meshgrid(xs, ys, indexing="ij")
    rho = d0 / math.sqrt(2.0)
    pts = np.column_stack([XX.ravel(), YY.ravel()])
    inside = np.max(eqs[:, :2] @ pts.T + eqs[:, 2:3], axis=0) <= rho
    pts = pts[inside]
    flat = {d: vals[d].ravel()[inside] for d in derivs}
    cells_level0 = len(pts)
    minima = []
    stats = []
    level = 0
    side = d0
    evals = cells_level0
    while True:
        L4v = L4fn(pts)
        ta, tb, lmin, Tf, g = eval_tests(flat, side / math.sqrt(2.0), L4v, al)
        unresolved = ~(ta | tb)
        pts_u = pts[unresolved]
        lmin_u = lmin[unresolved]
        rho_lvl = side / math.sqrt(2.0)
        # try to explain unresolved squares by a certified strict minimum
        if len(pts_u):
            if minima:
                xm = np.array([m["x"] for m in minima])
                rm = np.array([m["radius"] for m in minima])
                dist = np.hypot(pts_u[:, 0, None] - xm[:, 0], pts_u[:, 1, None] - xm[:, 1])
                inside_ball = np.any(dist + rho_lvl <= rm, axis=1)
                pts_u, lmin_u = pts_u[~inside_ball], lmin_u[~inside_ball]
            order = np.argsort(-lmin_u)
            tried = 0
            for idx in order.tolist():
                if tried >= newton_per_level:
                    break
                if minima:
                    xm = np.array([m["x"] for m in minima])
                    rm = np.array([m["radius"] for m in minima])
                    if np.any(np.hypot(pts_u[idx, 0] - xm[:, 0], pts_u[idx, 1] - xm[:, 1]) + rho_lvl <= rm):
                        continue
                tried += 1
                res = newton_to_critical(field, pts_u[idx], max_iter=25, max_move=max(4.0 * rho_lvl, 1e-3))
                if res["converged"] and res["eig"][0] > 0:
                    good, rec = certify_min_at(field, res, L4fn, al)
                    if good and not any(np.hypot(*(np.array(m["x"]) - res["x"])) < max(m["radius"], rec["radius"]) for m in minima):
                        rec["level"] = level
                        minima.append(rec)
            if minima:
                xm = np.array([m["x"] for m in minima])
                rm = np.array([m["radius"] for m in minima])
                dist = np.hypot(pts_u[:, 0, None] - xm[:, 0], pts_u[:, 1, None] - xm[:, 1])
                inside_ball = np.any(dist + rho_lvl <= rm, axis=1)
                pts_u = pts_u[~inside_ball]
        stats.append(dict(level=level, side=side, cells=len(pts), tested_a=int(ta.sum()), tested_b=int((tb & ~ta).sum()), unresolved=int(len(pts_u))))
        if len(pts_u) == 0:
            status = "EXIST_CERT" if minima else "NONE_CERT"
            final_unresolved = 0
            break
        if level >= max_level or len(pts_u) * 4 > max_cells:
            status = "EXIST_CERT" if minima else "UNDETERMINED"
            final_unresolved = int(len(pts_u))
            break
        side *= 0.5
        level += 1
        q = side / 2.0
        kids = np.concatenate([pts_u + np.array([[sx * q, sy * q]]) for sx in (-1.0, 1.0) for sy in (-1.0, 1.0)])
        rho_new = side / math.sqrt(2.0)
        keep = np.max(eqs[:, :2] @ kids.T + eqs[:, 2:3], axis=0) <= rho_new
        pts = kids[keep]
        if len(pts) == 0:
            status = "EXIST_CERT" if minima else "NONE_CERT"
            final_unresolved = 0
            break
        flat = field.points_many(pts, derivs)
        evals += len(pts)
    return dict(status=status, minima=minima, n_minima=len(minima), final_unresolved=final_unresolved, levels=level,
                cells_level0=cells_level0, evaluations=int(evals), level_stats=stats,
                allowances=dict(grad=al.n1, hess=al.n2, third=al.n3))
