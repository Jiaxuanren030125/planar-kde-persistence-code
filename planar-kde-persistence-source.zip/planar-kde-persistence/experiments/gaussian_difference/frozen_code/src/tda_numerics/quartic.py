"""The anisotropic quartic Q(u) = G.u + u^T M u - b|u|^4 used in the second comparison.

M is the full symmetric matrix M_n = (n^{1/3}/2) D^2 fhat_n(0); the isotropic Psi formula is NOT applied to it.

Two independent evaluations of the longest bar:
  * algebraic: all critical points from G + 2Mu - 4b|u|^2 u = 0.  In the eigenbasis of M put tau=4b|u|^2, u_i=g_i/(tau-2m_i);
    tau solves a degree-5 polynomial.  Roots seed Newton; polar multi-starts guard the special branches tau=2m_i (g_i=0).
    Types come from the Hessian 2M - 4b(|u|^2 I + 2uu^T).  Morse count #max-#saddle+#min must equal 1 (Q -> -inf at infinity).
    On any line Q is a quartic with leading coefficient -b, which has at most one local minimum, so Q has at most one.  That minimum is
    nondegenerate: a zero Hessian direction would give c t^3 - b t^4 on that line, which has no minimum at t=0.  Along each ray from the minimum Q has
    a unique maximizer, so sublevel components below that ridge are star-shaped about it and the bar always ends at the lowest saddle.
  * grid: PL persistence (same union-find as the KDE) on a window whose boundary has outward-decreasing radial derivative.
Mismatch beyond the grid bound is reported, never resolved silently.
"""
from __future__ import annotations

import math

import numpy as np

from .model import psi_ray
from .ph_grid import bars_c, longest, node_xy


def Q_value(u, G, M, b):
    u = np.asarray(u, dtype=float)
    r2 = u[..., 0] ** 2 + u[..., 1] ** 2
    return (G[0] * u[..., 0] + G[1] * u[..., 1] + M[0, 0] * u[..., 0] ** 2 + 2.0 * M[0, 1] * u[..., 0] * u[..., 1]
            + M[1, 1] * u[..., 1] ** 2 - b * r2 * r2)


def Q_grad(u, G, M, b):
    r2 = float(u @ u)
    return G + 2.0 * M @ u - 4.0 * b * r2 * u


def Q_hess(u, M, b):
    r2 = float(u @ u)
    return 2.0 * M - 4.0 * b * (r2 * np.eye(2) + 2.0 * np.outer(u, u))


def _newton(u0, G, M, b, scale, iters=60):
    u = np.array(u0, dtype=float)
    tol = 1e-13 * max(scale, 1e-3) ** 3 * max(b, 1e-12) + 1e-15
    for _ in range(iters):
        g = Q_grad(u, G, M, b)
        gn = float(np.hypot(*g))
        if gn <= tol:
            return u, gn, True
        H = Q_hess(u, M, b)
        try:
            step = -np.linalg.solve(H, g)
        except np.linalg.LinAlgError:
            return u, gn, False
        t = 1.0
        for _ in range(30):
            un = u + t * step
            if float(np.hypot(*Q_grad(un, G, M, b))) < gn:
                u = un
                break
            t *= 0.5
        else:
            return u, gn, gn <= 1e-9 * tol ** 0.5
    gn = float(np.hypot(*Q_grad(u, G, M, b)))
    return u, gn, gn <= tol * 1e3


def critical_points(G, M, b):
    G = np.asarray(G, dtype=float)
    M = 0.5 * (np.asarray(M, dtype=float) + np.asarray(M, dtype=float).T)
    m, R = np.linalg.eigh(M)         # ascending
    g = R.T @ G
    mplus = max(abs(m[0]), abs(m[1]), 1e-12)
    scale = math.sqrt(mplus / (2.0 * b)) + (float(np.hypot(*G)) / (4.0 * b)) ** (1.0 / 3.0)
    starts = []
    # polynomial in tau: tau (tau-2m1)^2 (tau-2m2)^2 - 4b [g1^2 (tau-2m2)^2 + g2^2 (tau-2m1)^2] = 0
    p1 = np.poly1d([1.0, -2.0 * m[0]]) ** 2
    p2 = np.poly1d([1.0, -2.0 * m[1]]) ** 2
    P = np.poly1d([1.0, 0.0]) * p1 * p2 - 4.0 * b * (g[0] ** 2 * p2 + g[1] ** 2 * p1)
    for tau in np.roots(P.coeffs):
        if abs(tau.imag) <= 1e-7 * (1.0 + abs(tau.real)) and tau.real >= -1e-12:
            t = max(tau.real, 0.0)
            d1, d2 = t - 2.0 * m[0], t - 2.0 * m[1]
            if abs(d1) > 1e-14 and abs(d2) > 1e-14:
                starts.append(R @ np.array([g[0] / d1, g[1] / d2]))
    # branches tau = 2 m_i (exact when g_i = 0) and small polar multistart
    for i, mi in enumerate(m):
        if mi > 0:
            j = 1 - i
            denom = 2.0 * mi - 2.0 * m[j]
            uj = g[j] / denom if abs(denom) > 1e-14 else 0.0
            rr = mi / (2.0 * b) - uj * uj
            ui = math.sqrt(rr) if rr > 0 else 0.0
            for sign in (1.0, -1.0):
                v = np.zeros(2)
                v[i], v[j] = sign * ui, uj
                starts.append(R @ v)
    starts.append(np.zeros(2))
    found = []
    tol_same = 1e-7 * max(scale, 1e-6)
    tol_eig = 1e-8 * max(4.0 * mplus, 4.0 * b * scale * scale, 1e-12)

    def absorb(seeds):
        for s0 in seeds:
            u, gn, ok = _newton(s0, G, M, b, scale)
            if not ok:
                continue
            if any(float(np.hypot(*(u - f["u"]))) <= tol_same for f in found):
                continue
            ev = np.linalg.eigvalsh(Q_hess(u, M, b))
            if abs(ev[0]) <= tol_eig or abs(ev[1]) <= tol_eig:
                typ = "degenerate"
            elif ev[0] > 0:
                typ = "min"
            elif ev[1] < 0:
                typ = "max"
            else:
                typ = "saddle"
            found.append(dict(u=u, value=float(Q_value(u, G, M, b)), eig=ev, grad=gn, type=typ))

    def morse_ok():
        c = [f["type"] for f in found]
        return "degenerate" not in c and c.count("max") - c.count("saddle") + c.count("min") == 1 and c.count("max") >= 1

    absorb(starts)
    if not morse_ok():
        polar = [scale * fr * np.array([math.cos(2.0 * math.pi * (k + 0.5) / 16.0), math.sin(2.0 * math.pi * (k + 0.5) / 16.0)])
                 for fr in (0.2, 0.45, 0.7, 0.95, 1.2, 1.5) for k in range(16)]
        absorb(polar)
    return found, scale


def window_radius(G, M, b, margin=1.15):
    """R such that the radial derivative of Q is negative for all |u|>=R (2 m_+ r + |G| - 4 b r^3 < 0)."""
    mplus = float(max(np.linalg.eigvalsh(0.5 * (M + M.T)).max(), 0.0))
    t = float(np.hypot(*np.asarray(G, dtype=float)))
    r = 1.0
    for _ in range(200):
        if 2.0 * mplus * r + t - 4.0 * b * r ** 3 < 0.0:
            break
        r *= 1.05
    return r * margin


def bar_grid(G, M, b, nu=601, R=None, mode=6):
    G = np.asarray(G, dtype=float)
    M = 0.5 * (np.asarray(M, dtype=float) + np.asarray(M, dtype=float).T)
    if R is None:
        R = window_radius(G, M, b)
    if nu % 2 == 0:
        nu += 1
    x = np.linspace(-R, R, nu)
    XX, YY = np.meshgrid(x, x, indexing="ij")
    W = XX * XX + YY * YY
    F = G[0] * XX + G[1] * YY + M[0, 0] * XX * XX + 2.0 * M[0, 1] * XX * YY + M[1, 1] * YY * YY - b * W * W
    B = bars_c(F, mode)
    delta = x[1] - x[0]
    mplus = float(max(np.abs(np.linalg.eigvalsh(M)).max(), 0.0))
    sup_d2 = 2.0 * mplus + 12.0 * b * 2.0 * R * R     # |x|<=sqrt2 R in the corners
    return dict(L=longest(B), n_bars=int(len(B["length"])), R=R, delta=delta,
                c0_bound=2.0 * (delta * delta / 4.0) * sup_d2,
                birth=node_xy(B["birth"][:1], x, x).tolist(), death=node_xy(B["death"][:1], x, x).tolist())


def bar_algebraic(G, M, b):
    G = np.asarray(G, dtype=float)
    M = 0.5 * (np.asarray(M, dtype=float) + np.asarray(M, dtype=float).T)
    m = np.linalg.eigvalsh(M)
    mplus = max(abs(m[0]), abs(m[1]), 1e-12)
    tiso = 1e-12 * mplus
    t = float(np.hypot(*G))
    if abs(m[1] - m[0]) <= tiso:
        # isotropic: the exact closed form applies because the matrix really is a multiple of I
        U = 0.5 * (m[0] + m[1])
        return dict(L=psi_ray(U, b, t), status="ok_isotropic_closed_form", n_min=None, n_saddle=None, n_max=None, morse=None)
    crit, scale = critical_points(G, M, b)
    nmin = sum(c["type"] == "min" for c in crit)
    nsad = sum(c["type"] == "saddle" for c in crit)
    nmax = sum(c["type"] == "max" for c in crit)
    ndeg = sum(c["type"] == "degenerate" for c in crit)
    morse_ok = (ndeg == 0 and nmax - nsad + nmin == 1)
    summary = dict(n_min=nmin, n_saddle=nsad, n_max=nmax, n_degenerate=ndeg, morse=bool(morse_ok),
                   critical=[dict(u=c["u"].tolist(), value=c["value"], type=c["type"]) for c in crit])
    if not morse_ok:
        return dict(L=None, status="morse_check_failed", **summary)
    if nmin == 0:
        return dict(L=0.0, status="ok_no_minimum", **summary)
    if nmin > 1:
        return dict(L=None, status="more_than_one_minimum", **summary)
    mn = next(c for c in crit if c["type"] == "min")
    sad = sorted(c["value"] for c in crit if c["type"] == "saddle")
    if not sad:
        return dict(L=None, status="minimum_without_saddle", **summary)
    # within rounding of the fold the difference can come out as -1e-16; a bar length is never negative
    return dict(L=max(sad[0] - mn["value"], 0.0), status="ok_lowest_saddle", **summary)


def bar(G, M, b, grid_nu=361):
    """Algebraic value with a grid cross-check; the grid value is authoritative for pairing if they disagree."""
    alg = bar_algebraic(G, M, b)
    grd = bar_grid(G, M, b, nu=grid_nu)
    mism = None if alg["L"] is None else abs(alg["L"] - grd["L"])
    agree = (mism is not None and mism <= grd["c0_bound"] + 1e-12)
    return dict(L=alg["L"] if alg["L"] is not None else None, L_grid=grd["L"], grid_c0_bound=grd["c0_bound"],
                grid_window=grd["R"], status=alg["status"], agree=bool(agree), mismatch=mism,
                n_min=alg.get("n_min"), n_saddle=alg.get("n_saddle"), n_max=alg.get("n_max"))
