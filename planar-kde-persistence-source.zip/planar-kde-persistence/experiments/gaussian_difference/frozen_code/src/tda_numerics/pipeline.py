"""One-dataset analysis: from observations to a complete record.  Failures become explicit statuses, never L=0.

Version preflight_v2 (task 57).

The primary statistic is L_primary: the longest finite bar of the mode-6 PL filtration of the node heights, after bars no longer than the declared
noise_floor are dropped.  Its numerical_budget is an empirical/conditional budget, not a rigorous certificate.  Everything that depends on the
heuristic critical-point search (L_polished_diagnostic) or on the floating-point minimum search (minimum_diagnostic) is a diagnostic: neither can
change L_primary, and the analysis never reads them for the primary displays.
"""
from __future__ import annotations

import math
import time
import traceback
from dataclasses import asdict, dataclass

import numpy as np
from scipy import ndimage

from . import ENGINE_VERSION
from .critical import Allowances, L4Field, ConstantL4, certify_minima, hull_equations, kantorovich_saddle, newton_to_critical, JET1, JET2, JET3, _hess_eigs, _t_frob
from .model import Model, psi_ray
from .ph_grid import bars_c, longest, node_xy, sort_order
from .quartic import bar as quartic_bar, bar_algebraic, bar_grid
from .spectral_kde import EPS, direct_points, kde_field, origin_jet

SCHEMA = "numerics_preflight.row.v3"
PRIMARY_DEFINITION = ("Longest finite bar of the lower-star filtration of the Kuhn-triangulated (mode 6) PL interpolation of the KDE node heights on the "
                      "output grid, after bars of length <= noise_floor are dropped; physical units; rescaled_L_primary = n^(2/3) L_primary")
BUDGET_KIND = "empirical/conditional numerical budget; not rigorously certified"
# floating-point minimum search: names of v1 and their v2 meaning.  None of them is a certified continuous event.
MIN_DIAGNOSTIC_NAMES = {"EXIST_CERT": "MIN_FOUND_FLOAT", "NONE_CERT": "NO_MIN_FOUND_FLOAT", "UNDETERMINED": "UNDETERMINED_FLOAT", "NOT_RUN": "NOT_RUN", "ERROR": "ERROR"}
ARTIFACT = "grid_artifact_both_nodes_reach_one_critical_point"
POLISHED_OK = ("ok", "ok_after_ridge_scan")
_KUHN6 = np.array([[1, 1, 0], [1, 1, 1], [0, 1, 1]], dtype=bool)     # adjacency of ph_core.c mode 6 as a label structure: offsets (+1,+1), (-1,-1) and the axes
_OFF6 = ((-1, 0), (1, 0), (0, -1), (0, 1), (1, 1), (-1, -1))
EXTERIOR = 0x7fffffff                                                 # component id of the exterior in the elder rule; labels and typed minima never take this value
SCAN_FAILED = ("no_ending_saddle", "ending_saddle_outside_C0_bracket", "no_typed_minimum", "lower_minimum_found_by_descent", "exception")


@dataclass(frozen=True)
class NumericOptions:
    du: float = 0.08              # rescaled output spacing; physical spacing delta = du * n^(-1/6)
    delta_coarse_sd: float = 0.25 # node spacing in kernel standard deviations (exp(-8 pi^2) spectral tail)
    pad_sd: float = 8.0           # node box extends the sample extent by this many kernel standard deviations
    d0: float = 0.0625            # first-level square side of the existence certificate (scaled by sqrt(H/0.25))
    max_level: int = 14           # certificate depth limit
    top_k: int = 5                # bars polished per dataset
    polish_cap: int = 64          # if every bar so far is a PL artifact, polishing continues to this rank
    scan_max_seeds: int = 48      # Newton starts per bar in the ridge scan; at most a quarter go first to the costlier ridge seeds
    chunk: int = 4096             # direct-sum chunk
    quartic_grid_nu: int = 361    # rescaled grid for the quartic cross-check
    core_radius: float = 1.0      # physical radius separating "central" and "tail" bars (descriptive only)
    check_modes: tuple = (8, 4)   # extra adjacencies computed on the same heights


def output_grid(extent, n, H, opt):
    """Odd symmetric grid with the origin as a node and half-width >= sample extent (window lemma)."""
    delta = opt.du * n ** (-1.0 / 6.0)
    half = int(math.ceil(extent / delta)) + 1
    x = delta * np.arange(-half, half + 1, dtype=float)
    return x, delta


def _is_type(r, want, n2):
    """A converged Newton limit of the wanted type, with the Hessian eigenvalues above the rounding allowance n2."""
    if not r["converged"]:
        return False
    if want == "min":
        return r["eig"][0] > n2
    return r["eig"][0] < -n2 and r["eig"][1] > n2


def _newton_typed(field, x0, want, delta, n2=0.0):
    """Newton towards a critical point of the wanted type from the grid node, with shrinking trust radii and nearby seeds."""
    last = None
    for mm in (2.0, 1.0, 0.5, 0.25, 0.125):
        r = newton_to_critical(field, x0, max_move=mm * delta, max_iter=60)
        last = r
        if _is_type(r, want, n2):
            return r
    for k in (1, 2, 4):
        for th in np.arange(8) * (math.pi / 4.0):
            r = newton_to_critical(field, np.asarray(x0) + k * delta * np.array([math.cos(th), math.sin(th)]), max_move=delta, max_iter=60)
            if _is_type(r, want, n2):
                return r
    return last


def _set_endpoint(rec, name, r):
    rec[name + "_x"] = r["x"].tolist()
    rec[name + "_conv"] = r["converged"]
    rec[name + "_eig"] = r["eig"].tolist()
    rec[name + "_moved"] = r["moved"]
    rec[name + "_grad"] = r["grad_norm"]


def _polish_pair(field, i, bars, x, delta, L4fn, al, c0_length_bound):
    """Newton from the (min node, merge node) of one grid bar.  Accepted only as a true (strict min, nondegenerate saddle) pair with a positive
    length inside the C0 bracket of the grid value.  Otherwise the reason is recorded."""
    pb = node_xy(bars["birth"][i:i + 1], x, x)[0]
    pd = node_xy(bars["death"][i:i + 1], x, x)[0]
    rm = _newton_typed(field, pb, "min", delta, al.n2)
    rs = _newton_typed(field, pd, "saddle", delta, al.n2)
    rec = dict(rank=int(i), grid_length=float(bars["length"][i]), min_node=pb.tolist(), merge_node=pd.tolist())
    _set_endpoint(rec, "min", rm)
    _set_endpoint(rec, "saddle", rs)
    is_min, is_saddle = _is_type(rm, "min", al.n2), _is_type(rs, "saddle", al.n2)
    rec["min_type_ok"], rec["saddle_type_ok"] = bool(is_min), bool(is_saddle)
    rec["polished_length"] = None
    if is_saddle:
        rec["saddle_kantorovich"] = kantorovich_saddle(field, rs, L4fn, al)
    if is_min and is_saddle:
        fm, fs = float(field.points(rm["x"][None, :])[0]), float(field.points(rs["x"][None, :])[0])
        rec["f_min"], rec["f_saddle"] = fm, fs
        if fs <= fm:
            rec["polished_status"] = "polished_pair_not_positive"
        elif abs((fs - fm) - rec["grid_length"]) <= c0_length_bound:
            rec["polished_status"] = "ok"
            rec["polished_length"] = fs - fm
        else:
            rec["polished_status"] = "polished_pair_outside_C0_bracket"
    elif rm["converged"] and rs["converged"] and float(np.hypot(*(rm["x"] - rs["x"]))) <= delta and rec["grid_length"] <= c0_length_bound:
        rec["polished_status"] = ARTIFACT
    elif rec["grid_length"] <= c0_length_bound:
        rec["polished_status"] = "below_C0_bound_not_polished"
    else:
        rec["polished_status"] = "grid_pair_did_not_polish_to_min_saddle"
    return rec, rm, rs


def _critical_nodes(F, delta):
    """Grid nodes near a nondegenerate critical point, from central differences of the exact node values: both gradient components change sign within the 3x3 patch and
    the Newton step from the node is short and locally least.  This does not depend on the PL order of the saddles, and it is cheap enough for the whole region of interest,
    which matters because a second gate on the way out can lie far from the bar's own component."""
    gx, gy, a, b, c = (np.zeros(F.shape) for _ in range(5))
    gx[1:-1, :] = (F[2:, :] - F[:-2, :]) / (2.0 * delta)
    gy[:, 1:-1] = (F[:, 2:] - F[:, :-2]) / (2.0 * delta)
    a[1:-1, :] = (F[2:, :] - 2.0 * F[1:-1, :] + F[:-2, :]) / (delta * delta)
    c[:, 1:-1] = (F[:, 2:] - 2.0 * F[:, 1:-1] + F[:, :-2]) / (delta * delta)
    b[1:-1, 1:-1] = (F[2:, 2:] - F[2:, :-2] - F[:-2, 2:] + F[:-2, :-2]) / (4.0 * delta * delta)
    fp = np.ones((3, 3), dtype=bool)
    hit = np.ones(F.shape, dtype=bool)
    for g in (gx, gy):
        hit &= (ndimage.minimum_filter(g, footprint=fp, mode="nearest") <= 0.0) & (ndimage.maximum_filter(g, footprint=fp, mode="nearest") >= 0.0)
    det = a * c - b * b
    with np.errstate(divide="ignore", invalid="ignore"):
        step = np.hypot((c * gx - b * gy) / det, (a * gy - b * gx) / det)
    step[~np.isfinite(step)] = np.inf
    return np.nonzero(hit & (step <= 3.0 * delta) & (step <= ndimage.minimum_filter(step, footprint=fp, mode="nearest")))


def _ridge_seeds(F, x, delta, i0, i1, j0, j1, centre, nth=180):
    """Points where the ridge height around centre is locally least.  On a nearly flat ridge the Newton step from a node is unreliable, because moving off the ridge
    changes the small tangential curvature; the ridge height V(theta)=first local maximum along the ray, from a cubic spline of the node values, still locates the saddles.
    It assumes the component is star-shaped about centre; anywhere that fails, the seed simply yields no valid saddle."""
    coef = ndimage.spline_filter(F[i0:i1 + 1, j0:j1 + 1], order=3, mode="nearest")
    corners = np.array([[x[i0], x[j0]], [x[i0], x[j1]], [x[i1], x[j0]], [x[i1], x[j1]]])
    rmax = float(np.hypot(*(corners - centre).T).max())
    step = 0.5 * delta
    rr = step * np.arange(1, int(rmax / step) + 2)
    th = 2.0 * math.pi * np.arange(nth) / nth
    px = (centre[0] + np.outer(rr, np.cos(th)) - x[i0]) / delta
    py = (centre[1] + np.outer(rr, np.sin(th)) - x[j0]) / delta
    vals = ndimage.map_coordinates(coef, [px.ravel(), py.ravel()], order=3, prefilter=False, mode="nearest").reshape(px.shape)
    peak = (vals[1:-1] >= vals[:-2]) & (vals[1:-1] > vals[2:])
    has = peak.any(axis=0)
    if not has.any():
        return []
    k = np.argmax(peak, axis=0) + 1
    ids = np.arange(nth)
    ya, yb, yc = vals[k - 1, ids], vals[k, ids], vals[k + 1, ids]
    den = ya - 2.0 * yb + yc
    off = np.where(den < 0.0, 0.5 * (ya - yc) / np.where(den < 0.0, den, -1.0), 0.0)
    V = np.where(has, yb - 0.25 * (ya - yc) * off, np.inf)
    R = rr[k] + off * step
    keep = has & (V <= np.roll(V, 1)) & (V <= np.roll(V, -1))
    idx = np.nonzero(keep)[0]
    idx = idx[np.argsort(V[idx])]
    return [np.array([centre[0] + R[m] * math.cos(th[m]), centre[1] + R[m] * math.sin(th[m])]) for m in idx]


def _node_of(p, x, delta):
    last = len(x) - 1
    return int(np.clip(round((p[0] - x[0]) / delta), 0, last)), int(np.clip(round((p[1] - x[0]) / delta), 0, last))


def _side_component(field, F, lab, x, delta, xs, direction, cut, max_steps=600):
    """Where the exact field goes downhill from a saddle on one side: a component label (>0), EXTERIOR at a window-boundary node (window lemma: every kernel keeps falling beyond it),
    the Newton record of the minimum the path ends at, or 0 if it stops anywhere else.
    The path uses exact heights and gradients, not node heights: a bar can be shorter than the local PL error, and then a walk on nodes cannot tell whether it has passed a basin (independent review, M1).
    Its steps are -|D2f|^{-1} grad f: they go downhill at any curvature, double the distance from the saddle and are plain Newton inside a basin.  A step is at most one spacing, or more on a slope,
    up to half of |grad|/|D2f|, inside which there is no critical point, and at most a quarter of the kernel standard deviation.
    A label counts only below the cut and when all nine nearest nodes carry it, so a basin the grid does not resolve still ends at its minimum."""
    nx, ny = F.shape
    f = float(field.points(xs[None, :])[0])
    p = None
    for t in (1.0 / 16.0, 0.125, 0.25, 0.5, 1.0, 2.0):
        q = xs + t * delta * direction
        if float(field.points(q[None, :])[0]) < f:
            p = q
            break
    if p is None:
        return 0
    derivs = [(0, 0)] + JET1 + JET2
    for _ in range(max_steps):
        a, c = _node_of(p, x, delta)
        if a in (0, nx - 1) or c in (0, ny - 1):
            return EXTERIOR
        v = field.points_many(p[None, :], derivs)
        f = float(v[(0, 0)][0])
        if f < cut:
            patch = lab[a - 1:a + 2, c - 1:c + 2]
            if patch[1, 1] > 0 and (patch == patch[1, 1]).all():
                return int(patch[1, 1])
        g = np.array([v[(1, 0)][0], v[(0, 1)][0]])
        w, V = np.linalg.eigh(np.array([[v[(2, 0)][0], v[(1, 1)][0]], [v[(1, 1)][0], v[(0, 2)][0]]]))
        step = -V @ ((V.T @ g) / np.maximum(np.abs(w), 1e-3 * float(np.abs(w).max()) + 1e-300))
        length = float(np.hypot(*step))
        if w[0] > 0.0 and length <= delta / 64.0:
            return newton_to_critical(field, p, max_move=delta, max_iter=20)
        curvature = float(np.abs(w).max())
        cap = max(delta, min(0.25 * math.sqrt(field.H), 0.5 * float(np.hypot(*g)) / curvature)) if curvature > 0.0 else delta
        if length > cap:
            step = step * (cap / length)
        for _ in range(12):
            q = p + step
            if float(field.points(q[None, :])[0]) < f:
                p = q
                break
            step = 0.5 * step
        else:                       # nothing lower at this precision: a minimum, or the path has stalled and Newton will not type it
            return newton_to_critical(field, p, max_move=delta, max_iter=20)
    return 0


def _ending_saddle(edges, value, target, in_order=False):
    """The elder rule on exact heights.  edges: (height, a, b, key), a saddle joining components a and b.  value: the lowest minimum of each component, -inf for the exterior.
    Going up in height, a component that meets an older one dies there.  Returns the key of the saddle that ends target, or None if the edges never end it.
    With in_order=True, edges is an iterable already in order of height.  It is read only as far as needed, and value may grow while it is read."""
    group = {}

    def of(u):
        return group.setdefault(u, {u})

    for h, a, b, key in (edges if in_order else sorted(edges, key=lambda e: e[0])):
        ga, gb = of(a), of(b)
        if ga is gb:
            continue
        gt = of(target)
        if gt is ga or gt is gb:
            other = gb if gt is ga else ga
            if min(value[u] for u in other) < min(value[u] for u in gt):
                return key
        ga |= gb
        for u in gb:
            group[u] = ga
    return None


def _refine_bar(field, rec, rm, rs, birth, death, F, x, delta, c0, al, L4fn, max_seeds, nodes):
    """Decide this bar from exact heights of polished critical points instead of the grid's order of them.

    The grid merges by PL height, and PL errors differ from saddle to saddle, so near-tied saddles can be in the wrong order: the reported saddle can be too high (two exits, the grid takes
    the truly higher one) or too low (two gates in series, whose true height is the larger).  Newton from the merge node can also land on a ridge maximum when the ridge is nearly flat.  So:
    (1) find critical points near the merge level anywhere, and minima in the bar's component, independently of PL heights (_critical_nodes, _ridge_seeds), polish and type them;
    (2) cut below every saddle that could matter, so that the components at the cut are separated by these saddles and not yet by the grid's order; a short bar, whose merge level can lie above its own lowest saddle, is cut below the typed saddles in its box;
    (3) follow the exact field down from each saddle to see which components it joins (_side_component), join them in the order of the exact heights and apply the elder rule (_ending_saddle).
    A minimum the path ends at counts even if no seed found it.
    The minimum is the lowest strict minimum in the bar's component at the merge level.  A failed search leaves the record of _polish_pair unchanged and says so in ridge_scan."""
    nx, ny = F.shape
    ib, jb = divmod(int(birth), ny)
    level = float(F[divmod(int(death), ny)])
    fb = float(F[ib, jb])
    lab_merge, _ = ndimage.label(F < level, structure=_KUHN6)
    lc = int(lab_merge[ib, jb])
    ii, jj = np.nonzero(lab_merge == lc)
    pad = 8 + int(0.25 * max(int(ii.max() - ii.min()), int(jj.max() - jj.min())))
    box = (max(int(ii.min()) - pad, 0), min(int(ii.max()) + pad, nx - 1), max(int(jj.min()) - pad, 0), min(int(jj.max()) + pad, ny - 1))
    band = 5.0 * c0       # a node within two spacings of a saddle is within 8 PL errors of it; a saddle in the bracket is within c0 of the merge level
    ni, nj = nodes
    Fn = F[ni, nj]
    low = np.nonzero((Fn <= fb + band) & (lab_merge[ni, nj] == lc))[0]
    near = np.nonzero(np.abs(Fn - level) <= band)[0]
    near = near[np.argsort(np.abs(Fn[near] - level))]
    centre = rm["x"] if _is_type(rm, "min", al.n2) else np.array([x[ib], x[jb]])
    ridge = _ridge_seeds(F, x, delta, *box, centre)
    # a quarter of the budget goes first to the ridge seeds: on a flat ridge they are the ones that find the saddles.
    # They also get more iterations, because Newton measured by |grad| creeps along a curved flat ridge, so they cost more when they fail.
    as_seed = lambda k: (np.array([x[ni[k]], x[nj[k]]]), 12)
    in_low = set(low.tolist())
    seeds = [as_seed(k) for k in low] + [(p, 40) for p in ridge[:max_seeds // 4]] + [as_seed(k) for k in near if int(k) not in in_low] + [(p, 40) for p in ridge[max_seeds // 4:]]
    scan = dict(box=list(box), node_seeds=int(len(low) + len(near)), seeds=len(seeds), capped=len(seeds) > max_seeds, unconverged=0)

    crit = []

    def absorb(r):
        typ = "min" if _is_type(r, "min", al.n2) else ("saddle" if _is_type(r, "saddle", al.n2) else "other")
        if any(c["type"] == typ and float(np.hypot(*(c["x"] - r["x"]))) <= delta / 64.0 for c in crit):
            return
        c = dict(r)
        c["type"], c["f"] = typ, float(field.points(r["x"][None, :])[0])
        crit.append(c)

    for r in (rm, rs):
        if r["converged"]:
            absorb(r)
    for p, iters in seeds[:max_seeds]:
        r = newton_to_critical(field, p, max_move=2.0 * delta, max_iter=iters)
        if r["converged"]:
            absorb(r)
        else:
            scan["unconverged"] += 1

    def in_merge_component(c):
        i, j = _node_of(c["x"], x, delta)
        return bool(np.any(lab_merge[max(i - 1, 0):i + 2, max(j - 1, 0):j + 2] == lc))

    all_mins = [c for c in crit if c["type"] == "min"]
    saddles = [c for c in crit if c["type"] == "saddle"]
    mins = [c for c in all_mins if in_merge_component(c)]
    scan.update(n_min=len(mins), n_saddle=len(saddles), n_critical=len(crit))
    rec["ridge_scan"] = scan
    if not mins:
        scan["outcome"] = "no_typed_minimum"
        return
    fmin = min(mins, key=lambda c: c["f"])

    # components at a level below every saddle that could end this bar, with at least half of the bar left under the cut.
    # A bar under 4 c0 is cut at the midpoint of the grid's merge level, which can lie above its true lowest saddle when the PL error exceeds the bar; so go below the typed saddles in its box as well.
    cut = max(level - 2.0 * c0, 0.5 * (fmin["f"] + level))
    if cut > level - 2.0 * c0:
        in_box = [c["f"] for c in saddles if c["f"] > fmin["f"] and box[0] <= _node_of(c["x"], x, delta)[0] <= box[1] and box[2] <= _node_of(c["x"], x, delta)[1] <= box[3]]
        if in_box:
            cut = min(cut, 0.5 * (fmin["f"] + min(in_box)))
    lab, _ = ndimage.label(F < cut, structure=_KUHN6)
    exterior = set(np.unique(np.concatenate([lab[0, :], lab[-1, :], lab[:, 0], lab[:, -1]])).tolist()) - {0}
    component_of_min = {}

    def min_component(k):
        """The component at the cut that holds this minimum: the lowest labelled node next to it that the straight segment joins to it below the cut, in exact heights.
        Otherwise the minimum is its own component, -(k+1): in a bar shorter than the PL error a node of the next component can be one spacing away."""
        if k not in component_of_min:
            p = all_mins[k]["x"]
            i, j = _node_of(p, x, delta)
            out = -(k + 1)
            if all_mins[k]["f"] < cut:
                cand = [(F[a, b], a, b) for a in range(max(i - 1, 0), min(i + 2, nx)) for b in range(max(j - 1, 0), min(j + 2, ny)) if lab[a, b]]
                for _, a, b in sorted(cand):
                    segment = p + np.outer(np.linspace(0.0, 1.0, 7)[1:-1], np.array([x[a], x[b]]) - p)
                    if float(field.points(segment).max()) < cut:
                        out = int(lab[a, b])
                        break
            component_of_min[k] = out
        return component_of_min[k]

    value = {}
    for k, c in enumerate(all_mins):
        u = min_component(k)
        if u not in exterior:
            value[u] = min(value.get(u, math.inf), c["f"])
    value[EXTERIOR] = -math.inf
    target = min_component(next(k for k, c in enumerate(all_mins) if c is fmin))

    def as_id(u):
        return EXTERIOR if u in exterior else u

    def side_id(c, direction):
        out = _side_component(field, F, lab, x, delta, c["x"], direction, cut)
        if not isinstance(out, dict):
            return as_id(out)
        if not _is_type(out, "min", al.n2):
            return 0
        k = next((k for k, m in enumerate(all_mins) if float(np.hypot(*(m["x"] - out["x"]))) <= delta / 64.0), None)
        if k is None:               # a minimum that no seed found: the path has reached it, so it is one
            m = dict(out)
            m["type"], m["f"] = "min", float(field.points(out["x"][None, :])[0])
            all_mins.append(m)
            k = len(all_mins) - 1
            u = min_component(k)
            if u not in exterior:
                value[u] = min(value.get(u, math.inf), m["f"])
            scan["minima_found_by_descent"] = scan.get("minima_found_by_descent", 0) + 1
            if m["f"] < fmin["f"] and in_merge_component(m):
                scan["lower_minimum"] = True
        return as_id(min_component(k))

    rejected = {}
    unresolved_heights = []         # saddles whose sides could not be followed: if one lies below the ending saddle, the pairing is not confirmed (task 57, N1)
    scan.update(n_edges=0, rejected=rejected)

    def label_value(u):
        if u not in value:          # a component at the cut with no typed minimum
            value[u] = float(F[lab == u].min())

    def edges_by_height():
        """The saddles in order of height, each with the components its two sides reach.  This is read only until the bar ends, because the paths are the costly part."""
        for idx in sorted(range(len(saddles)), key=lambda k: saddles[k]["f"]):
            c = saddles[idx]
            if c["f"] <= fmin["f"] or c["f"] < cut - c0 or c["f"] > level + c0:
                rejected["out_of_band"] = rejected.get("out_of_band", 0) + 1
                continue
            e = np.linalg.eigh(c["H"])[1][:, 0]
            a, b = side_id(c, e), side_id(c, -e)
            if a == 0 or b == 0:
                rejected["side_unresolved"] = rejected.get("side_unresolved", 0) + 1
                unresolved_heights.append(c["f"])
            elif a == b:
                rejected["same_component"] = rejected.get("same_component", 0) + 1
            else:
                label_value(a)
                label_value(b)
                scan["n_edges"] += 1
                yield c["f"], a, b, idx

    if target in exterior:          # the minimum reaches the exterior below the cut: the search has nothing to decide
        scan["outcome"] = "no_ending_saddle"
        return
    label_value(target)
    key = _ending_saddle(edges_by_height(), value, target, in_order=True)
    if scan.get("lower_minimum"):   # fmin is not the lowest minimum of this component after all, so this search answered the wrong question
        scan["outcome"] = "lower_minimum_found_by_descent"
        return
    if key is None:
        scan["outcome"] = "no_ending_saddle"
        return
    best = saddles[key]
    if abs((best["f"] - fmin["f"]) - rec["grid_length"]) > c0:
        scan["outcome"] = "ending_saddle_outside_C0_bracket"
        return
    near_heights = sorted(c["f"] for c in saddles if abs(c["f"] - best["f"]) <= c0)
    scan.update(saddle_heights_within_C0=near_heights[:8], n_saddles_within_C0=len(near_heights))
    lower_unresolved = sum(h < best["f"] for h in unresolved_heights)
    scan["lower_saddles_unresolved"] = int(lower_unresolved)
    rec["pairing"] = "unconfirmed_lower_saddle_unresolved" if lower_unresolved else "consistent_with_search"
    first = rec["polished_length"]
    was_ok = rec["polished_status"] == "ok"
    if first is not None:
        rec["first_polished_length"] = first
    _set_endpoint(rec, "min", fmin)
    _set_endpoint(rec, "saddle", best)
    rec["min_type_ok"], rec["saddle_type_ok"] = True, True
    rec["f_min"], rec["f_saddle"] = fmin["f"], best["f"]
    rec["saddle_kantorovich"] = kantorovich_saddle(field, best, L4fn, al)
    rec["polished_length"] = best["f"] - fmin["f"]
    rec["polished_status"] = "ok" if was_ok else "ok_after_ridge_scan"
    scan["outcome"] = "unchanged" if (first is not None and rec["polished_length"] == first) else ("changed" if first is not None else "polished_by_scan")


def _polish_bars(field, bars, x, F, top_k, cap, delta, L4fn, c0_length_bound, max_seeds):
    """Polish the top_k longest grid bars.  If all of them are PL artifacts, continue down the list, since a real but shorter bar can rank below them.
    The polished bars within 2 c0 of the top go through _refine_bar.  A bar below rank top_k is not polished even inside that bracket, so with more than top_k bars inside the local PL error of the top the longest can be missed (independent review, M4)."""
    al = Allowances(field)
    total = len(bars["length"])
    out, raw = [], []
    i = 0
    while i < total and (i < top_k or (i < cap and all(r["polished_status"] == ARTIFACT for r in out))):
        rec, rm, rs = _polish_pair(field, i, bars, x, delta, L4fn, al, c0_length_bound)
        out.append(rec)
        raw.append((rm, rs))
        i += 1
    real = [k for k, r in enumerate(out) if r["polished_status"] != ARTIFACT]
    if real:
        top = max(out[k]["grid_length"] for k in real)
        lead = [k for k in real if out[k]["grid_length"] >= top - 2.0 * c0_length_bound]
        # the region of interest ends where the field drops below every minimum of these bars
        floor = min(float(F.ravel()[bars["birth"][k]]) for k in lead) - 5.0 * c0_length_bound
        ii, jj = np.nonzero(F >= floor)
        i0, i1, j0, j1 = max(int(ii.min()) - 2, 0), min(int(ii.max()) + 2, F.shape[0] - 1), max(int(jj.min()) - 2, 0), min(int(jj.max()) + 2, F.shape[1] - 1)
        ni, nj = _critical_nodes(F[i0:i1 + 1, j0:j1 + 1], delta)
        nodes = (ni + i0, nj + j0)
        for k in lead:
            try:
                _refine_bar(field, out[k], raw[k][0], raw[k][1], bars["birth"][k], bars["death"][k], F, x, delta, c0_length_bound, al, L4fn, max_seeds, nodes)
            except Exception as exc:     # the search only refines: its failure keeps the row's grid value and certificate, and it is flagged, not hidden
                out[k]["ridge_scan"] = dict(outcome="exception", error="%s: %s" % (type(exc).__name__, exc))
    return out


def _c0_budget(field, x, F, delta, d0, L4fn, al=None):
    """Per-square bound of ||D^2 fhat||_op on a coarse cover of the whole output window: Taylor about the square centre c,
    ||D2(c)|| + n2 + rho (||D3(c)||_F + n3) + rho^2/2 L4, with the rounding/aliasing/wrap allowances n2, n3 of Allowances (empirical) added to the
    computed derivatives.  al=None gives the version without allowances, kept only for comparison in the tests."""
    xs = np.arange(x[0] + d0 / 2.0, x[-1] + d0 / 2.0, d0)      # the last square reaches x[-1]
    derivs = JET2 + JET3 + [(0, 0), (1, 0), (0, 1)]
    v = field.tensor_many(xs, xs, derivs)
    XX, YY = np.meshgrid(xs, xs, indexing="ij")
    pts = np.column_stack([XX.ravel(), YY.ravel()])
    rho = d0 / math.sqrt(2.0)
    L4v = L4fn(pts).reshape(XX.shape)
    lmin, lmax = _hess_eigs(v[(2, 0)], v[(1, 1)], v[(0, 2)])
    n2 = al.n2 if al is not None else 0.0
    n3 = al.n3 if al is not None else 0.0
    Hop = np.maximum(np.abs(lmin), np.abs(lmax)) + n2
    Tf = _t_frob(v[(3, 0)], v[(2, 1)], v[(1, 2)], v[(0, 3)]) + n3
    sup = Hop + rho * Tf + 0.5 * rho * rho * L4v
    gnorm = np.hypot(v[(1, 0)], v[(0, 1)])
    osc = rho * gnorm + 0.5 * rho * rho * sup     # |f(x)-f(c)| <= osc on the square
    return dict(sup_d2_global=float(sup.max()), fields=dict(sup=sup, f=v[(0, 0)], osc=osc, xs=xs), rho=rho, n2=n2, n3=n3,
                parts_at_max=dict(hessian_with_n2=float(Hop.ravel()[int(np.argmax(sup))]), third_with_n3=float(Tf.ravel()[int(np.argmax(sup))]), L4=float(L4v.ravel()[int(np.argmax(sup))])))


def node_error_bound(field):
    """eta_node: bound used for |computed node height - fhat(node)|: calibrated rounding allowance plus the aliasing and wrap bounds (empirical, Accelerate)."""
    return float(field.noise_allowance((0, 0)) + field.meta["aliasing_bound"]["0"] + field.meta["wrap_bound"]["0"])


def numerical_budget(bud, delta, d0, eta_node, noise_floor, n):
    """B_total = 2 (delta^2/4) M_bound + 2 eta_node + noise_floor, each term for a different effect:
    the PL interpolation of exact node values (M_bound from _c0_budget, Kuhn right triangles of leg delta), the computed node heights (a uniform
    perturbation of size eta moves every bar end by at most eta), and the bars dropped at noise_floor (they can only remove a longest bar no longer
    than the floor).  Conditional on M_bound and eta_node holding; both rest on empirically calibrated allowances, so this is not a certificate."""
    M = float(bud["sup_d2_global"])
    pl = 2.0 * (delta * delta / 4.0) * M
    node = 2.0 * eta_node
    total = pl + node + noise_floor
    scale = n ** (2.0 / 3.0)
    return dict(kind=BUDGET_KIND,
                formula="B_total = 2*(delta^2/4)*M_bound + 2*eta_node + noise_floor",
                function="fhat_n, the full-sample Gaussian KDE (every observation, no binning or truncation); M_bound bounds ||D^2 fhat_n||_op",
                region="the output window [-W, W]^2, which contains every observation (window lemma), covered by squares of side d0 centred at the cover points",
                delta=delta, d0=d0, rho=bud["rho"], M_bound=M, n2_added=bud["n2"], n3_added=bud["n3"], parts_at_max=bud["parts_at_max"],
                eta_node=eta_node, pl_interpolation=pl, node_term=node, noise_floor=noise_floor, B_total=total,
                rescaled=dict(pl_interpolation=pl * scale, node_term=node * scale, noise_floor=noise_floor * scale, B_total=total * scale),
                assumptions=["M_bound bounds the Hessian operator norm of fhat on the window: Taylor from the cover centres with the computed D2 and D3 plus "
                             "the allowances n2, n3 and the L4 tile bound; the allowances are calibrated by measurement on Apple Accelerate, not proved",
                             "eta_node bounds the error of each computed node height: calibrated rounding allowance plus aliasing and wrap bounds",
                             "linear interpolation on Kuhn right triangles of leg delta has error at most (delta^2/4) M_bound; persistence stability doubles a sup error",
                             "every bounded sublevel component lies inside the window (window lemma), so the window boundary acts as the exterior"])


def _drop_noise(bars, floor):
    """Bars at the rounding level of the spectral evaluation are not bars of the estimator; count them, do not report them."""
    keep = bars["length"] > floor
    out = dict(bars)
    out["birth"], out["death"], out["length"] = bars["birth"][keep], bars["death"][keep], bars["length"][keep]
    out["n_noise"] = int((~keep).sum())
    return out


def _quartic_value(G, M, b, nu):
    """Algebraic longest bar; grid value only if the algebra cannot certify its critical set (recorded in the source tag)."""
    a = bar_algebraic(G, M, b)
    if a["L"] is not None:
        return dict(L=a["L"], source=a["status"])
    g = bar_grid(G, M, b, nu=nu)
    return dict(L=g["L"], source="grid_after_" + a["status"], c0_bound=g["c0_bound"])


def analyze_dataset(X, model: Model, n=None, s=None, eps=None, opt: NumericOptions = NumericOptions(), certify=True, want_debug=False):
    """Full record for one dataset.  X is never modified or binned; every observation contributes to every quantity."""
    t_start = time.perf_counter()
    timings = {}
    row = dict(schema=SCHEMA, engine=ENGINE_VERSION, status="ok", error=None, options=asdict(opt))
    try:
        X = np.asarray(X, dtype=float)
        if X.ndim != 2 or X.shape[1] != 2:
            raise ValueError("X must be n x 2")
        if not np.isfinite(X).all():
            raise ValueError("non-finite observation")
        n = int(len(X)) if n is None else int(n)
        if n != len(X):
            raise ValueError("n mismatch with number of observations")
        if eps is None and s is not None:
            eps = model.eps_of(n, s)
        if s is None and eps is not None:
            s = model.s_of(n, eps)
        row.update(n=n, s=None if s is None else float(s), eps=None if eps is None else float(eps), q=model.q, H=model.H,
                   e=model.e, a=model.a, b=model.b, sigma_g=model.sigma_g)
        H = model.H
        sd = math.sqrt(H)
        extent = float(np.abs(X).max())
        row["extent"] = extent
        row["R_max"] = float(np.sqrt(np.sum(X * X, axis=1)).max())

        # ---------------------------- exact estimator ------------------------------------------------------------
        t0 = time.perf_counter()
        field = kde_field(X, H, delta_target=opt.delta_coarse_sd * sd, pad=opt.pad_sd * sd, chunk=opt.chunk)
        timings["kde_direct_nodes"] = time.perf_counter() - t0
        row["kde"] = {k: field.meta[k] for k in ("W_p", "N", "Delta", "aliasing_bound", "wrap_bound", "nyquist_mass", "input_points_kept", "input_points_dropped")}

        # ---------------------------- output grid and discrete persistence ------------------------------------------
        t0 = time.perf_counter()
        x, delta = output_grid(extent, n, H, opt)
        F = field.tensor(x, x)
        timings["fine_grid"] = time.perf_counter() - t0
        row["grid"] = dict(delta=delta, du=opt.du, N=int(len(x)), W=float(x[-1]), nodes=int(len(x) ** 2))
        t0 = time.perf_counter()
        order = sort_order(F)
        eta_node = node_error_bound(field)
        noise_floor = 4.0 * eta_node
        bars_raw = bars_c(F, 6, order)
        bars6 = _drop_noise(bars_raw, noise_floor)
        scale = n ** (2.0 / 3.0)
        # the primary statistic: raw maximum, the filter, and the filtered value are all kept so that the filtering can be checked
        row["L_PL6_raw"] = longest(bars_raw)
        row["noise_floor"] = noise_floor
        row["L_PL6_filtered"] = longest(bars6)
        row["L_primary"] = row["L_PL6_filtered"]
        row["primary_definition"] = PRIMARY_DEFINITION
        row["rescaled_L_PL6_raw"] = row["L_PL6_raw"] * scale
        row["rescaled_noise_floor"] = noise_floor * scale
        row["rescaled_L_primary"] = row["L_primary"] * scale
        if len(bars6["length"]):
            bxy = node_xy(bars6["birth"][:1], x, x)[0]
            row["primary_bar_birth_xy"] = bxy.tolist()
            row["primary_bar_location"] = "central" if float(np.hypot(*bxy)) <= opt.core_radius else "tail"
        else:
            row["primary_bar_birth_xy"], row["primary_bar_location"] = None, None
        row["n_bars_PL6"] = int(len(bars6["length"]))
        row["n_bars_PL6_noise_dropped"] = bars6["n_noise"]
        row["zero_pairs_PL6"] = bars6["zero_pairs"]
        for m in opt.check_modes:
            b = _drop_noise(bars_c(F, m, order), noise_floor)
            row["L_mode%d" % m] = longest(b)
            row["n_bars_mode%d" % m] = int(len(b["length"]))
        timings["persistence"] = time.perf_counter() - t0

        # ---------------------------- envelopes, budget, certificate -----------------------------------------------------
        t0 = time.perf_counter()
        d0 = opt.d0 * sd / 0.5
        L4fn = L4Field(X, H, float(x[-1]), tau=0.25 * sd, rho=d0 / math.sqrt(2.0))
        bud = _c0_budget(field, x, F, delta, d0, L4fn, Allowances(field))
        row["numerical_budget"] = numerical_budget(bud, delta, d0, eta_node, noise_floor, n)
        sup_global = bud["sup_d2_global"]
        eps_glob = (delta * delta / 4.0) * sup_global
        # the PL-interpolation term of the budget; the diagnostic search also uses it as its bracket
        row["c0"] = dict(sup_d2_global=sup_global, pl_error_global=eps_glob, length_bound_global=2.0 * eps_glob,
                         rescaled_length_bound_global=2.0 * eps_glob * scale, note="pl_interpolation term of numerical_budget; bracket of the diagnostic search")
        timings["c0_budget"] = time.perf_counter() - t0

        # ---------------------------- polish the leading bars ------------------------------------------------------------
        t0 = time.perf_counter()
        polished = _polish_bars(field, bars6, x, F, opt.top_k, opt.polish_cap, delta, L4fn, row["c0"]["length_bound_global"] + noise_floor, opt.scan_max_seeds)
        row["top_bars"] = polished
        row["n_bars_polished"] = len(polished)
        L_pol = None
        polish_status = polished[0]["polished_status"] if polished else "no_grid_bar"
        with_length = [p for p in polished if p["polished_length"] is not None]
        lead = max(with_length, key=lambda p: p["polished_length"]) if with_length else None
        if lead is not None:
            pp = lead
            L_pol = pp["polished_length"]
            # direct-sum verification of the leading bar on the same sample (difference of kernel sums reduces rounding)
            pm, ps = np.array(pp["min_x"]), np.array(pp["saddle_x"])
            dirv = direct_points(np.vstack([pm, ps]), X, H)
            pp["f_min_direct"], pp["f_saddle_direct"] = float(dirv[0]), float(dirv[1])
            pp["polished_length_direct"] = float(dirv[1] - dirv[0])
            pp["spectral_minus_direct"] = float(pp["polished_length"] - pp["polished_length_direct"])
            gd = [direct_points(np.vstack([pm, ps]), X, H, deriv=d) for d in ((1, 0), (0, 1))]
            pp["direct_grad_min"] = float(np.hypot(gd[0][0], gd[1][0]))
            pp["direct_grad_saddle"] = float(np.hypot(gd[0][1], gd[1][1]))
            # level-restricted C0 budget.  It brackets this bar's endpoints only, not the statistic: another bar keeps the global error.
            lo, hi = min(pp["f_min"], pp["f_saddle"]), max(pp["f_min"], pp["f_saddle"])
            fv, sup, osc = bud["fields"]["f"], bud["fields"]["sup"], bud["fields"]["osc"]
            band = (fv + osc >= lo - eps_glob) & (fv - osc <= hi + eps_glob)
            eps_band = (delta * delta / 4.0) * float(sup[band].max()) if band.any() else eps_glob
            pp["length_bound_band_this_bar"] = 2.0 * eps_band
            pp["rescaled_length_bound_band_this_bar"] = 2.0 * eps_band * scale
        row["L_polished"] = L_pol
        row["polish_status"] = polish_status
        # L_polished_diagnostic: the heuristic search's value (v1 called it L_num).  A diagnostic only: the primary statistic never depends on it.
        # A bar whose search accepted an exit while a lower saddle stayed unresolved is labelled unconfirmed (task 57, N1).
        cand = [(p["polished_length"] if p["polished_length"] is not None else p["grid_length"], p["polished_length"] is not None, p.get("pairing"))
                for p in polished if p["polished_status"] != ARTIFACT]
        if cand:
            best = max(cand, key=lambda t: t[0])
            src = "grid_PL6_only" if not best[1] else ("polished_unconfirmed" if best[2] == "unconfirmed_lower_saddle_unresolved" else "polished_critical_values")
            row["L_polished_diagnostic"], row["L_polished_diagnostic_source"] = best[0], src
        elif len(bars6["length"]):
            row["L_polished_diagnostic"], row["L_polished_diagnostic_source"] = row["L_PL6_filtered"], "grid_PL6_all_polished_bars_artifact"
        else:
            row["L_polished_diagnostic"], row["L_polished_diagnostic_source"] = 0.0, "no_grid_bar"
        row["rescaled_L_polished_diagnostic"] = row["L_polished_diagnostic"] * scale
        gap = abs(row["L_polished_diagnostic"] - row["L_primary"])
        # an interval centred on the diagnostic value needs the budget plus the actual displacement from the primary value (task 57, R1.4)
        row["diagnostic_interval_radius"] = row["numerical_budget"]["B_total"] + gap
        row["rescaled_diagnostic_interval_radius"] = row["diagnostic_interval_radius"] * scale
        row["bar_lengths_rescaled_top20"] = (bars6["length"][:20] * scale).tolist()
        row["bar_min_radius_top20"] = np.hypot(*node_xy(bars6["birth"][:20], x, x).T).tolist() if len(bars6["length"]) else []
        if lead is not None:
            mx = np.array(lead["min_x"])
            row["diagnostic_min_radius"] = float(np.hypot(*mx))
            row["diagnostic_bar_location"] = "central" if row["diagnostic_min_radius"] <= opt.core_radius else "tail"
        else:
            row["diagnostic_min_radius"] = None
            row["diagnostic_bar_location"] = None
        # descriptive central/tail split over all grid bars
        pos = node_xy(bars6["birth"], x, x) if len(bars6["length"]) else np.zeros((0, 2))
        rad = np.hypot(pos[:, 0], pos[:, 1]) if len(pos) else np.zeros(0)
        central = bars6["length"][rad <= opt.core_radius] if len(pos) else np.zeros(0)
        tail = bars6["length"][rad > opt.core_radius] if len(pos) else np.zeros(0)
        row["L_PL6_central"] = float(central.max()) if len(central) else 0.0
        row["L_PL6_tail"] = float(tail.max()) if len(tail) else 0.0
        row["n_bars_central"], row["n_bars_tail"] = int(len(central)), int(len(tail))
        timings["polish"] = time.perf_counter() - t0

        if certify:
            t0 = time.perf_counter()
            eqs, lo_, hi_ = hull_equations(X)
            cert = certify_minima(field, eqs, lo_, hi_, L4fn, d0=d0, max_level=opt.max_level)
            cert_slim = {k: cert[k] for k in ("status", "n_minima", "final_unresolved", "levels", "cells_level0", "evaluations", "allowances")}
            cert_slim["minima"] = [dict(x=m["x"], lambda_min=m["lambda_min"], lambda_eff=m.get("lambda_eff"), radius=m["radius"]) for m in cert["minima"]]
            row["minimum_search"] = cert_slim
            row["minimum_diagnostic_v1_name"] = cert["status"]
            # a floating-point diagnostic.  It never changes L_primary: a NO_MIN_FOUND_FLOAT row keeps its PL value (task 57, R1.2).
            row["minimum_diagnostic"] = MIN_DIAGNOSTIC_NAMES[cert["status"]]
            timings["minimum_search"] = time.perf_counter() - t0
        else:
            row["minimum_search"] = None
            row["minimum_diagnostic_v1_name"] = "NOT_RUN"
            row["minimum_diagnostic"] = "NOT_RUN"

        # ---------------------------- same-sample jets and comparison models -----------------------------------------------
        t0 = time.perf_counter()
        jet = origin_jet(X, H)
        Gn = math.sqrt(n) * jet["grad"]
        Mn = 0.5 * n ** (1.0 / 3.0) * jet["hess"]
        row["G_n"] = Gn.tolist()
        row["G_norm"] = float(np.hypot(*Gn))
        row["M_n"] = [Mn[0, 0], Mn[0, 1], Mn[1, 1]]
        ev = np.linalg.eigvalsh(Mn)
        row["M_eigs"] = ev.tolist()
        row["M_trace_half"] = float(0.5 * (Mn[0, 0] + Mn[1, 1]))
        row["M_aniso_diff"] = float(0.5 * (Mn[0, 0] - Mn[1, 1]))
        row["M_aniso_off"] = float(Mn[0, 1])
        row["M_aniso_norm"] = float(np.hypot(row["M_aniso_diff"], row["M_aniso_off"]))
        if row["G_norm"] > 0.0:
            eg = Gn / row["G_norm"]
            row["M_along_G"] = float(eg @ Mn @ eg)
            row["M_along_G_status"] = "ok"
        else:
            row["M_along_G"] = None
            row["M_along_G_status"] = "undefined_G_zero"
        row["Ubar"], row["Vbar"], row["f0"] = jet["Ubar"], jet["Vbar"], jet["f0"]
        if eps is not None:
            alpha = model.alpha_eps(eps)
            row["alpha_eps"] = alpha
            row["pop_quadratic_rescaled"] = n ** (1.0 / 3.0) * alpha
            row["M_trace_half_centered"] = row["M_trace_half"] - row["pop_quadratic_rescaled"]
            row["U_leading"] = model.a * s if s is not None else None
            row["beta_eps"] = model.beta_eps(eps)
        if s is not None:
            row["Psi_leading"] = model.Psi(s, Gn)
        q2 = quartic_bar(Gn, Mn, model.b, grid_nu=opt.quartic_grid_nu)
        row["Qtilde"] = q2
        row["L_Qtilde"] = q2["L"] if q2["L"] is not None else None
        row["L_Qtrace"] = psi_ray(row["M_trace_half"], model.b, row["G_norm"])     # diagnostic: trace part of M_n alone
        if eps is not None and s is not None:
            # preregistered decomposition diagnostics; the primary comparison is Psi_leading versus L_Qtilde
            Mc = Mn + (model.a * s - row["pop_quadratic_rescaled"]) * np.eye(2)     # random curvature only, deterministic drift removed
            row["L_Qcentered"] = _quartic_value(Gn, Mc, model.b, opt.quartic_grid_nu)
            b_eps = -model.beta_eps(eps)
            row["b_eps"] = b_eps
            row["L_Qbeta"] = _quartic_value(Gn, Mn, b_eps, opt.quartic_grid_nu) if b_eps > 0 else dict(L=None, source="b_eps_nonpositive")
            row["pop_bar_rescaled"] = model.pop_bar(eps) * scale
        timings["jets_and_models"] = time.perf_counter() - t0

        # ---------------------------- flags: primary, diagnostic, comparator kept apart -----------------------------------
        primary_flags, diagnostic_flags, comparator_flags = [], [], []
        B = row["numerical_budget"]["B_total"]
        Lv, Lp, Lt = row.get("L_mode8", 0.0), row["L_PL6_filtered"], row.get("L_mode4", 0.0)
        if not (Lv <= Lp + noise_floor and Lp <= Lt + noise_floor):
            primary_flags.append("adjacency_monotonicity_violated")
        if not math.isfinite(B):
            primary_flags.append("budget_not_finite")
        if row["L_PL6_raw"] > 0.0 and row["L_primary"] == 0.0:
            primary_flags.append("raw_bar_below_noise_floor_dropped")
        if row["L_primary"] > 0.0 and row["L_primary"] <= B:
            primary_flags.append("primary_within_budget_of_zero")
        if abs(row["L_polished_diagnostic"] - row["L_primary"]) > B:
            diagnostic_flags.append("polished_outside_budget")
        md = row["minimum_diagnostic"]
        if md == "NO_MIN_FOUND_FLOAT" and row["L_primary"] > B:
            diagnostic_flags.append("no_min_found_float_but_primary_above_budget")
        if md == "MIN_FOUND_FLOAT" and row["L_primary"] == 0.0:
            diagnostic_flags.append("min_found_float_but_primary_zero")
        if md == "UNDETERMINED_FLOAT" and row["L_primary"] == 0.0:
            diagnostic_flags.append("primary_zero_minimum_undetermined")
        if row["L_polished_diagnostic_source"] == "grid_PL6_all_polished_bars_artifact" and row["n_bars_polished"] < row["n_bars_PL6"]:
            diagnostic_flags.append("polish_cap_reached_all_artifact")
        # over every bar the search ran on, not only the row's lead: a bar whose search failed can still be the longest (independent review, M3)
        notes = []
        scans = [p["ridge_scan"] for p in polished if "ridge_scan" in p]
        row["n_scans_failed"] = sum(sc.get("outcome") in SCAN_FAILED for sc in scans)
        if row["n_scans_failed"]:
            diagnostic_flags.append("leading_saddle_pairing_unverified")
        row["n_pairings_unconfirmed"] = sum(p.get("pairing") == "unconfirmed_lower_saddle_unresolved" for p in polished)
        if row["n_pairings_unconfirmed"]:
            diagnostic_flags.append("pairing_unconfirmed_lower_saddle_unresolved")
        if any(sc.get("n_saddles_within_C0", 0) > 1 for sc in scans):
            notes.append("several_saddles_within_C0")
        if any(sc.get("capped") for sc in scans):
            notes.append("ridge_scan_seed_cap_reached")
        row["scan_notes"] = notes
        if q2["L"] is None:
            comparator_flags.append("quartic_algebraic_unresolved")
        elif not q2["agree"]:
            comparator_flags.append("quartic_algebraic_grid_mismatch")
        row["primary_flags"], row["diagnostic_flags"], row["comparator_flags"] = primary_flags, diagnostic_flags, comparator_flags
    except Exception as exc:  # explicit failure record; the caller must never treat this as L=0
        row["status"] = "error"
        row["error"] = "%s: %s" % (type(exc).__name__, exc)
        row["traceback"] = traceback.format_exc(limit=6)
        row["L_primary"] = None
        row["rescaled_L_primary"] = None
        row["L_polished_diagnostic"] = None
        row["minimum_diagnostic"] = "ERROR"
    timings["total"] = time.perf_counter() - t_start
    row["timings"] = timings
    if want_debug and row["status"] == "ok":
        return row, dict(field=field, x=x, F=F, bars=bars6)
    return row
