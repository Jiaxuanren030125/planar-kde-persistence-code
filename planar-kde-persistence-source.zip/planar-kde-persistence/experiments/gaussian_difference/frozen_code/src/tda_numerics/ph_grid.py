"""Grid persistence: compiled union-find (primary) and a pure-Python twin (cross-check/fallback).

See ph_core.c for the exact discrete object.  Relation to the continuous statistic:

  (window lemma) If [-W,W]^2 contains every observation, then along the outward normal at any boundary point every kernel
  decreases strictly, so a component of the strict sublevel set {fhat<c} that meets the boundary is unbounded.  Bounded
  components of {fhat<c} therefore lie inside the open square (an unbounded component may also miss the square entirely, so "does not
  meet the boundary" alone would not characterize them).  On the window this is what the virtual exterior vertex encodes.  By Alexander
  duality (paper, Appendix B) these components correspond to the H1 bars of the closed superlevel filtration: birth at the merge height S
  (a saddle), death at the component minimum m, length S-m.

  (stability) With mode 6 the object is the lower-star persistence of the PL interpolant g of fhat on a Kuhn triangulation,
  rel the boundary.  Then |L(fhat)-L(g)| <= 2 ||fhat-g||_inf on the window, and ||fhat-g||_inf <= (delta^2/4) sup||D^2 fhat||.

  (monotonicity) More edges merge components earlier, so L_mode8 <= L_mode6 <= L_mode4 on the same node heights, and the
  same inclusions hold for the events {L>0}.  This brackets the choices made by earlier scripts.
"""
from __future__ import annotations

import ctypes
import hashlib
import subprocess
from pathlib import Path

import numpy as np

_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parent.parent          # preflight_v1
_SRC = _HERE / "ph_core.c"
_BUILD = _ROOT / "build"
COMPILE_FLAGS = ["-O2", "-std=c11", "-shared", "-fPIC", "-Wall", "-Wextra"]


def c_source_sha256():
    return hashlib.sha256(_SRC.read_bytes()).hexdigest()


def _lib_path():
    return _BUILD / ("libphcore_%s.dylib" % c_source_sha256()[:16])


def build_library():
    _BUILD.mkdir(exist_ok=True)
    lib = _lib_path()
    if not lib.exists():
        cmd = ["clang"] + COMPILE_FLAGS + ["-o", str(lib), str(_SRC)]
        subprocess.run(cmd, check=True)
    return lib


def build_info():
    """Compiler identity and library hash, for run provenance."""
    lib = build_library()
    cc = subprocess.run(["clang", "--version"], check=True, capture_output=True, text=True).stdout.splitlines()[0]
    return dict(compiler=cc, flags=COMPILE_FLAGS, library=lib.name, library_sha256=hashlib.sha256(lib.read_bytes()).hexdigest())


_lib = None


def _load():
    global _lib
    if _lib is None:
        lib = ctypes.CDLL(str(build_library()))
        lib.uf_bars.restype = ctypes.c_int64
        lib.uf_bars.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int64, ctypes.c_int64, ctypes.c_int,
                                ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int64, ctypes.c_void_p]
        _lib = lib
    return _lib


def sort_order(F):
    """Total order on vertices: (height, flat index)."""
    flat = F.ravel()
    return np.lexsort((np.arange(flat.size, dtype=np.int64), flat)).astype(np.int64)


def bars_c(F, mode=6, order=None):
    """All positive bars of the grid sublevel filtration with exterior. Returns dict(birth, death, length, zero_pairs)."""
    F = np.ascontiguousarray(F, dtype=np.float64)
    if not np.isfinite(F).all():
        raise ValueError("non-finite grid height")
    nx, ny = F.shape
    if order is None:
        order = sort_order(F)
    cap = int(min(F.size, 1 << 22))
    birth = np.empty(cap, dtype=np.int64)
    death = np.empty(cap, dtype=np.int64)
    zero = ctypes.c_int64(0)
    k = _load().uf_bars(F.ctypes.data, order.ctypes.data, nx, ny, int(mode), birth.ctypes.data, death.ctypes.data, cap,
                        ctypes.byref(zero))
    if k < 0:
        raise RuntimeError("uf_bars failed with code %d" % k)
    birth, death = birth[:k].copy(), death[:k].copy()
    flat = F.ravel()
    length = flat[death] - flat[birth]
    idx = np.lexsort((birth, -length))
    return dict(birth=birth[idx], death=death[idx], length=length[idx], zero_pairs=int(zero.value), mode=int(mode))


def bars_py(F, mode=6):
    """Pure-Python twin of uf_bars; same rules, written separately for cross-checking."""
    F = np.asarray(F, dtype=np.float64)
    nx, ny = F.shape
    flat = F.ravel().tolist()
    order = np.lexsort((np.arange(F.size), F.ravel())).tolist()
    offsets = {4: [(-1, 0), (1, 0), (0, -1), (0, 1)],
               6: [(-1, 0), (1, 0), (0, -1), (0, 1), (1, 1), (-1, -1)],
               7: [(-1, 0), (1, 0), (0, -1), (0, 1), (1, -1), (-1, 1)],
               8: [(-1, 0), (1, 0), (0, -1), (0, 1), (1, 1), (-1, -1), (1, -1), (-1, 1)]}[mode]
    N = F.size
    EXT = N
    parent = list(range(N + 1))
    present = bytearray(N + 1)
    present[EXT] = 1
    key = {EXT: (-float("inf"), -1)}

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    out = []
    zero = 0
    for v in order:
        i, j = divmod(v, ny)
        present[v] = 1
        key[v] = (flat[v], v)
        nbrs = []
        if i == 0 or j == 0 or i == nx - 1 or j == ny - 1:
            nbrs.append(EXT)
        for di, dj in offsets:
            a, c = i + di, j + dj
            if 0 <= a < nx and 0 <= c < ny:
                u = a * ny + c
                if present[u]:
                    nbrs.append(u)
        for u in nbrs:
            ru, rv = find(u), find(v)
            if ru == rv:
                continue
            if key[ru] < key[rv]:
                old, young = ru, rv
            else:
                old, young = rv, ru
            born = key[young]
            ln = flat[v] - born[0]
            if ln > 0.0:
                out.append((born[1], v, ln))
            else:
                zero += 1
            parent[young] = old
    out.sort(key=lambda t: (-t[2], t[0]))
    return dict(birth=np.array([o[0] for o in out], dtype=np.int64), death=np.array([o[1] for o in out], dtype=np.int64),
                length=np.array([o[2] for o in out], dtype=float), zero_pairs=zero, mode=mode)


def longest(bars):
    return float(bars["length"][0]) if len(bars["length"]) else 0.0


def node_xy(idx, x, y):
    i, j = np.divmod(np.asarray(idx, dtype=np.int64), len(y))
    return np.column_stack([x[i], y[j]])
