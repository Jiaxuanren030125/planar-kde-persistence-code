"""Deterministic point clouds and closed-form fields.  No random-number generator is called anywhere in this module.

lattice_sample uses the R2 low-discrepancy sequence pushed through the exact radial quantile of the model density.  It is a
structured fixture: its KDE is close to the population smoother and carries almost no sampling noise.  It is NOT an iid draw and
its outputs are engineering checks, not evidence about sampling distributions.
"""
from __future__ import annotations

import math

import numpy as np
from scipy.optimize import brentq

from .model import Model

_G = 1.32471795724474602596


def r2_sequence(n, shift=0.5):
    i = np.arange(1, n + 1, dtype=float)
    return (shift + i / _G) % 1.0, (shift + i / (_G * _G)) % 1.0


def radial_survival(w, eps, q):
    """P(|X|^2 > w) under f_eps."""
    return (np.exp(-w / 2.0) - eps * q * np.exp(-w / (2.0 * q))) / (1.0 - eps * q)


def radial_quantile(u, eps, q):
    """Monotone inverse of the radial CDF by a Newton-safeguarded table + bisection (vectorized by interpolation then polish)."""
    wtab = np.concatenate([[0.0], np.geomspace(1e-6, 200.0, 20000)])
    cdf = 1.0 - radial_survival(wtab, eps, q)
    w = np.interp(u, cdf, wtab)
    for _ in range(6):
        pdf = (np.exp(-w / 2.0) / 2.0 - eps * q * np.exp(-w / (2.0 * q)) / (2.0 * q)) / (1.0 - eps * q)
        res = 1.0 - radial_survival(w, eps, q) - u
        w = np.maximum(w - res / np.maximum(pdf, 1e-300), 0.0)
    return w


def lattice_sample(n, model: Model, eps):
    u, v = r2_sequence(n)
    w = radial_quantile(u, eps, model.q)
    r = np.sqrt(w)
    return np.column_stack([r * np.cos(2.0 * np.pi * v), r * np.sin(2.0 * np.pi * v)])


def tail_triangle_fixture(n, model: Model, eps, radius=None, side=2.1, angle=0.6):
    """Lattice cloud plus three outliers placed around an empty region beyond the bulk.  Forces a very small tail bar."""
    X = lattice_sample(n - 3, model, eps)
    rad = float(np.max(np.hypot(X[:, 0], X[:, 1]))) if radius is None else radius
    c = (rad + side) * np.array([math.cos(angle), math.sin(angle)])
    pts = [c + side / math.sqrt(3.0) * np.array([math.cos(angle + k * 2.0 * math.pi / 3.0), math.sin(angle + k * 2.0 * math.pi / 3.0)]) for k in range(3)]
    return np.vstack([X, np.array(pts)]), c


def ring_fixture(m, radius):
    th = 2.0 * np.pi * (np.arange(m) + 0.5) / m
    return np.column_stack([radius * np.cos(th), radius * np.sin(th)])


def gauss2(x, y, v):
    return np.exp(-(x * x + y * y) / (2.0 * v)) / (2.0 * math.pi * v)


def population_with_perturbation(model: Model, eps, tilt=(0.0, 0.0), hess=(0.0, 0.0, 0.0), v=None):
    """Closed-form band-limited field m_eps + linear tilt + symmetric quadratic part, each localized by a Gaussian of variance v.

    The perturbation is built from derivatives of phi_v at the origin: for d=(d1,d2) and K=(k11,k12,k22),
        P(x) = c1 * [d . x] phi_v(x) + [k11 x1^2 + 2 k12 x1 x2 + k22 x2^2 - (k11+k22) v] phi_v(x)/(...)
    Normalizing constants are chosen so that grad P(0)=d and D^2 P(0)=2K exactly.  v must be >= H for band-limit consistency.
    Returned callable accepts arrays.  Also returns the exact gradient and Hessian of the total field at 0."""
    if v is None:
        v = 1.0 + model.H
    d1, d2 = tilt
    k11, k12, k22 = hess
    nf = 2.0 * math.pi * v
    A0, B = model.A0, model.B

    def field(x, y):
        pop = (A0 * np.exp(-(x * x + y * y) / (2.0 * model.v1)) - eps * B * np.exp(-(x * x + y * y) / (2.0 * model.v2))) / (1.0 - eps * model.q)
        g = np.exp(-(x * x + y * y) / (2.0 * v))
        return pop + (d1 * x + d2 * y) * g + (k11 * x * x + 2.0 * k12 * x * y + k22 * y * y) * g

    del nf
    grad0 = np.array([d1, d2])
    H0 = 2.0 * model.alpha_eps(eps) * np.eye(2) + 2.0 * np.array([[k11, k12], [k12, k22]])
    return field, grad0, H0
