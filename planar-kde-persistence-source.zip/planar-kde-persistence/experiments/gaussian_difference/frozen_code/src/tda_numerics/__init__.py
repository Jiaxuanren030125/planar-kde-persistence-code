"""TDA crater project numerics preflight (task 44/47). Deterministic engine; no formal Monte Carlo is run from this package."""
ENGINE_VERSION = "preflight_v2"
