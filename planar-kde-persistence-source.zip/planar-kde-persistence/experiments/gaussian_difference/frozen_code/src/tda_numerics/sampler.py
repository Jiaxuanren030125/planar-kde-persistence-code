"""IID sampler for f_eps.  Same RNG call order as Rounds 5-6 (radial exponential proposal, acceptance, then angles).

This module is imported by the guarded runner only.  In the preflight it is exercised for (a) a deterministic proof-check of the acceptance
law, (b) a fingerprint replay of already-saved Round 5/6 datasets, (c) pure timing with draws discarded.  No statistic of the target
experiment is ever computed on draws generated here during the preflight.
"""
from __future__ import annotations

import numpy as np


def draw_iid(n, eps, q, rng):
    """f_eps = (phi_1 - eps q phi_q)/(1-eps q).  |X|^2 under phi_1 is exponential with mean 2; accept with 1-eps exp(-s (1/q-1)/2)."""
    if not 0.0 <= eps <= 1.0:
        raise ValueError("epsilon must lie in [0,1]")
    k = 1.0 / q - 1.0
    pieces, have = [], 0
    while have < n:
        m = int((n - have) / (1.0 - eps * q) * 1.025) + 16
        s = rng.exponential(2.0, m)
        keep = rng.random(m) < 1.0 - eps * np.exp(-s * k / 2.0)
        a = s[keep]
        pieces.append(a)
        have += len(a)
    radius = np.sqrt(np.concatenate(pieces)[:n])
    theta = rng.uniform(0.0, 2.0 * np.pi, n)
    return np.column_stack([radius * np.cos(theta), radius * np.sin(theta)])
