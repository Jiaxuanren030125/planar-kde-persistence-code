"""Run integrity for the candidate design: frozen file list, environment check, single writer, expected identities, block verification and the
overall release status.  Small on purpose; it is not the Round 6 system.

preflight_v2 (task 57, R2 and R3).

Status rules (task 57, R2.3).  INVALID wins over PENDING, PENDING over VALID:
  INVALID  something present is wrong: a changed frozen file, a block that is unreadable, re-hashed or bound to another freeze, a duplicate or
           malformed identity, a wrong seed, a row outside the design, an unknown schema or data source, a block from another source version or
           environment, missing authorization for formal rows, analysis outputs that no longer match, or no analysable primary value at all.
  PENDING  nothing present is wrong but something expected is missing: blocks, the verification itself, or the analysis.
  VALID    every expected block and identity is present and legal, and the analysis outputs exist and are bound to exactly these blocks.
VALID means "complete and bound to the frozen definitions".  It does not mean that a theorem is supported, that the numerical error is small, or
that any continuous event is certified.  The numerical scope is fixed separately as NUMERIC_SCOPE_LIMITED.  Error rows and rows whose minimum
diagnostic is undetermined are legal rows and stay in every denominator.
"""
from __future__ import annotations

import fcntl
import hashlib
import json
import math
import os
import platform
import subprocess
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ROW_SCHEMA = "numerics_preflight.row.v3"
BLOCK_SCHEMA = "numerics_preflight.block.v2"
FREEZE_SCHEMA = "numerics_preflight.freeze.v2"
STATUS_SCHEMA = "numerics_preflight.release_status.v1"
ANALYSIS_SCHEMA = "numerics_preflight.analysis.v2"
NUMERIC_SCOPE = "NUMERIC_SCOPE_LIMITED"
SOURCES_BY_MODE = {False: "iid_draw", True: "deterministic_lattice_fixture"}     # keyed by fixture_only

ENGINE_FILES = ["src/tda_numerics/__init__.py", "src/tda_numerics/model.py", "src/tda_numerics/spectral_kde.py", "src/tda_numerics/ph_core.c",
                "src/tda_numerics/ph_grid.py", "src/tda_numerics/critical.py", "src/tda_numerics/quartic.py", "src/tda_numerics/pipeline.py",
                "src/tda_numerics/sampler.py", "src/tda_numerics/fixtures.py", "src/tda_numerics/release.py"]
SCRIPT_FILES = ["scripts/make_freeze.py", "scripts/run_candidate.py", "scripts/verify_run.py", "scripts/analyze_candidate.py"]
SPEC_FILES = ["candidate/DESIGN_CANDIDATE.json", "candidate/PREREG_CANDIDATE_CN.md", "candidate/ANALYSIS_PLAN_CN.md", "candidate/NUMERIC_POLICY_CN.md",
              "candidate/FIGURE_CAPTIONS_CN.md", "ENV_LOCK.json", "requirements.lock"]
FROZEN_FILES = ENGINE_FILES + SCRIPT_FILES + SPEC_FILES
THREAD_VARIABLES = ("VECLIB_MAXIMUM_THREADS", "OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS")


class Refusal(Exception):
    """A precondition failed; the caller stops before doing anything (exit code 3)."""


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical(obj):
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def digest(obj):
    return hashlib.sha256(canonical(obj).encode()).hexdigest()


def utc():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def frozen_hashes(root=ROOT):
    return {f: sha(Path(root) / f) for f in FROZEN_FILES}


# ------------------------------------------------------------------------------------------------ environment
def env_probe():
    """The environment as it actually is: interpreter, numerical libraries and their BLAS/LAPACK backends, architecture, C source and compiler."""
    import numpy
    import scipy
    from .ph_grid import COMPILE_FLAGS, c_source_sha256
    deps = numpy.__config__.CONFIG.get("Build Dependencies", {})
    try:
        compiler = subprocess.run(["clang", "--version"], check=True, capture_output=True, text=True).stdout.splitlines()[0]
    except Exception as exc:          # recorded, and then it fails the comparison
        compiler = "UNAVAILABLE: %s" % type(exc).__name__
    return dict(python=platform.python_version(), implementation=platform.python_implementation(), numpy=numpy.__version__, scipy=scipy.__version__,
                blas=deps.get("blas", {}).get("name"), lapack=deps.get("lapack", {}).get("name"), machine=platform.machine(), system=platform.system(),
                c_source_sha256=c_source_sha256(), compiler=compiler, compile_flags=COMPILE_FLAGS,
                thread_variables={v: os.environ.get(v) for v in THREAD_VARIABLES}, platform_detail=platform.platform())


def env_mismatches(lock, probe):
    """Every difference that matters.  Only the fields named in lock["accepted_differences"] may differ; nothing is relaxed at run time."""
    out = []
    for k, v in lock["required_equal"].items():
        if probe.get(k) != v:
            out.append("%s: locked %r, actual %r" % (k, v, probe.get(k)))
    for k, v in lock.get("thread_variables", {}).items():
        if probe.get("thread_variables", {}).get(k) != v:
            out.append("thread variable %s: locked %r, actual %r" % (k, v, probe.get("thread_variables", {}).get(k)))
    return out


def load_env_lock(root=ROOT):
    return json.loads((Path(root) / "ENV_LOCK.json").read_text())


# ------------------------------------------------------------------------------------------------ single writer
class RunLock:
    """Exclusive writer lock on a run directory (advisory flock on WRITER.lock; released when the process ends).  A second writer is refused."""

    def __init__(self, run_dir, role):
        self.path = Path(run_dir) / "WRITER.lock"
        self.role = role
        self.token = uuid.uuid4().hex
        self.fh = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fh = open(self.path, "a+")
        try:
            fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            fh.seek(0)
            holder = fh.read()
            fh.close()
            raise Refusal("another writer holds %s: %s" % (self.path.name, holder.strip()[:300]))
        fh.seek(0)
        fh.truncate()
        self.identity = dict(pid=os.getpid(), role=self.role, token=self.token, acquired_utc=utc(), host=platform.node())
        fh.write(json.dumps(self.identity))
        fh.flush()
        self.fh = fh
        return self

    def __exit__(self, *exc):
        if self.fh is not None:
            fcntl.flock(self.fh, fcntl.LOCK_UN)
            self.fh.close()
            self.fh = None
        return False


# ------------------------------------------------------------------------------------------------ design identities
def expected_jobs(design):
    jobs = []
    for cell in design["cells"]:
        for start in range(0, cell["reps"], design["block_reps"]):
            jobs.append(dict(cell=cell["cell"], n=cell["n"], s=cell["s"], start=start, stop=min(start + design["block_reps"], cell["reps"])))
    return jobs


def block_name(job):
    return "cell%03d_rep%05d_%05d.json" % (job["cell"], job["start"], job["stop"])


def seed_of(design, cell, rep):
    return design["seed_base"] + cell * 10000 + rep


def expected_identities(design):
    return {(c["cell"], rep): seed_of(design, c["cell"], rep) for c in design["cells"] for rep in range(c["reps"])}


def check_rows(rows, design, data_source=None, require_complete=True):
    """Identity and schema checks of rows against a design, without files.  Returns (invalid_reasons, pending_reasons, summary)."""
    cells = {c["cell"]: c for c in design["cells"]}
    want = expected_identities(design)
    invalid, seen = [], {}
    for r in rows:
        if not isinstance(r, dict):
            invalid.append("a row is not a record")
            continue
        key = (r.get("cell"), r.get("rep"))
        tag = "cell=%s rep=%s" % key
        if r.get("schema") != ROW_SCHEMA:
            invalid.append("unknown or missing row schema %r (%s)" % (r.get("schema"), tag))
        if data_source is not None and r.get("data_source") != data_source:
            invalid.append("data source %r is not %r (%s)" % (r.get("data_source"), data_source, tag))
        if key not in want:
            invalid.append("identity outside the design (%s)" % tag)
            continue
        if r.get("seed") != want[key]:
            invalid.append("wrong seed %r, design gives %r (%s)" % (r.get("seed"), want[key], tag))
        c = cells[key[0]]
        if r.get("n") != c["n"] or r.get("s") != c["s"] or r.get("q") != design["q"] or r.get("H") != design["H"]:
            invalid.append("n, s, q or H differ from the design cell (%s)" % tag)
        if r.get("status") not in ("ok", "error"):
            invalid.append("status %r is neither ok nor error (%s)" % (r.get("status"), tag))
        if key in seen:
            invalid.append("duplicate identity (%s)" % tag)
        seen[key] = r
    missing = len(set(want) - set(seen))
    pending = ["%d of %d expected identities missing" % (missing, len(want))] if (missing and require_complete) else []
    ok = [r for r in seen.values() if r.get("status") == "ok"]
    with_primary = [r for r in ok if _finite(r.get("rescaled_L_primary"))]
    summary = dict(expected=len(want), found=len(seen), missing=missing, rows_read=len(rows), ok=len(ok),
                   error=sum(r.get("status") == "error" for r in seen.values()), with_primary_value=len(with_primary),
                   minimum_undetermined=sum(r.get("minimum_diagnostic") == "UNDETERMINED_FLOAT" for r in seen.values()))
    if seen and not with_primary and not missing:
        invalid.append("no analysable primary value in any row")
    return invalid, pending, summary


def _finite(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


# ------------------------------------------------------------------------------------------------ freeze and authorization
def read_freeze(run_dir, root=ROOT):
    """(freeze, freeze_sha256, invalid_reasons).  Checks the frozen files on disk, the embedded design and environment lock."""
    fz = Path(run_dir) / "FREEZE.json"
    if not fz.exists():
        return None, None, []
    try:
        freeze = json.loads(fz.read_text())
    except Exception as exc:
        return None, None, ["FREEZE.json unreadable: %s" % type(exc).__name__]
    absent = [k for k in ("design", "design_sha256", "env_lock", "env_lock_sha256", "frozen_files") if not isinstance(freeze, dict) or k not in freeze]
    if absent:
        return None, None, ["FREEZE.json lacks: " + ", ".join(absent)]
    bad = []
    if freeze.get("schema") != FREEZE_SCHEMA:
        bad.append("freeze schema %r" % freeze.get("schema"))
    files = freeze.get("frozen_files", {})
    if set(files) != set(FROZEN_FILES):
        bad.append("freeze does not cover exactly the frozen file list")
    for f, h in files.items():
        p = Path(root) / f
        if not p.exists() or sha(p) != h:
            bad.append("frozen file changed or missing: " + f)
    if freeze.get("design_sha256") != digest(freeze.get("design")):
        bad.append("embedded design does not match its hash")
    if freeze.get("env_lock_sha256") != digest(freeze.get("env_lock")):
        bad.append("embedded environment lock does not match its hash")
    return freeze, sha(fz), bad


def read_authorization(run_dir, freeze, freeze_sha):
    """(present, invalid_reasons).  A fixture-only freeze never has a formal authorization."""
    au = Path(run_dir) / "AUTHORIZATION.json"
    if not au.exists():
        return False, []
    try:
        auth = json.loads(au.read_text())
    except Exception as exc:
        return True, ["AUTHORIZATION.json unreadable: %s" % type(exc).__name__]
    bad = []
    if auth.get("freeze_sha256") != freeze_sha or auth.get("formal_run_authorized") is not True:
        bad.append("authorization does not name this freeze")
    if auth.get("fixture_only") or (freeze or {}).get("fixture_only"):
        bad.append("a FIXTURE_ONLY object cannot authorize a formal run")
    return True, bad


# ------------------------------------------------------------------------------------------------ blocks and the overall status
def verify_run(run_dir, root=ROOT, check_env=True, include_analysis=True):
    """Compute the status from the files actually present.  Writes nothing."""
    run_dir = Path(run_dir)
    invalid, pending, notes = [], [], []
    freeze, freeze_sha, bad = read_freeze(run_dir, root)
    invalid += bad
    blocks_dir = run_dir / "blocks"
    files = sorted(blocks_dir.glob("*.json")) if blocks_dir.exists() else []
    tmp = sorted(blocks_dir.glob("*.tmp")) if blocks_dir.exists() else []
    res = dict(schema=STATUS_SCHEMA, numeric_scope=NUMERIC_SCOPE, verified_utc=utc(), run_dir=str(run_dir),
               verifier_files={f: sha(Path(root) / f) for f in ("src/tda_numerics/release.py", "scripts/verify_run.py") if (Path(root) / f).exists()})
    if freeze is None:
        if files:
            invalid.append("blocks without a FREEZE.json")
        else:
            pending.append("no FREEZE.json yet")
        res.update(status="INVALID" if invalid else "PENDING", reasons_invalid=invalid, reasons_pending=pending)
        return res
    design, fixture_only = freeze["design"], bool(freeze.get("fixture_only"))
    source = SOURCES_BY_MODE[fixture_only]
    actual = {f: (sha(Path(root) / f) if (Path(root) / f).exists() else None) for f in FROZEN_FILES}
    res.update(freeze_sha256=freeze_sha, design_sha256=freeze.get("design_sha256"), env_lock_sha256=freeze.get("env_lock_sha256"), fixture_only=fixture_only,
               data_source_expected=source, sources_actual_digest=digest(actual), sources_actual_match_freeze=actual == freeze.get("frozen_files"))
    if check_env:
        mism = env_mismatches(freeze["env_lock"], env_probe())
        if mism:
            invalid += ["verifier environment differs from the lock: " + m for m in mism]
    auth_present, bad = read_authorization(run_dir, freeze, freeze_sha)
    invalid += bad
    res["authorization_present"] = auth_present
    jobs = expected_jobs(design)
    want = {block_name(j): j for j in jobs}
    rows, manifest = [], {}
    for p in files:
        if p.name not in want:
            invalid.append("extra block file not in the design: " + p.name)
            continue
        try:
            body = json.loads(p.read_text())
        except Exception as exc:
            invalid.append("block unreadable: %s (%s)" % (p.name, type(exc).__name__))
            continue
        manifest[p.name] = sha(p)
        job = want[p.name]
        if body.get("schema") != BLOCK_SCHEMA:
            invalid.append("block schema %r: %s" % (body.get("schema"), p.name))
        if body.get("freeze_sha256") != freeze_sha:
            invalid.append("block bound to another freeze: " + p.name)
        if {k: body.get("job", {}).get(k) for k in job} != job:
            invalid.append("block job does not match its name: " + p.name)
        if digest(body.get("rows")) != body.get("rows_sha256"):
            invalid.append("block rows changed after writing: " + p.name)
        if (body.get("env") or {}).get("frozen_files") != freeze["frozen_files"]:
            invalid.append("block written by other source versions than the freeze: " + p.name)
        mism = env_mismatches(freeze["env_lock"], (body.get("env") or {}).get("probe") or {})
        if mism:
            invalid.append("block written in another environment: %s (%s)" % (p.name, mism[0]))
        brows = body.get("rows") if isinstance(body.get("rows"), list) else []
        if len(brows) != job["stop"] - job["start"]:
            invalid.append("block length differs from its job: " + p.name)
        for r in brows:
            if not isinstance(r, dict):
                continue            # check_rows reports it
            if r.get("cell") != job["cell"] or not (job["start"] <= (r.get("rep") if isinstance(r.get("rep"), int) else -1) < job["stop"]):
                invalid.append("row outside its block's range: %s cell=%s rep=%s" % (p.name, r.get("cell"), r.get("rep")))
        rows += brows
    rbad, _, summary = check_rows(rows, design, data_source=source, require_complete=False)
    invalid += rbad
    if not fixture_only and rows and not auth_present:
        invalid.append("formal rows without AUTHORIZATION.json")
    missing_blocks = sorted(set(want) - set(manifest) - {p.name for p in files})
    if missing_blocks:
        pending.append("%d of %d expected blocks missing" % (len(missing_blocks), len(want)))
    if tmp:
        notes.append("%d uncommitted .tmp block file(s) present (an interrupted write); they are not counted" % len(tmp))
    res["block_manifest_sha256"] = digest(manifest)
    res["blocks"] = dict(expected=len(want), present=len(files), missing=len(missing_blocks), missing_names=missing_blocks[:10])
    res["rows"] = summary
    if include_analysis:
        a = run_dir / "analysis" / "analysis_summary.json"
        if not a.exists():
            pending.append("analysis not done")
        else:
            try:
                body = json.loads(a.read_text())
            except Exception as exc:
                body = None
                invalid.append("analysis summary unreadable: %s" % type(exc).__name__)
            if body is not None:
                outs = body.get("outputs", {})
                res["analysis"] = dict(summary_sha256=sha(a), outputs=outs)
                if body.get("schema") != ANALYSIS_SCHEMA or body.get("mode") != "final":
                    invalid.append("analysis summary is not a final analysis of this schema")
                if body.get("consumed_block_manifest_sha256") != res["block_manifest_sha256"]:
                    invalid.append("analysis was made from other blocks than those present")
                if body.get("freeze_sha256") != freeze_sha:
                    invalid.append("analysis bound to another freeze")
                if body.get("analysis_files") != {f: freeze["frozen_files"].get(f) for f in body.get("analysis_files", {})} or not body.get("analysis_files"):
                    invalid.append("analysis made by source files other than the frozen ones")
                for name, h in outs.items():
                    q = run_dir / "analysis" / name
                    if not q.exists() or sha(q) != h:
                        invalid.append("analysis output changed or missing: " + name)
    res["reasons_invalid"], res["reasons_pending"], res["notes"] = invalid, pending, notes
    res["status"] = "INVALID" if invalid else ("PENDING" if pending else "VALID")
    res["formal_release"] = bool(res["status"] == "VALID" and not fixture_only and auth_present)
    res["meaning"] = ("VALID: complete and bound to the frozen definitions; not a supported theorem, not a small-error claim, not a certified continuous "
                      "event.  " + NUMERIC_SCOPE + " holds whatever the status.")
    return res


def compare_with_stored(run_dir, fresh):
    """--check: a stored release_status.json stays valid only while every binding it records is unchanged."""
    p = Path(run_dir) / "release_status.json"
    if not p.exists():
        return ["no stored release_status.json"]
    old = json.loads(p.read_text())
    diffs = []
    for k in ("status", "freeze_sha256", "design_sha256", "env_lock_sha256", "sources_actual_digest", "block_manifest_sha256", "analysis", "fixture_only", "formal_release"):
        if old.get(k) != fresh.get(k):
            diffs.append("binding changed since the status was written: " + k)
    return diffs
