"""Model constants and analytic limit-law references (no randomness).

Definitions follow PAPER_EDITING/releases/v4_2_1_singular_2026-11-04/sections/section1.tex and section2.tex.
H is always the kernel VARIANCE.  Old rounds wrote h for the standard deviation (H = h^2); see ASSET_REUSE_TABLE.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

TWO_PI = 2.0 * math.pi


@dataclass(frozen=True)
class Model:
    q: float
    H: float

    def __post_init__(self):
        if not (0.0 < self.q < 1.0 and self.H > 0.0 and self.H * self.H < self.q):
            raise ValueError("need 0<q<1, H>0 and H^2<q (paper section 1)")

    # ---- section 1 constants ------------------------------------------------------------------------------------
    @property
    def v1(self):
        return 1.0 + self.H

    @property
    def v2(self):
        return self.q + self.H

    @property
    def e(self):
        return self.v2 ** 2 / (self.q * self.v1 ** 2)

    @property
    def Dc(self):
        return 1.0 - self.e * self.q

    @property
    def A0(self):
        return 1.0 / (TWO_PI * self.v1)

    @property
    def B(self):
        return self.q / (TWO_PI * self.v2)

    @property
    def a(self):
        return self.B / (2.0 * self.v2 * self.Dc)

    @property
    def b(self):
        return self.A0 * (self.v1 / self.v2 - 1.0) / (8.0 * self.v1 ** 2 * self.Dc)

    @property
    def sigma_g2(self):
        H, q, e = self.H, self.q, self.e
        return ((H + 2.0) ** -2 - e * q ** 2 * (H + 2.0 * q) ** -2) / (4.0 * math.pi ** 2 * H ** 2 * self.Dc)

    @property
    def sigma_g(self):
        return math.sqrt(self.sigma_g2)

    @property
    def kappa(self):
        """P(L>0) -> 1-exp(-kappa s^3) for s>0; kappa = 4a^3/(27 b sigma_g^2)."""
        return 4.0 * self.a ** 3 / (27.0 * self.b * self.sigma_g2)

    def trace_sd_coefficient(self):
        """c with SD(tr(M_n)/2) ~ c n^{-1/6} at eps=e, where M_n=(n^{1/3}/2) D^2 fhat_n(0).  By quadrature of the radial integral over f_e."""
        from scipy.integrate import quad
        H, q, e = self.H, self.q, self.e

        def f_e(r):
            return (math.exp(-r * r / 2.0) / TWO_PI - e * q * math.exp(-r * r / (2.0 * q)) / (TWO_PI * q)) / (1.0 - e * q)

        def lap_half(r):
            return 0.5 * (r * r / H ** 2 - 2.0 / H) * math.exp(-r * r / (2.0 * H)) / (TWO_PI * H)

        second_moment = quad(lambda r: TWO_PI * r * f_e(r) * lap_half(r) ** 2, 0.0, 40.0, epsabs=1e-13)[0]
        return 0.5 * math.sqrt(second_moment)

    # ---- local parameter path --------------------------------------------------------------------------------------
    def eps_of(self, n, s):
        return self.e + s * n ** (-1.0 / 3.0)

    def s_of(self, n, eps):
        return (eps - self.e) * n ** (1.0 / 3.0)

    def legal_eps(self, eps):
        return 0.0 < eps < 1.0

    # ---- population smoother (closed form) -----------------------------------------------------------------------
    def p_eps(self, w, eps):
        """p_eps(w) with w=|x|^2; m_eps(x)=p_eps(|x|^2)."""
        return (self.A0 * np.exp(-w / (2.0 * self.v1)) - eps * self.B * np.exp(-w / (2.0 * self.v2))) / (1.0 - eps * self.q)

    def alpha_eps(self, eps):
        """alpha_eps = p'_eps(0) = (-A0/(2 v1) + eps B/(2 v2))/(1-eps q); D^2 m_eps(0) = 2 alpha_eps I."""
        return (-self.A0 / (2.0 * self.v1) + eps * self.B / (2.0 * self.v2)) / (1.0 - eps * self.q)

    def beta_eps(self, eps):
        """Quartic coefficient p''_eps(0)/2 at the origin; beta_e = -b."""
        return 0.5 * (self.A0 / (4.0 * self.v1 ** 2) - eps * self.B / (4.0 * self.v2 ** 2)) / (1.0 - eps * self.q)

    def ring_w_eps(self, eps):
        """w=r^2 of the population ridge for eps>e (p'_eps(w)=0); 0 if eps<=e."""
        if eps <= self.e:
            return 0.0
        k = 1.0 / (2.0 * self.v2) - 1.0 / (2.0 * self.v1)
        return math.log(eps * self.B / (2.0 * self.v2) / (self.A0 / (2.0 * self.v1))) / k

    def pop_bar(self, eps):
        """Exact population persistence bar length of m_eps: ridge height minus centre height (0 if eps<=e)."""
        w = self.ring_w_eps(eps)
        if w <= 0.0:
            return 0.0
        return float(self.p_eps(w, eps) - self.p_eps(0.0, eps))

    # ---- limit theorem references ----------------------------------------------------------------------------------
    def U_of(self, s):
        return self.a * s

    def t_c(self, s):
        U = self.U_of(s)
        return 4.0 * U ** 1.5 / (3.0 * math.sqrt(6.0 * self.b)) if U > 0 else 0.0

    def existence_limit(self, s):
        return 1.0 - math.exp(-self.kappa * s ** 3) if s > 0 else 0.0

    def atom_at_zero(self, s):
        """Limit P(Psi_s(G)=0).  =1 for s<=0, exp(-kappa s^3) for s>0."""
        return math.exp(-self.kappa * s ** 3) if s > 0 else 1.0

    def Psi(self, s, g):
        """Psi_s(g) for g a 2-vector or the magnitude t=|g|."""
        t = float(np.hypot(g[0], g[1])) if np.ndim(g) == 1 else abs(float(g))
        return psi_ray(self.U_of(s), self.b, t)

    def psi_max(self, s):
        U = self.U_of(s)
        return U * U / (4.0 * self.b) if U > 0 else 0.0

    def limit_quantile(self, s, p):
        """Quantile of Y=Psi_s(G): explicit because T=|G| is Rayleigh and psi is decreasing in t."""
        if s <= 0 or p <= self.atom_at_zero(s):
            return 0.0
        if p >= 1.0:
            return self.psi_max(s)
        t = self.sigma_g * math.sqrt(-2.0 * math.log(p))
        return psi_ray(self.U_of(s), self.b, t)

    def limit_r(self, s, y):
        """r_s(y): inverse of psi_s on [0,M], by bisection (psi is strictly decreasing on [0,t_c])."""
        U = self.U_of(s)
        if U <= 0:
            raise ValueError("r_s is defined for s>0")
        M = self.psi_max(s)
        tc = self.t_c(s)
        if y <= 0.0:
            return tc
        if y >= M:
            return 0.0
        lo, hi = 0.0, tc
        for _ in range(200):
            mid = 0.5 * (lo + hi)
            if psi_ray(U, self.b, mid) > y:
                lo = mid
            else:
                hi = mid
        return 0.5 * (lo + hi)

    def limit_cdf(self, s, y):
        """F_s(y)=P(Psi_s(G)<=y); atom exp(-t_c^2/(2 sigma_g^2)) at 0 for s>0; point mass at 0 for s<=0."""
        if y < 0.0:
            return 0.0
        if s <= 0:
            return 1.0
        if y >= self.psi_max(s):
            return 1.0
        return math.exp(-self.limit_r(s, y) ** 2 / (2.0 * self.sigma_g2))

    def limit_tail(self, s, tau):
        """lim P(n^{2/3} L_n > tau) for fixed 0<tau<M (a continuity point); 0 for tau>=M; for tau=0 the separate event limit."""
        if tau <= 0.0:
            return self.existence_limit(s)
        if s <= 0 or tau >= self.psi_max(s):
            return 0.0
        return 1.0 - self.limit_cdf(s, tau)

    def limit_cdf_curve(self, s, m=401):
        """Parametric exact CDF curve (y(t), F(y(t))), t in [0,t_c]; no inversion error."""
        if s <= 0:
            return np.array([0.0]), np.array([1.0])
        t = np.linspace(0.0, self.t_c(s), m)
        y = np.array([psi_ray(self.U_of(s), self.b, ti) for ti in t])
        F = np.exp(-t * t / (2.0 * self.sigma_g2))
        return y[::-1], F[::-1]


def psi_ray(U, b, t):
    """Length of the quartic bar for Q(x)=U x^2 - b x^4 + t x on the ray, using the trigonometric cubic solution."""
    if U <= 0.0:
        return 0.0
    if t == 0.0:
        return U * U / (4.0 * b)
    tc = 4.0 * U ** 1.5 / (3.0 * math.sqrt(6.0 * b))
    if t >= tc:
        return 0.0
    # x^3 + p x + q = 0 with p=-U/(2b), q=-t/(4b); three real roots
    p = -U / (2.0 * b)
    qq = -t / (4.0 * b)
    A = 2.0 * math.sqrt(-p / 3.0)
    arg = 3.0 * qq / (p * A)
    arg = max(-1.0, min(1.0, arg))
    th = math.acos(arg) / 3.0
    roots = sorted(A * math.cos(th - 2.0 * math.pi * k / 3.0) for k in range(3))
    x1, x2 = roots[0], roots[1]
    S = 3.0 * b * x1 ** 4 - U * x1 ** 2
    m = 3.0 * b * x2 ** 4 - U * x2 ** 2
    return S - m


PAPER_FIG2B = Model(q=0.5, H=0.25)      # the parameters of Figure 2(b) and of check_theorem.py
ROUND456 = Model(q=0.36 / 1.36, H=0.25)  # tau=0.6, h=0.5 (Rounds 4, 5, 6)
ROUND12 = Model(q=0.36 / 1.36, H=0.09)   # tau=0.6, h=0.3 (Rounds 1, 2 and the audit pilot)
