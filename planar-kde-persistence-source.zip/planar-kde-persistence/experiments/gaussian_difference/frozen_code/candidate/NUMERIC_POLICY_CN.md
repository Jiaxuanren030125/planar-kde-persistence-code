# 数值对象、预算与诊断政策 v2（候选，未冻结）

它取代 final6 记录目录里的 `NUMERIC_POLICY_CN.md` 中关于主报告量、误差括号和精确事件的部分；其余（估计器、离散过滤、窗口引理、比较模型）不变，证据仍是 final6 的 QA（代码未改的模块不重跑）。本文是工程说明，不是定理。

## 1. 主统计量

`L_primary` = 输出网格上 Kuhn 三角剖分（六邻接，`ph_core.c` 模式 6）的 PL 插值、其下星过滤的最长有限条，去掉长度不超过 `noise_floor` 的条以后。节点高度来自全样本 Gaussian KDE：每个观测都参与，不分箱，不截核，不设输入窗；节点上直接求和，再做三角插值。`rescaled_L_primary` = n^{2/3}·`L_primary`。

同一行还存过滤前的 `L_PL6_raw`、阈值 `noise_floor` 和过滤后的 `L_PL6_filtered`（与 `L_primary` 相同），所以过滤可以核查。`G_n` 和完整 2×2 的 `M_n` 由同一批样本在原点直接求和得到，不用迹代替矩阵。

主对象不依赖启发式搜索是否成功，也不依赖浮点极小搜索的结论。任务 57 的 N1 夹具上，关掉搜索或把它改坏，主字段一字不变（测试 T01）。

## 2. 经验/条件性数值预算

每行的 `numerical_budget`：

B_total = 2·(δ²/4)·M_bound + 2·η_node + noise_floor

| 项 | 管的误差 | 怎么算 | 依赖 |
|---|---|---|---|
| 2·(δ²/4)·M_bound | 精确节点值的 PL 插值与连续 f̂ 之差，经持久稳定性加倍 | M_bound 是 ‖D²f̂‖_op 在整个输出窗口上的上界：覆盖方块中心处的计算值，加 Hessian 余量 n2，加 ρ·(‖D³f̂‖_F + n3)，加 ρ²/2·L4。作用的函数是全样本 KDE f̂_n，区域是 [−W,W]²，它包含所有观测 | n2、n3 是经验校准的舍入余量加混叠、周期界；L4 是逐块四阶导上界；Kuhn 直角三角形的插值常数 δ²/4 |
| 2·η_node | 计算出的节点高度与 f̂ 在节点上的差 | η_node = 校准舍入余量 + 混叠界 + 周期界；节点值一致偏移 η 时每个条端点最多移动 η | 经验校准，只在 Apple Accelerate 上做过 |
| noise_floor | 删掉短条 | noise_floor = 4·η_node；只有全部条都不超过阈值时最长条才会被删，此时差不超过阈值 | 无额外假设 |

三项各管一种误差，不重复计数。条件是：M_bound 和 η_node 真的界住了所说的量。两者都依赖经验校准的舍入余量，所以字段名和图注都写 **empirical/conditional numerical budget**，不写严格认证。设计点上 B 约为重标度 0.004（n=10⁴）和 0.009（n=10⁵），几乎全部来自第一项；后两项在 10⁻¹² 量级。

以诊断值为中心的区间（如果要展示）半径至少是 B_total + |诊断值 − 主值|（行字段 `diagnostic_interval_radius`）。“落在 B 内”不说明配对正确。

## 3. 诊断量（不进入主显示）

- `L_polished_diagnostic`：启发式临界点搜索的值（v1 的 `L_num`）。来源标 `polished_critical_values`、`polished_unconfirmed`、`grid_PL6_only` 等。它可能错，第三、四轮审查的 M2、M4、N1 都还在，误差上界只有 B_total + |诊断值 − 主值|。
- N1 规则：如果结束这条的鞍点以下还有一个相关鞍点的某一侧没有解出，这条不算确认，`pairing` 记为 `unconfirmed_lower_saddle_unresolved`，行标 `pairing_unconfirmed_lower_saddle_unresolved`。诊断值保留。
- `minimum_diagnostic`：浮点极小搜索。v1 名称到 v2 名称：EXIST_CERT→MIN_FOUND_FLOAT，NONE_CERT→NO_MIN_FOUND_FLOAT，UNDETERMINED→UNDETERMINED_FLOAT（原名存于 `minimum_diagnostic_v1_name`）。它是数值极小值诊断，不是连续的 L_n>0 或 L_n=0，没有“精确率”及其上下界；NO_MIN_FOUND_FLOAT 也不会把主值改成 0。
- 存在性测试的余量传递：`certify_min_at` 的半径和 5/8 凸性余量现在用 λ_eff = λ − n2。这修的是公式适用缺口，没有让浮点程序变成严格认证。
- 标记分三组：`primary_flags`（邻接单调性、预算非有限、原始条被阈值删去、主值在预算内接近 0），`diagnostic_flags`（搜索、配对、极小诊断与主值不一致），`comparator_flags`（四次模型代数未解或与网格不符）。

## 4. 运行门槛（摘要）

冻结覆盖 `release.FROZEN_FILES`：引擎、运行器、核验器、分析器、冻结脚本、设计、本政策、协议、分析计划、图注、`ENV_LOCK.json`、`requirements.lock`。运行、续跑、核验、分析都先比较实际环境与锁（Python、NumPy、SciPy、BLAS/LAPACK 后端、架构、系统、C 源、编译器与参数、线程变量），任何一项不同就以退出码 3 停下，不能现场改锁。允许不同的只有操作系统补丁号、解释器路径、主机名和工作目录。运行目录有单写入锁。状态 INVALID 优先于 PENDING，齐全合法且分析完成才 VALID；数值范围另记 NUMERIC_SCOPE_LIMITED。

## 5. 不变的限制

- 舍入余量只在 Apple Accelerate 上校准；换后端是另一个未测环境。
- 没有在真实 iid 噪声上运行过：未定率、尾部条率、预算内未定的比例要运行后才知道。
- 极远外点会让磨光（诊断）变慢；主统计量不受影响。
- 四次比较模型在尖点 10⁻⁹ 以内可能给出舍入大小的假状态，记为 `comparator_flags`。
