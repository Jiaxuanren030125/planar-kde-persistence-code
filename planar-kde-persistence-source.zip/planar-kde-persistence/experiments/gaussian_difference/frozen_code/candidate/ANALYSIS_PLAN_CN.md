# 候选分析计划 v2（未冻结）

实现：`scripts/analyze_candidate.py`。阈值、分层和比较量写在代码常量里，先于任何目标数据。

**唯一的主统计量。** 每行的 `rescaled_L_primary`（过滤后 PL6 条长 × n^{2/3}）和它的 `numerical_budget.rescaled.B_total`。主计数、CDF、分位数、MAE/RMSE、主散点图都只读这两个字段。`L_polished_diagnostic` 和 `minimum_diagnostic` 只出现在 E 节。相对 v1：主对象由 `L_num` 换成 `L_primary`；精确事件一节删除；配对改用共同 mask；分析必须绑定完整的运行目录。

**单元与分母。** 按 (n, s)，不跨 n 合并。每格计划 400 份。没有主值的行（error 行；预览中尚缺的行）记为未知，不当作“无条”。

**A. 阈值事件（第一组展示）。** τ∈{0.005, 0.01, 0.02, 0.05, 0.1, 0.2} 全部报告；主曲线用预定的 τ=0.05，对照极限 Pr(Ψ_s(G)>0.05)。每个 τ 报：
- 名义计数 k=#{rescaled_L_primary>τ}，分母是有主值的行数 m_with_value；Clopper–Pearson 95% 区间只属于这个二项指标。
- 确定计数 k_certain=#{L−B>τ}、可能计数 k_possible=#{L+B>τ}+未知数，分母为计划份数；“预算内未定”数和 B≥τ 的行数。
- 敏感性包络：[k_certain 的 CP 下端, k_possible 的 CP 上端]（分母为计划份数）。它依赖经验数值预算，不是连续概率的严格置信区间。
- n=10⁵ 时 B 约 0.009，大于 τ=0.005、接近 0.01：这两个阈值的包络基本不提供信息，照报，不解读。

**B. 分布（第一组展示）。** 分位数 10/25/50/75/90 对极限分位数；经验 CDF 对极限 CDF 的 sup 差，只作描述，含原子处跳跃；m_used、m_missing 同时报，分位数再报把缺失行放到最下、最上时的上下界。零点（`L_primary=0` 的份数）来自声明的数值分辨率，单独报，不叫认证的无条。

**C. 同样本误差（第二组展示）。** 主比较 C₀=`Psi_leading`、C₁=`L_Qtilde`（完整 M_n 的四次）；预定辅助 C₂=`L_Qcentered`、C₃=`L_Qbeta`、C₄=`L_Qtrace` 同样全部报告。每个比较量用一个共同有限 mask（主值和比较量都有限），报 m_used、m_missing、带符号均值、MAE、RMSE、绝对误差 50/90/95 分位；有无条 2×2 表在同一个 mask 上，四格之和必须等于 m_used；比较量缺值不计入任何一格。s>0 按 |G_n|/t_c 分层 0–0.5、0.5–0.9、0.9–1.1、>1.1。相关只放最后，零方差写 NA。不在看数据后把表现好的比较量提成主比较。

**D. 曲率分量。** 迹部分均值和标准差、各向异性范数均值和 90 分位，并列领先公式 c·n^{-1/6}（c 在 ε=e 处）。这是固定紧盘的同样本量，不外推为全局条长或 CDF 的误差率。

**E. 数值预算与诊断（与展示分开）。** B 的中位数和最大值；`primary_flags`、`comparator_flags` 计数。诊断节：`minimum_diagnostic` 各类计数（分母为计划份数，缺行单列；每类的 CP 区间只属于“该行诊断为此类”这个指标，不是连续事件），`diagnostic_flags` 与 `scan_notes` 计数，`L_polished_diagnostic` 来源计数，|诊断值−主值| 的中位数和最大值。

**F. 输入与状态。** 分析读入冻结设计并由 `verify_run` 核对：160 块和 3,200 个唯一 (cell, rep, seed)，n/s/q/H、行模式、数据来源、块 hash、绑定的冻结、写块时的源和环境。INVALID 拒绝（退出码 3）；PENDING 只能 `--preview`，输出写到 `analysis_preview/` 并在图上标 PENDING；齐全合法才写最终分析，之后 `verify_run --write` 给出 VALID 并绑定分析输出。所有行都没有主值时不出主结果。每格都检查加和不变式（见 `invariants` 字段），任何一条不成立就拒绝写出。

**固定的图。** `display1_threshold_rate_and_cdf.png`、`display2_same_sample_errors.png`。图注草稿见 `FIGURE_CAPTIONS_CN.md`。没有点云例图。

**解释纪律。** 不用“验证”“确认”描述定理；相容只说在该 n 和该精度下相容；C₁ 优于或劣于 C₀ 都按实际写，同时看辅助量；看结果后才想到的分析标为事后。
