# 两组数值展示的图注草稿 v2（候选）

图注用英文，供正文直接使用；作者语态用 I/my 或无人称。中括号里的数在正式分析后按 `analysis_tables.json` 填入，不按结果改写措辞。

## Display 1: threshold rate and distribution of the numerical bar

**Caption draft.** Numerical longest bar for the model with q = 1/2, H = 1/4, at n = 10⁴ and 10⁵ and local parameters s = −1, 0, 1, 2 (400 independent samples per cell). The numerical statistic is the longest finite bar of the piecewise-linear interpolation of the full-sample kernel density estimate on a Kuhn-triangulated grid of spacing 0.08·n^{−1/6}, after bars no longer than a declared rounding threshold are removed, rescaled by n^{2/3}. (a) Fraction of samples with rescaled bar above τ = 0.05, with exact 95% binomial intervals; the shaded range shows how the count could move within each sample's empirical numerical budget. The black curve is the limit probability Pr(Ψ_s(G) > 0.05). (b, c) Empirical distribution functions for s = 1 and 2 against the limit distribution, which has an atom at 0. A value of 0 means that no grid bar exceeds the numerical resolution; it is not a certified absence of a minimum. The comparison is descriptive and makes no claim of convergence rate.

**必须保留的说明。** 阴影是经验数值预算下的敏感性范围，不是置信区间；n=10⁵ 时预算约 [0.009]，所以 τ=0.005、0.01 的计数照报但不解读；error 行和未定行的份数写在表里。

## Display 2: same-sample errors

**Caption draft.** For each sample with s > 0, the rescaled numerical bar against two same-sample predictions computed from the same observations: the leading prediction Ψ_s(G_n) from the rescaled gradient G_n = √n ∇f̂_n(0), and the longest bar of the quartic Q̃_n(u) = G_n·u + uᵀM_n u − b|u|⁴ with the full 2×2 matrix M_n = ½ n^{1/3} D²f̂_n(0). Each panel reports the number of samples used, the mean absolute error and the root-mean-square error; the diagonal marks equality. Errors are reported for both predictions whichever is smaller. The curvature correction concerns a fixed compact disc around the origin and is not a global convergence rate for the bar or its distribution.

**必须保留的说明。** 三个预定辅助比较（去漂移的 M_n、b_ε、只用迹）只在表里；相关系数只作次要信息；缺值不计入。

## 不使用的图

没有点云例图（任务 57 R3.4）。不画浮点极小诊断的率；如果以后需要，只能作为辅助图，图注写明它是浮点诊断，不是连续事件。
