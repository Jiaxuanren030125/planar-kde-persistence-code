"""Saved-record reading and analysis for the Mac run (task 92).

New here: quiescent, scan, analyze and the PNG preview export only (Mac storage, no Windows
ledger or environment scan). The functions rational, validate_result, counts, csv_write,
cp95_for_count and make_plot below the marker are copied mechanically from analysis82.py
(task 86); the computational bodies are unchanged.
Only saved objects and the original analytic constants; no RNG/KDE/PH imports.
"""
from pathlib import Path
from fractions import Fraction as Q
import csv
import fcntl
import math
import os
from records82 import (ROOT, TASK_ROOT, SCOPE, FORMAL, FIXTURE, Refused, need, read, sha, digest, atomic_json,
                       identity, key, planned, design, read_object, sample_read, arrays_read, listing)

MPL_CACHE = ROOT / 'runtime_cache/matplotlib'      # the same path make_plot sets; fixed before any import
os.environ['MPLCONFIGDIR'] = str(MPL_CACHE)
ROW_STATUSES = ('RUNNING', 'COMPLETE', 'ERROR', 'ERROR_PROCESS', 'ERROR_BUDGET', 'TIMEOUT', 'COST_LIMIT', 'MEMORY_LIMIT')
ROW_PHASES = ('PRE_GENERATION', 'GENERATING', 'SAMPLE_SAVED', 'COMPUTING', 'RESULT_COMMITTED')


def quiescent(run):
    """True when no process holds the run lock (flock is released by the OS when its owner exits)."""
    lock = Path(run) / 'RUN.lock'
    if not lock.exists():
        return True
    fd = os.open(str(lock), os.O_RDONLY)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        return False
    else:
        fcntl.flock(fd, fcntl.LOCK_UN)
        return True
    finally:
        os.close(fd)


def scan(run, binding):
    """No writes. Read every committed X and result before analysis."""
    run = Path(run)
    need(quiescent(run), 'READ_REQUIRES_QUIESCENT_RUN')
    started = read(run / 'RUN_STARTED.json')
    need(started['binding'] == binding and started['mode'] == binding['mode'] and started['planned'] == 2400, 'RUN_BINDING_CHANGED')
    end = read(run / 'RUN_END.json') if (run / 'RUN_END.json').exists() else None
    need(end is None or end['binding'] == binding, 'RUN_END_BINDING_CHANGED')
    expected = {key(ident): ident for ident in planned()}
    rows, snapshots, issues = [], {}, []
    error = timeout = partial = started_rows = complete = budget_missing = 0
    root = run / 'rows'
    if root.exists():
        for rowdir in sorted(listing(root)):
            need(rowdir.is_dir() and rowdir.name in expected, 'DUPLICATE_OR_UNPLANNED_ROW: ' + rowdir.name)
            need({p.name for p in listing(rowdir)} <= {'STATE.json', 'sample', 'result', 'work'}, 'UNPLANNED_OR_DUPLICATE_ROW_OBJECT')
            ident = expected[rowdir.name]
            need(not list(rowdir.rglob('*.writing')) and not list(rowdir.glob('*.staging')), 'AMBIGUOUS_COMMIT_FILES: ' + rowdir.name)
            state = read(rowdir / 'STATE.json')
            need(state['identity'] == ident and state['binding'] == binding, 'ROW_IDENTITY_VERSION_MISMATCH')
            started_rows += 1
            status = state['status']
            need(status in ROW_STATUSES, 'UNKNOWN_ROW_STATUS')
            need(state['phase'] in ROW_PHASES, 'UNKNOWN_ROW_PHASE')
            error += int(status.startswith('ERROR') or status in ('TIMEOUT', 'COST_LIMIT', 'MEMORY_LIMIT'))
            timeout += int(status == 'TIMEOUT')
            snapshot = {'state': sha(rowdir / 'STATE.json')}
            sample_commit = None
            if (rowdir / 'sample').exists():
                sample_read(rowdir, binding, ident, state.get('sample_commit'))
                sample_commit = sha(rowdir / 'sample/COMMIT.json')
                snapshot['sample'] = sample_commit
            else:
                need(state['phase'] == 'PRE_GENERATION' and not state.get('sample_commit'), 'GENERATION_INTERRUPTED_OR_SAMPLE_LOST')
            if (rowdir / 'result').exists():
                need(sample_commit is not None, 'RESULT_WITHOUT_SAMPLE')
                result = validate_result(rowdir, binding, ident, state, sample_commit)
                snapshot['result'] = sha(rowdir / 'result/COMMIT.json')
                rows.append(result)
                complete += 1
                budget_missing += int(result['E_T_upper'] is None)
            else:
                need(not state.get('result_commit') and status != 'COMPLETE', 'COMMITTED_RESULT_LOST')
                partial += 1
                if (rowdir / 'work/PROGRESS.json').exists():
                    progress = read(rowdir / 'work/PROGRESS.json')
                    budget_missing += int('Ynum' in progress and progress.get('E_T_upper') is None)
                    snapshot['partial_progress'] = sha(rowdir / 'work/PROGRESS.json')
            snapshots[rowdir.name] = snapshot
    basis = dict(run_started=sha(run / 'RUN_STARTED.json'), run_end=sha(run / 'RUN_END.json') if end else None,
                 run_log=sha(run / 'RUN_LOG.jsonl') if (run / 'RUN_LOG.jsonl').exists() else None, rows=snapshots,
                 frozen=binding.get('frozen_sha256'))
    charged = end['charged_monotonic_seconds'] if end else None
    summary = dict(scope=SCOPE, mode=binding['mode'], status='PENDING', planned=2400, completed_numerical=complete,
                   errors=error, timeout=timeout, not_started=2400-started_rows, partial_rows=partial,
                   unknown_numerical=2400-complete, budget_missing=budget_missing,
                   data_snapshot_sha256=digest(basis), identity_unique=True, issues=issues,
                   run_end_reason=end['reason'] if end else 'NO_RUN_END_RECORD',
                   cumulative_active_monotonic_seconds=charged,
                   cumulative_cap_reached=None if charged is None else charged >= 21600.0)
    # Errors overlap completed_numerical when a numerical value was committed but its budget failed.
    all_ready = complete == 2400 and error == 0 and budget_missing == 0 and partial == 0
    summary['all_rows_ready'] = all_ready
    return summary, rows


def _png_preview_hook():
    """Preview export only: when make_plot saves angular_display.svg, also save a PNG of the same Figure."""
    import matplotlib
    matplotlib.use('Agg')
    from matplotlib.figure import Figure
    original = Figure.savefig
    if getattr(original, '_task92_preview', False):
        return
    def savefig(self, fname, *args, **kwargs):
        out = original(self, fname, *args, **kwargs)
        path = Path(str(fname))
        if path.name == 'angular_display.svg':
            original(self, path.with_name('angular_display_preview.png'), dpi=200)
        return out
    savefig._task92_preview = True
    Figure.savefig = savefig


def analyze(run, binding, out, deps, smoke=False):
    """Mac twin of the original analyze: same counts/CP/plot/CSV calls, outputs in out, then a binding."""
    out = Path(out)
    need(out.name and out.name not in ('.', '..'), 'INVALID_ANALYSIS_NAME')
    summary, rows = scan(run, binding)
    need(not out.exists(), 'ANALYSIS_OUTPUT_ALREADY_EXISTS')
    out.mkdir(parents=True)
    table = counts(rows, summary)
    blockers = []
    fixture = binding['mode'] == FIXTURE
    need(not smoke or fixture, 'SMOKE_REQUIRES_NONSCIENTIFIC_MODE')
    if fixture and not smoke:
        blockers.append('NONSCIENTIFIC_COUNTS_ONLY')
    else:
        if deps.get('scipy') is None:
            blockers.append('SCIPY_MISSING_CP95')
            for r in table:
                if r['completed'] == 200:
                    r['cp_status'] = 'BLOCKED_SCIPY_MISSING'
        else:
            for r in table:
                r.update(cp95_for_count(r['exceeded'], r['completed']))
        if deps.get('matplotlib') is None:
            blockers.append('MATPLOTLIB_MISSING_VECTOR_PLOT')
        elif any(r['E_T_upper'] is None for r in rows):
            blockers.append('MISSING_BUDGET_FOR_PUBLIC_XLIMIT')
        else:
            _png_preview_hook()
            make_plot(rows, summary, out)
    csv_write(out / 'threshold_counts.csv', table, list(table[0]))
    saved = []
    d = design()
    for r in rows:
        cell = d['pilot_cells'][r['identity']['cell']]
        ms = d['regimes'][cell['regime']]['max_limit_length']
        saved.append(dict(**r['identity'], angular_law=cell['angular_law'], n=cell['n'], regime=cell['regime'],
                          Ynum=r['Ynum'], Ms=ms, Ynum_over_Ms=r['Ynum']/ms,
                          E_T_upper=r['E_T_upper'], E_T_over_Ms=None if r['E_T_upper'] is None else r['E_T_upper']/ms))
    csv_write(out / 'saved_values.csv', saved, ['cell', 'rep', 'seed', 'angular_law', 'n', 'regime', 'Ynum', 'Ms', 'Ynum_over_Ms', 'E_T_upper', 'E_T_over_Ms'])
    report = dict(summary, dependencies=deps, blockers=blockers,
                  denominators='planned 200 per cell and 2400 globally; missing/error never zero; error count may overlap known numerical values',
                  ambiguity='Ynum-E_T <= tau < Ynum+E_T; interpolation term only; no true KDE event certification',
                  fixture_not_scientific=fixture, non_scientific_smoke=smoke,
                  preview_png='angular_display_preview.png saved from the same Figure as PDF/SVG (preview export only)')
    atomic_json(out / 'SUMMARY.json', report)
    after, _ = scan(run, binding)
    need(after['data_snapshot_sha256'] == summary['data_snapshot_sha256'], 'INPUT_CHANGED_DURING_ANALYSIS')
    full = not fixture and not blockers and summary['all_rows_ready']
    atomic_json(out / 'BINDING.json', dict(binding=binding, data_snapshot_sha256=summary['data_snapshot_sha256'],
                                         full_display_complete=full, scope=SCOPE,
                                         files={p.name: sha(p) for p in sorted(listing(out))}))
    return report


# ---- below: copied mechanically from reference_candidate/code/analysis82.py (task 86); do not edit ----


def rational(record):
    return Q(int(record['numerator']), int(record['denominator']))


def validate_result(rowdir, binding, ident, state, sample_commit):
    import numpy as np
    record = read_object(rowdir, 'result', binding, ident, state.get('result_commit'))
    need(record['sample_commit'] == sample_commit, 'RESULT_SAMPLE_BINDING_MISMATCH')
    need(record['scope'] == SCOPE, 'NUMERIC_SCOPE_CHANGED')
    y = record['Ynum']
    need(type(y) in (float, int) and math.isfinite(y) and y >= 0, 'INVALID_YNUM')
    if binding['mode'] == FIXTURE:
        need(record['non_scientific'] is True, 'UNMARKED_HAND_RECORD')
        e = record['E_T_upper']
        need(e is None or (math.isfinite(e) and e >= 0), 'INVALID_HAND_BUDGET')
        return record
    from arithmetic_task80 import scaling_envelope, upward
    cell = design()['pilot_cells'][ident['cell']]
    ms = design()['regimes'][cell['regime']]['max_limit_length']
    need(record['n'] == cell['n'] and record['Ms'] == ms, 'RESULT_DESIGN_MISMATCH')
    fine = record['fine']
    need(fine['vertices'] <= 2_500_000 and fine['shape'] == [4 * fine['m'] + 1] * 2, 'GRID_SHAPE_OR_CAP_MISMATCH')
    need(fine['h_base'] == .08 * cell['n'] ** (-1/6) and fine['index_step'] == fine['h_base'] / 2,
         'GRID_STEP_CHANGED')
    need(fine['W'] == fine['m'] * fine['h_base'] and fine['W'] > fine['max_abs_X'], 'WINDOW_RULE_CHANGED')
    need(fine['m'] == math.ceil((fine['max_abs_X'] + .5) / fine['h_base']), 'WINDOW_CEILING_CHANGED')
    need(isinstance(fine['grid_sha256'], str) and len(fine['grid_sha256']) == 64, 'GRID_DIGEST_MISSING')
    coeff = arrays_read(Path(rowdir) / 'result/coefficients.npz', record['coeff_arrays'])
    bars = arrays_read(Path(rowdir) / 'result/bars.npz', record['bar_arrays'])
    need(set(coeff) == {'Fnodes', 'c_real', 'c_imag', 'xi_p', 'xi_q', 'wq', 'axis'}, 'COEFFICIENT_MEMBERS_CHANGED')
    need(set(bars) == {'birth', 'death', 'length'}, 'BAR_MEMBERS_CHANGED')
    nfft = record['field']['N']
    need(coeff['c_real'].shape == coeff['c_imag'].shape == (nfft, nfft // 2 + 1), 'COEFFICIENT_SHAPE')
    need(coeff['Fnodes'].shape == (nfft, nfft) and coeff['xi_p'].shape == (nfft,)
         and coeff['xi_q'].shape == coeff['wq'].shape == (nfft // 2 + 1,), 'FIELD_SHAPE')
    for part in ('c_real', 'c_imag'):
        need(np.all(coeff[part][nfft // 2] == 0) and np.all(coeff[part][:, nfft // 2] == 0), 'NYQUIST_NOT_ZERO')
    need(coeff['wq'][0] == coeff['wq'][-1] == 1 and np.all(coeff['wq'][1:-1] == 2), 'RFFT_WEIGHTS_CHANGED')
    axis = np.arange(-2 * fine['m'], 2 * fine['m'] + 1, dtype=float) * fine['index_step']
    need(np.array_equal(coeff['axis'], axis), 'SAVED_AXIS_CHANGED')
    lengths = bars['length']
    need(lengths.ndim == 1 and bars['birth'].shape == bars['death'].shape == lengths.shape, 'BAR_SHAPE')
    need(np.all(lengths > 0) and np.all(lengths[:-1] >= lengths[1:]), 'POSITIVE_BAR_ORDER')
    need(np.all((bars['birth'] >= 0) & (bars['birth'] < fine['vertices']))
         and np.all((bars['death'] >= 0) & (bars['death'] < fine['vertices'])), 'BAR_VERTEX_RANGE')
    longest = float(lengths[0]) if len(lengths) else 0.0
    need(record['L_PL'] == longest and y == cell['n'] ** (2/3) * longest, 'RAW_LONGEST_OR_SCALING_CHANGED')
    need(record['positive_bar_count'] == len(lengths) and type(record['zero_pairs']) is int and record['zero_pairs'] >= 0,
         'BAR_COUNTS_CHANGED')
    need(record['mode'] == 6 and record['unperformed'] == {'coarse_grid': 'NOT_RUN', 'expanded_window': 'NOT_RUN', 'nine_points': 'NOT_RUN'},
         'PH_MODE_OR_UNPERFORMED_RECORD_CHANGED')
    if record['scaling'] is not None:
        K = rational(record['K_triangle']['exact'])
        need(K >= 0 and record['K_triangle'] == upward(K), 'K_DISPLAY_INVALID')
        expected = scaling_envelope(cell['n'], fine['index_step'], ms, K)
        need(record['scaling'] == expected and record['E_T_upper'] == expected['E_T_upper']['value'], 'SCALAR_ENVELOPE_CHANGED')
        need(record['budget_flag'] == ('BELOW_0_1_MS' if expected['threshold_relation'] == 'BELOW' else 'RETAIN_OVER_OR_UNRESOLVED_BUDGET'),
             'BUDGET_FLAG_CHANGED')
    else:
        need(record['E_T_upper'] is None and record['budget_flag'] == 'BUDGET_MISSING', 'MISSING_BUDGET_HIDDEN')
    return record


def counts(rows, summary):
    d = design()
    tables = []
    for cell in d['pilot_cells']:
        subset = [r for r in rows if r['identity']['cell'] == cell['cell']]
        m, ms = len(subset), d['regimes'][cell['regime']]['max_limit_length']
        for relative in (Q(1, 10), Q(1, 4), Q(1, 2)):
            tau = relative * Q.from_float(ms)
            k = sum(Q.from_float(float(r['Ynum'])) > tau for r in subset)
            missing = sum(r['E_T_upper'] is None for r in subset)
            ambiguous = sum(Q.from_float(float(r['Ynum'])) - Q.from_float(float(r['E_T_upper'])) <= tau
                            < Q.from_float(float(r['Ynum'])) + Q.from_float(float(r['E_T_upper']))
                            for r in subset if r['E_T_upper'] is not None)
            tables.append(dict(cell=cell['cell'], angular_law=cell['angular_law'], n=cell['n'], regime=cell['regime'],
                               threshold_relative=str(relative), threshold=float(tau), planned=200, completed=m,
                               unknown=200-m, exceeded=k, planned_proportion_low=k/200,
                               planned_proportion_high=(k+200-m)/200, interpolation_only_ambiguous=ambiguous,
                               completed_budget_missing=missing, cp95_low=None, cp95_high=None,
                               cp_status='NOT_APPLICABLE_INCOMPLETE' if m != 200 else 'NOT_COMPUTED',
                               curve_label=('COMPLETE 200/200' if m == 200 else 'CONDITIONAL %d/200' % m)))
    return tables


def csv_write(path, records, fields):
    with Path(path).open('x', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader(); writer.writerows(records)


def cp95_for_count(k, m):
    """Production CP95; task86 also checks this same function with hand counts."""
    need(type(k) is int and type(m) is int and 0 <= k <= m <= 200, 'INVALID_CP_COUNTS')
    if m != 200:
        return dict(cp95_low=None, cp95_high=None, cp_status='NOT_APPLICABLE_INCOMPLETE')
    from scipy.stats import beta
    return dict(cp95_low=0.0 if k == 0 else float(beta.ppf(.025, k, 201-k)),
                cp95_high=1.0 if k == 200 else float(beta.ppf(.975, k+1, 200-k)),
                cp_status='NOMINAL_DESCRIPTIVE_CP95')


def make_plot(rows, summary, out):
    """Original production 2x2 plot; hand smoke uses this exact code, visibly marked."""
    need(all(r['E_T_upper'] is not None for r in rows), 'MISSING_BUDGET_FOR_PUBLIC_XLIMIT')
    os.environ['MPLCONFIGDIR'] = str(ROOT / 'runtime_cache/matplotlib')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    from tda_numerics.model import psi_ray
    d = design()
    fig, axes = plt.subplots(2, 2, figsize=(10, 7.8), sharex='row', sharey=True)
    curves = []
    for regime in (0, 1):
        ms = d['regimes'][regime]['max_limit_length']
        selected = [r for r in rows if d['pilot_cells'][r['identity']['cell']]['regime'] == regime]
        xmax = max([1.05] + [(r['Ynum'] + r['E_T_upper']) / ms for r in selected])
        U = d['constants']['a'] * d['regimes'][regime]['s']
        b, sigma2 = d['constants']['b'], d['constants']['sigma2']
        tc = 4 * U**1.5 / (3 * math.sqrt(6*b))
        ts = np.linspace(tc, 0., 1001)
        axx = [psi_ray(U, b, float(t))/ms for t in ts]
        cdf = [math.exp(-float(t)**2/(2*sigma2)) for t in ts]
        axx[0], axx[-1], cdf[0], cdf[-1] = 0., 1., 1-d['regimes'][regime]['target_limit_occurrence'], 1.
        for col, n in enumerate((10000, 100000)):
            ax = axes[regime, col]
            for law in ('circle', 'regular6', 'regular8'):
                group = [r for r in rows if d['pilot_cells'][r['identity']['cell']]['regime'] == regime
                         and d['pilot_cells'][r['identity']['cell']]['n'] == n
                         and d['pilot_cells'][r['identity']['cell']]['angular_law'] == law]
                vals = sorted(r['Ynum']/ms for r in group)
                m = len(vals)
                label = law + (' 200/200' if m == 200 else ' CONDITIONAL %d/200' % m)
                if m:
                    xx = [0.] + vals + [xmax]
                    yy = [0.] + [(i+1)/m for i in range(m)] + [1.]
                    ax.step(xx, yy, where='post', linewidth=1.2, label=label)
                    curves.extend(dict(regime=regime, n=n, series=law, x=x, cdf=y, completed=m, planned=200,
                                       conditional=m != 200) for x, y in zip(xx, yy))
                else:
                    ax.plot([], [], label=label + ' (no curve)')
            ax.plot(axx + [xmax], cdf + [1.], color='black', linewidth=1.4, label='Common analytic CDF')
            ax.vlines(0, 0, cdf[0], color='black', linewidth=1.4)
            curves.extend(dict(regime=regime, n=n, series='analytic', x=x, cdf=y, completed='', planned='', conditional=False)
                          for x, y in zip(axx + [xmax], cdf + [1.]))
            ax.set(xlim=(0, xmax), ylim=(0, 1.02), title='regime %d, n=%d' % (regime, n), xlabel='Ynum / Ms', ylabel='CDF')
            ax.legend(fontsize=7)
    label = 'COMPLETE' if summary['all_rows_ready'] else 'PENDING - incomplete cells show conditional m/200 ECDFs'
    if summary['mode'] == FIXTURE:
        label = 'NONSCIENTIFIC_SMOKE - hand values only\n' + label
    fig.suptitle(label, fontsize=10)
    fig.text(.02, .01, 'NUMERIC_SCOPE_LIMITED. Ynum=n^(2/3) raw longest positive mode6 PL bar. PL zero is not a continuous-plane absence.\n'
             'All values, including >1, retained. Row xmax=max(1.05, max((Ynum+E_T)/Ms)); E_T is interpolation only.', fontsize=7)
    fig.tight_layout(rect=(0, .055, 1, .96))
    fig.savefig(out / 'angular_display.pdf')
    fig.savefig(out / 'angular_display.svg')
    plt.close(fig)
    csv_write(out / 'curves.csv', curves, ['regime', 'n', 'series', 'x', 'cdf', 'completed', 'planned', 'conditional'])
