"""Fixed scalar envelopes and two arithmetic checks (task 80)."""
from fractions import Fraction as Q
import math

def binary(x):
    x=float(x)
    if not math.isfinite(x):raise ValueError('Nonfinite binary64 input')
    return Q.from_float(x)

def exact_record(q):
    return dict(numerator=str(q.numerator),denominator=str(q.denominator))

def upward(q):
    """Smallest finite binary64 >= exact rational q, checked as rationals."""
    f=float(q)
    if not math.isfinite(f):raise OverflowError('No finite display value')
    if binary(f)<q:f=math.nextafter(f,math.inf)
    if not math.isfinite(f) or binary(f)<q:raise ArithmeticError('Upward conversion failed')
    return dict(value=f,hex=f.hex(),exact=exact_record(q),display_not_below_exact=True)

def k_triangle(c_real,c_imag,xi_p,xi_q,wq):
    """Exactly the one prescribed formula; every operation uses Fraction."""
    pp=[binary(x)**2 for x in xi_p];qq=[binary(x)**2 for x in xi_q]
    ww=[binary(x) for x in wq]
    total=Q(0)
    for p in range(len(pp)):
        for q in range(len(qq)):
            total+=ww[q]*(abs(binary(c_real[p][q]))+abs(binary(c_imag[p][q])))*(pp[p]+qq[q])
    return total

def scaling_envelope(n,h,Ms,K):
    """n^(2/3) bracket certified by exact cubing; h, Ms are saved binary64 constants."""
    target=n*n;u=n**(2/3)
    for _ in range(32):
        if binary(u)**3>=target:break
        u=math.nextafter(u,math.inf)
    else:raise ArithmeticError('Cannot bracket n^(2/3) within 32 adjacent floats')
    for _ in range(32):
        prev=math.nextafter(u,-math.inf)
        if binary(prev)**3<target:break
        u=prev
    else:raise ArithmeticError('Cannot minimize upper bracket')
    low,high=binary(prev),binary(u)
    assert low**3<target<=high**3
    hq,Mq=binary(h),binary(Ms)
    if hq<=0 or Mq<=0 or K<0:raise ValueError('Invalid scaling inputs')
    factor=K*hq*hq/2
    Elow,Ehigh=low*factor,high*factor
    threshold=Mq/10
    relation='BELOW' if Ehigh<threshold else 'NOT_BELOW' if Elow>=threshold else 'UNRESOLVED_SCALAR_BRACKET'
    return dict(n=n,n_power=dict(definition='real cube root of n^2',n_squared=target,
        lower=exact_record(low),lower_hex=prev.hex(),upper=exact_record(high),upper_value=u,upper_hex=u.hex(),
        exact_cube_inequalities='lower^3 < n^2 <= upper^3',verified=True),
        h=exact_record(hq),h_hex=float(h).hex(),h_scope='exact saved fine.index_step; not recomputed from .04*n^(-1/6)',
        Ms=exact_record(Mq),Ms_scope='exact original saved binary64 max_limit_length; canonical task76 normalization',
        E_T_lower=exact_record(Elow),E_T_upper=upward(Ehigh),E_T_over_Ms_upper=upward(Ehigh/Mq),
        exact_threshold=exact_record(threshold),threshold_relation=relation,
        finite_field_interpolation_only=True,coordinate_and_vertex_evaluation_error_certified=False)

def arithmetic_checks():
    # Check 1: a DC field and one real cosine in an interior rFFT q mode.
    # N=4: row 2 and column 2 (Nyquist) remain exactly zero.
    real=[[0.,0.,0.] for _ in range(4)];imag=[[0.,0.,0.] for _ in range(4)]
    real[0][0]=3.5;p=[0.,1.,-2.,-1.];q=[0.,1.,2.];w=[1.,2.,1.]
    constant=k_triangle(real,imag,p,q,w);assert constant==0
    real[0][1]=.5
    cosine=k_triangle(real,imag,p,q,w);assert cosine==1
    assert real[2]==[0.,0.,0.] and all(row[2]==0 for row in real)
    one=dict(status='PASS',constant_K=exact_record(constant),cosine_K=exact_record(cosine),
        real_coefficients=real,imag_coefficients=imag,xi_p=p,xi_q=q,wq=w,
        field='3.5 + cos(y+P/2); derivative Hessian norm has supremum 1',
        analytic_hessian_at_zero_phase=[['0','0'],['0','-1']],Nyquist_entries_zero=True,
        upward_display=upward(cosine))
    # Check 2: both mode6 triangles of one tiny square; quadratic Hessian is 3I.
    # The diagonal midpoint attains the h^2/2 variance and K*h^2/4 error.
    entries=[];K=Q(3)
    for h in (Q(1),Q(1,2)):
        for middle in ((h,Q(0)),(Q(0),h)):
            vertices=((Q(0),Q(0)),middle,(h,h))
            for weights in ((Q(1,2),Q(0),Q(1,2)),(Q(1,3),)*3):
                x=[sum(weights[i]*vertices[i][j] for i in range(3)) for j in range(2)]
                variance=sum(weights[i]*sum((vertices[i][j]-x[j])**2 for j in range(2)) for i in range(3))
                f=lambda xy:K*sum(z*z for z in xy)/2
                err=sum(weights[i]*f(vertices[i]) for i in range(3))-f(x)
                assert variance<=h*h/2 and err==K*variance/2 and err<=K*h*h/4
                if weights[1]==0:assert err==K*h*h/4
                entries.append(dict(h=str(h),vertices=[[str(z) for z in v] for v in vertices],weights=[str(z) for z in weights],
                    variance=str(variance),error=str(err),bound=str(K*h*h/4),error_over_h_squared=str(err/(h*h))))
    assert Q(entries[4]['error'])/Q(entries[0]['error'])==Q(1,4)
    two=dict(status='PASS',quadratic='3/2*(x^2+y^2)',K='3',probes=entries,
        half_step_error_ratio='1/4',scope='hand-constructed deterministic fixture only; no pilot grid modified')
    return dict(status='PASS',check_count=2,constant_and_cosine=one,triangle_geometry=two)
