"""Minimal storage and identity layer for the Mac run (task 92).

Replaces the Windows records82.py for the names science82.py imports
(FORMAL, SCOPE, need, design, arrays_write, arrays_read, atomic_json, array_sha, utc)
plus the row commit helpers the original 82/86 worker used. The original Windows file is
kept byte-unchanged under input/.../reference_candidate/code/records82.py.

No sampler, KDE, PH or analytic CDF is called here. Bodies of need, utc, sha, json_bytes,
digest, read, array_sha, array_description, arrays_write, arrays_read, identity, key,
planned, commit_object, read_object, set_state and sample_read follow the original;
atomic_json and the directory commit use POSIX no-replace primitives (os.link) because a
POSIX rename silently replaces an existing destination file, unlike Windows.
"""
from pathlib import Path
import datetime
import hashlib
import json
import math
import os

TASK_ROOT = Path(__file__).resolve().parents[1]          # historical run directory
ROOT = TASK_ROOT                                          # Mac ROOT: caches under ROOT/runtime_cache
INPUT = TASK_ROOT / 'input' / 'TDA_TASK92_MAC_ANGULAR_RUN_v1_2026-11-06'
REFERENCE = INPUT / 'reference_candidate'                 # read-only copy of the 36 candidate files
RUN = TASK_ROOT / 'run'
SCOPE = 'NUMERIC_SCOPE_LIMITED'
FORMAL = 'FORMAL_LIMITED_DISPLAY'
FIXTURE = 'NONSCIENTIFIC_FIXTURE'
RUN_ID = 'mac92_run_v1'
THREADS = ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')
for _key in THREADS:
    os.environ[_key] = '1'          # set before any NumPy import in this process; actual Accelerate threads UNKNOWN
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'


class Refused(RuntimeError):
    pass


def need(condition, message):
    if not condition:
        raise Refused(message)


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def json_bytes(obj):
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n').encode('utf-8')


def digest(obj):
    return hashlib.sha256(json_bytes(obj)).hexdigest()


def read(path):
    def pairs(items):
        out = {}
        for key, value in items:
            need(key not in out, 'DUPLICATE_JSON_KEY: ' + key)
            out[key] = value
        return out
    def bad(value):
        raise Refused('NONFINITE_JSON: ' + value)
    try:
        return json.loads(Path(path).read_text(encoding='utf-8-sig'), object_pairs_hook=pairs, parse_constant=bad)
    except (ValueError, OSError) as exc:
        raise Refused('UNREADABLE_JSON: ' + str(path) + ': ' + str(exc)) from exc


def fsync_dir(path):
    fd = os.open(str(path), os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def atomic_json(path, obj, replace=False):
    """fsync, then no-replace link (or explicit replace). A leftover .writing is evidence, never erased."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    need(replace or not path.exists(), 'DUPLICATE_COMMIT: ' + str(path))
    payload = json_bytes(obj)  # Reject nonfinite content before creating any temporary file.
    tmp = path.with_name(path.name + '.writing')
    with tmp.open('xb') as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    if replace:
        os.replace(tmp, path)
    else:
        os.link(tmp, path)   # POSIX link refuses an existing destination; rename would replace it
        os.unlink(tmp)
    fsync_dir(path.parent)


def append_line(path, obj):
    """Append one JSON line, flush and fsync (parent-owned run log only)."""
    with Path(path).open('ab') as stream:
        stream.write((json.dumps(dict(at=utc(), **obj), ensure_ascii=False, sort_keys=True, allow_nan=False) + '\n').encode())
        stream.flush()
        os.fsync(stream.fileno())


def array_sha(array):
    import numpy as np
    return hashlib.sha256(np.ascontiguousarray(array).tobytes()).hexdigest()


def array_description(array):
    return dict(shape=list(array.shape), dtype=array.dtype.str, sha256=array_sha(array))


def arrays_write(path, arrays):
    import numpy as np
    for name, array in arrays.items():
        need(array.dtype.kind in 'fiu' and np.isfinite(array).all(), 'NONFINITE_OR_OBJECT_ARRAY: ' + name)
    with Path(path).open('xb') as stream:
        np.savez_compressed(stream, **arrays)
        stream.flush()
        os.fsync(stream.fileno())
    return {name: array_description(array) for name, array in arrays.items()}


def arrays_read(path, descriptions):
    import numpy as np
    with np.load(path, allow_pickle=False) as archive:
        need(set(archive.files) == set(descriptions), 'ARRAY_MEMBERS_MISMATCH')
        arrays = {name: archive[name] for name in archive.files}
    for name, array in arrays.items():
        need(array.dtype.kind in 'fiu' and np.isfinite(array).all(), 'NONFINITE_ARRAY: ' + name)
        need(array_description(array) == descriptions[name], 'ARRAY_HASH_SHAPE_DTYPE_MISMATCH: ' + name)
    return arrays


def design():
    return read(REFERENCE / 'provenance/DESIGN_CANDIDATE.json')


def identity(cell, rep):
    need(type(cell) is int and type(rep) is int and 0 <= cell < 12 and 0 <= rep < 200, 'UNPLANNED_IDENTITY')
    return dict(cell=cell, rep=rep, seed=20261105800000 + 1000 * cell + rep)


def key(ident):
    need(ident == identity(ident['cell'], ident['rep']), 'WRONG_SEED_OR_IDENTITY')
    return 'c%02d_r%03d' % (ident['cell'], ident['rep'])


def planned():
    return [identity(cell, rep) for cell in range(12) for rep in range(200)]


def commit_object(rowdir, name, record, arrays=None, files=None):
    """Same function for hand payload and science payload. Never replaces an object."""
    rowdir = Path(rowdir)
    target, stage = rowdir / name, rowdir / (name + '.staging')
    need(not target.exists(), 'DUPLICATE_COMMIT: ' + str(target))
    need(not stage.exists(), 'AMBIGUOUS_STAGING_OBJECT: ' + str(stage))
    stage.mkdir()
    record = dict(record)
    if arrays is not None:
        record['arrays'] = arrays_write(stage / 'arrays.npz', arrays)
    if files:
        import shutil
        for file_name, source in files.items():
            need(Path(file_name).name == file_name, 'NONLOCAL_PAYLOAD_FILE')
            with Path(source).open('rb') as src, (stage / file_name).open('xb') as dest:
                shutil.copyfileobj(src, dest); dest.flush(); os.fsync(dest.fileno())
    atomic_json(stage / 'record.json', record)
    members = {p.name: dict(size_bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(listing(stage))}
    atomic_json(stage / 'COMMIT.json', dict(schema='task82-object-v1', files=members))
    need(not target.exists(), 'DUPLICATE_COMMIT: ' + str(target))   # single writer per row holds the run lock
    os.rename(stage, target)
    fsync_dir(rowdir)
    return sha(target / 'COMMIT.json')


FINDER_METADATA = '.DS_Store'   # macOS Finder may add this when a folder is opened; never part of an object


def listing(path):
    """Directory entries without Finder metadata (Mac storage adaptation)."""
    return [p for p in Path(path).iterdir() if p.name != FINDER_METADATA]


def read_object(rowdir, name, binding, ident, expected_commit=None):
    path = Path(rowdir) / name
    need(path.is_dir(), 'MISSING_OBJECT: ' + name)
    need(not (Path(rowdir) / (name + '.staging')).exists(), 'AMBIGUOUS_STAGING_OBJECT')
    commit = read(path / 'COMMIT.json')
    if expected_commit is not None:
        need(sha(path / 'COMMIT.json') == expected_commit, 'COMMIT_ID_CHANGED')
    need(set(p.name for p in listing(path)) == set(commit['files']) | {'COMMIT.json'}, 'OBJECT_FILE_SET_CHANGED')
    for rel, expected in commit['files'].items():
        need(Path(rel).name == rel, 'NONLOCAL_OBJECT_MEMBER')
        file = path / rel
        need(file.is_file() and file.stat().st_size == expected['size_bytes'] and sha(file) == expected['sha256'],
             'CORRUPT_OBJECT: ' + str(file))
    record = read(path / 'record.json')
    need(record['binding'] == binding and record['identity'] == ident, 'OBJECT_VERSION_OR_SEED_MISMATCH')
    return record


def set_state(rowdir, binding, ident, phase, status='RUNNING', **values):
    path = Path(rowdir) / 'STATE.json'
    old = read(path) if path.exists() else {}
    need(not old or (old['binding'] == binding and old['identity'] == ident), 'STATE_IDENTITY_CHANGED')
    old.update(binding=binding, identity=ident, phase=phase, status=status, updated_utc=utc(), **values)
    atomic_json(path, old, replace=path.exists())
    return old


def sample_read(rowdir, binding, ident, commit_hash=None):
    import numpy as np
    record = read_object(rowdir, 'sample', binding, ident, commit_hash)
    arrays = arrays_read(Path(rowdir) / 'sample/arrays.npz', record['arrays'])
    need(set(arrays) == {'X', 'angular'} and arrays['X'].dtype == np.dtype('float64'), 'INVALID_SAMPLE_ARRAYS')
    if binding['mode'] == FORMAL:
        cell = design()['pilot_cells'][ident['cell']]
        need(record['cell'] == {k: v for k, v in cell.items() if k != 'pilot_seed'}, 'SAMPLE_DESIGN_MISMATCH')
        need(arrays['X'].shape == (cell['n'], 2) and arrays['angular'].shape == (cell['n'],), 'SAMPLE_SHAPE_MISMATCH')
        need(record['generator'] == 'PCG64' and record['generation_order'] == 'all angles/labels, then all (n,2) normal errors',
             'SAMPLER_METADATA_MISMATCH')
        angle = arrays['angular']
        if cell['angular_law'] == 'circle':
            need(angle.dtype == np.dtype('float64') and np.all((angle >= 0) & (angle < 2 * math.pi)), 'INVALID_CIRCLE_ANGLES')
        else:
            need(angle.dtype.kind == 'i' and np.all((angle >= 0) & (angle < int(cell['angular_law'][-1]))), 'INVALID_LABELS')
    else:
        need(record['non_scientific'] is True and arrays['X'].shape == (3, 2), 'INVALID_HAND_FIXTURE')
    return arrays, record
