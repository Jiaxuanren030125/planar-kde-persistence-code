"""Scientific payload for angular designs (task 82).

Not imported by prepare or fixture. The accepted engine and arithmetic files
are copied without edits; only the new formal identity and transaction wrapper
are used here. There is no executable top-level scientific entry point.
"""
from pathlib import Path
import math
import time
import traceback
from records82 import (FORMAL, SCOPE, need, design, arrays_write, arrays_read, atomic_json, array_sha, utc)


def sample(binding, ident):
    need(binding['mode'] == FORMAL, 'SCIENCE_FORBIDDEN_IN_FIXTURE')
    import numpy as np
    d = design()
    cell = {k: v for k, v in d['pilot_cells'][ident['cell']].items() if k != 'pilot_seed'}
    n, law = cell['n'], cell['angular_law']
    rng = np.random.Generator(np.random.PCG64(ident['seed']))
    before = rng.bit_generator.state
    if law == 'circle':
        angular = rng.uniform(0., 2 * math.pi, size=n)
        angles = angular
    elif law in ('regular6', 'regular8'):
        k = int(law[-1])
        angular = rng.integers(0, k, size=n)
        angles = 2 * math.pi * angular / k
    else:
        raise ValueError('Unplanned angular law')
    S = np.column_stack((np.cos(angles), np.sin(angles)))
    noise = rng.normal(0., math.sqrt(d['lambda_observation']), size=(n, 2))
    X = math.sqrt(cell['theta_n']) * S + noise
    need(np.isfinite(X).all(), 'NONFINITE_SAMPLE')
    record = dict(binding=binding, identity=ident, cell=cell, generator='PCG64', numpy_version=np.__version__,
                  state_before=before, state_after=rng.bit_generator.state,
                  generation_order='all angles/labels, then all (n,2) normal errors', generated_once=True,
                  max_abs_coordinate=float(np.abs(X).max()),
                  vertex_counts=None if law == 'circle' else np.bincount(angular, minlength=int(law[-1])).tolist())
    return record, dict(X=X, angular=angular)


def compute(rowdir, binding, ident, arrays, sample_record, sample_commit):
    need(binding['mode'] == FORMAL, 'SCIENCE_FORBIDDEN_IN_FIXTURE')
    import numpy as np
    from tda_numerics.spectral_kde import kde_field
    from tda_numerics.ph_grid import bars_py, longest
    from arithmetic_task80 import k_triangle, scaling_envelope, upward
    d, X = design(), arrays['X']
    cell = d['pilot_cells'][ident['cell']]
    n, H = cell['n'], d['H']
    Ms = d['regimes'][cell['regime']]['max_limit_length']
    work = Path(rowdir) / 'work'
    work.mkdir(exist_ok=True)
    attempt = work / ('compute_' + str(time.time_ns()))
    attempt.mkdir()
    start = time.perf_counter()
    progress = dict(binding=binding, identity=ident, sample_commit=sample_commit, scope=SCOPE,
                    compute_attempt=attempt.name, started_utc=utc())

    def checkpoint(stage, **values):
        progress.update(stage=stage, elapsed_seconds=time.perf_counter()-start, **values)
        atomic_json(attempt / 'PROGRESS.json', progress, replace=(attempt / 'PROGRESS.json').exists())
        atomic_json(work / 'PROGRESS.json', progress, replace=(work / 'PROGRESS.json').exists())

    h_base = .08 * n ** (-1/6)
    extent = float(np.abs(X).max())
    m = int(math.ceil((extent + .5) / h_base))
    W, h = m * h_base, h_base / 2
    vertices = (4*m+1)**2
    checkpoint('GRID_PLANNED', h_base=h_base, m=m, W=W, h=h, vertices=vertices)
    if vertices > 2_500_000:
        raise MemoryError('COST_LIMIT_FINE_VERTICES: %d > 2500000 before grid allocation' % vertices)
    need(W > extent, 'WINDOW_DOES_NOT_CONTAIN_SAMPLE')
    axis = np.arange(-2*m, 2*m+1, dtype=float) * h
    t = time.perf_counter()
    field = kde_field(X, H, output_halfwidth=W)
    kde_seconds = time.perf_counter()-t
    need(field.meta['input_points_kept'] == n and field.meta['input_points_dropped'] == 0, 'NOT_FULL_SAMPLE_KDE')
    coeff = dict(Fnodes=field.Fnodes, c_real=field.c.real, c_imag=field.c.imag,
                 xi_p=field.xi_p, xi_q=field.xi_q, wq=field.wq, axis=axis)
    coeff_desc = arrays_write(attempt / 'coefficients.npz', coeff)
    checkpoint('COEFFICIENTS_SAVED', coeff_arrays=coeff_desc, kde_seconds=kde_seconds)
    t = time.perf_counter()
    F = field.tensor(axis, axis)
    need(np.isfinite(F).all(), 'NONFINITE_FINE_GRID')
    tensor_seconds = time.perf_counter()-t
    fine = dict(h_base=h_base, m=m, index_step=h, W=W, max_abs_X=extent,
                shape=list(F.shape), vertices=int(F.size), effective_step=float(axis[1]-axis[0]),
                grid_sha256=array_sha(F), axis_sha256=array_sha(axis),
                field_min=float(F.min()), field_max=float(F.max()),
                boundary='mode6 (+1,+1) Kuhn; exterior joined to all boundary vertices; (height,flat index) order')
    checkpoint('FINE_GRID_EVALUATED', fine=fine, tensor_seconds=tensor_seconds)
    t = time.perf_counter()
    bars = bars_py(F, mode=6)
    ph_seconds = time.perf_counter()-t
    bar_desc = arrays_write(attempt / 'bars.npz', {k: bars[k] for k in ('birth', 'death', 'length')})
    L = longest(bars)
    y = n ** (2/3) * L
    need(math.isfinite(y), 'NONFINITE_YNUM')
    checkpoint('POSITIVE_BARS_SAVED', Ynum=y, L_PL=L, E_T_upper=None, bar_arrays=bar_desc, ph_seconds=ph_seconds)
    result = dict(binding=binding, identity=ident, scope=SCOPE, sample_commit=sample_commit,
                  n=n, Ms=Ms, fine=fine, L_PL=L, Ynum=y, mode=6, positive_bar_count=len(bars['length']),
                  zero_pairs=bars['zero_pairs'], positive_bars_below_1e_12=int(np.sum(bars['length'] < 1e-12)),
                  smallest_positive_bar=float(bars['length'].min()) if len(bars['length']) else None,
                  coeff_arrays=coeff_desc, bar_arrays=bar_desc,
                  field=dict(N=field.N, P=field.P, Delta=field.Delta, H=H, meta=field.meta),
                  build_arguments=dict(H=H, output_halfwidth=W, delta_target=None, pad=None, chunk=4096,
                                       resolved_delta_target=.25*math.sqrt(H), resolved_pad=8*math.sqrt(H)),
                  unperformed=dict(coarse_grid='NOT_RUN', expanded_window='NOT_RUN', nine_points='NOT_RUN'),
                  old_kernel_interpolation_Y=n**(2/3)*h*h/(4*math.pi*H**2),
                  old_kernel_interpolation_over_Ms=n**(2/3)*h*h/(4*math.pi*H**2)/Ms,
                  uncertified_terms=['KDE-to-finite-Fourier uniform approximation', 'floating-point coordinates versus ideal j*h',
                                     'floating-point node, exponential and tensor evaluation'],
                  times=dict(kde=kde_seconds, tensor=tensor_seconds, ph=ph_seconds))
    if len(bars['length']):
        minimum, merge = int(bars['birth'][0]), int(bars['death'][0])
        result['longest_pair'] = dict(minimum_index=minimum, merge_index=merge,
                                     minimum_height=float(F.ravel()[minimum]), merge_height=float(F.ravel()[merge]))
    del F, field, coeff
    t = time.perf_counter()
    try:
        saved = arrays_read(attempt / 'coefficients.npz', coeff_desc)
        K = k_triangle(saved['c_real'], saved['c_imag'], saved['xi_p'], saved['xi_q'], saved['wq'])
        envelope = scaling_envelope(n, h, Ms, K)
        result.update(K_triangle=upward(K), scaling=envelope, E_T_upper=envelope['E_T_upper']['value'],
                      budget_flag='BELOW_0_1_MS' if envelope['threshold_relation'] == 'BELOW' else 'RETAIN_OVER_OR_UNRESOLVED_BUDGET')
    except (ArithmeticError, ValueError) as exc:
        # Preserve a known numerical value plus an explicit missing budget; stop the supervisor afterwards.
        result.update(K_triangle=None, scaling=None, E_T_upper=None, budget_flag='BUDGET_MISSING',
                      budget_error=repr(exc), budget_traceback=traceback.format_exc())
    result['times'].update(fraction=time.perf_counter()-t, compute_total=time.perf_counter()-start)
    checkpoint('PAYLOAD_READY', Ynum=y, E_T_upper=result['E_T_upper'], budget_flag=result['budget_flag'])
    return result, {'coefficients.npz': attempt / 'coefficients.npz', 'bars.npz': attempt / 'bars.npz'}
