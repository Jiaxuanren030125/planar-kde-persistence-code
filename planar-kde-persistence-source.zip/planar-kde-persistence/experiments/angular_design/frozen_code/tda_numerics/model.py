"""Task76: generic quartic ray only; no old-family Model initialization."""
import math
TWO_PI = 2.0 * math.pi

def psi_ray(U, b, t):
    """Length of the quartic bar for Q(x)=U x^2 - b x^4 + t x on the ray, using the trigonometric cubic solution."""
    if U <= 0.0:
        return 0.0
    if t == 0.0:
        return U * U / (4.0 * b)
    tc = 4.0 * U ** 1.5 / (3.0 * math.sqrt(6.0 * b))
    if t >= tc:
        return 0.0
    # x^3 + p x + q = 0 with p=-U/(2b), q=-t/(4b); three real roots
    p = -U / (2.0 * b)
    qq = -t / (4.0 * b)
    A = 2.0 * math.sqrt(-p / 3.0)
    arg = 3.0 * qq / (p * A)
    arg = max(-1.0, min(1.0, arg))
    th = math.acos(arg) / 3.0
    roots = sorted(A * math.cos(th - 2.0 * math.pi * k / 3.0) for k in range(3))
    x1, x2 = roots[0], roots[1]
    S = 3.0 * b * x1 ** 4 - U * x1 ** 2
    m = 3.0 * b * x2 ** 4 - U * x2 ** 2
    return S - m

