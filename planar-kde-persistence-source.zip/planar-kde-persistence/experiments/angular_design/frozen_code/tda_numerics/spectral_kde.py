"""Exact full-sample Gaussian KDE: direct summation on a Nyquist-adequate node set, then trigonometric evaluation anywhere.

Why this replaces the binned FFT of check_theorem.py
---------------------------------------------------
* There is NO input window: every observation contributes its full kernel at every node.  There is no histogram and
  no kernel truncation.  The node values are exact direct sums up to floating-point rounding.
* The Gaussian KDE is numerically band-limited: its Fourier transform obeys |F(xi)| <= exp(-H |xi|^2 / 2).  Values and
  derivatives at arbitrary points therefore follow from the node values with a spectrally small, explicitly bounded
  error (aliasing_bound and wrap_bound below).  The cost of the output grid does not depend on n.
* Same estimator everywhere: L_num, G_n, M_n and every polished critical value derive from one sample and one formula.

Period/box geometry: nodes x_j = -P/2 + j*Delta, j=0..N-1, N even.  The box half-width W_p=P/2 must exceed the sample
extent by `pad`, so the periodic images of every kernel are negligible on the output box; wrap_bound records that.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from .model import TWO_PI

EPS = np.finfo(float).eps


def gauss1(t, H):
    return np.exp(-t * t / (2.0 * H)) / math.sqrt(TWO_PI * H)


def _he(a, z):
    """Probabilists' Hermite polynomial He_a(z), a=0..5 (explicit, no recurrence state to get wrong)."""
    if a == 0:
        return np.ones_like(z)
    if a == 1:
        return z
    if a == 2:
        return z * z - 1.0
    if a == 3:
        return z * (z * z - 3.0)
    if a == 4:
        return z ** 4 - 6.0 * z * z + 3.0
    if a == 5:
        return z * (z ** 4 - 10.0 * z * z + 15.0)
    raise ValueError("derivative order too high")


def gauss1_deriv(t, H, a):
    """a-th derivative in t of the N(0,H) density g(t): (-1)^a H^{-a/2} He_a(t/sqrt H) g(t)."""
    rt = math.sqrt(H)
    return (-1.0) ** a * rt ** (-a) * _he(a, t / rt) * gauss1(t, H)


def direct_points(pts, X, H, deriv=(0, 0), chunk=2_000_000):
    """Direct full-sample evaluation of the (a,b) partial derivative of fhat at the points pts (M x 2). O(M n)."""
    pts = np.atleast_2d(np.asarray(pts, dtype=float))
    a, b = deriv
    n = len(X)
    out = np.zeros(len(pts))
    for k, p in enumerate(pts):
        acc = 0.0
        for start in range(0, n, chunk):
            c = X[start:start + chunk]
            acc += float(np.sum(gauss1_deriv(p[0] - c[:, 0], H, a) * gauss1_deriv(p[1] - c[:, 1], H, b)))
        out[k] = acc / n
    return out


def direct_nodes(xnodes, X, H, chunk=4096):
    """fhat on the tensor product xnodes x xnodes by direct separable summation. Cost O(N^2 n); memory O(N chunk)."""
    n = len(X)
    N = len(xnodes)
    F = np.zeros((N, N))
    for start in range(0, n, chunk):
        c = X[start:start + chunk]
        Ax = gauss1(xnodes[:, None] - c[:, 0][None, :], H)
        Ay = gauss1(xnodes[:, None] - c[:, 1][None, :], H)
        F += Ax @ Ay.T
    return F / n


def aliasing_bound(H, P, N, order=0):
    """Upper bound for the trigonometric-interpolation aliasing error of an order-`order` derivative of any function
    whose Fourier coefficients satisfy |c_pq| <= P^{-2} exp(-H |xi|^2/2) (every KDE with this kernel does, |phi_emp|<=1).
    Twice the l1 mass outside the retained box |p|,|q| < N/2 with the |xi|^order factor."""
    dxi = TWO_PI / P
    kmax = int(N * 4)
    k = np.arange(-kmax, kmax + 1)
    xi = k * dxi
    w = np.exp(-H * xi * xi / 2.0)
    wk = w * np.maximum(np.abs(xi), 1.0 if order == 0 else 0.0) ** order if order else w
    inside = np.abs(k) < N / 2
    total_all = float(np.sum(wk)) * float(np.sum(w))
    total_in = float(np.sum(wk[inside])) * float(np.sum(w[inside]))
    # floating subtraction would lose the tiny tail: sum the tail directly
    tail1 = float(np.sum(wk[~inside]))
    tail2 = float(np.sum(w[~inside]))
    outside = tail1 * float(np.sum(w)) + float(np.sum(wk)) * tail2
    del total_all, total_in
    return 2.0 * 2.0 * outside / (P * P)


def wrap_bound(X, H, W_p, output_halfwidth, order=0):
    """Upper bound on the contribution of periodic images on the node set and output box.

    For x in the box and observation X_i, every image kernel k != 0 sits at coordinate distance at least
    d_ij = 2 W_p - max(W_p, output_halfwidth) - |X_ij| in at least one coordinate.  Each kernel value is at most
    (2 pi H)^{-1} exp(-d^2/(2H)); a factor 4 covers images on both sides and in both coordinates, and the derivative
    prefactor is bounded by (order!)^{1/2} ((d/H) + 1/sqrt H)^order to stay conservative.

    This bounds the image sum only.  Nodes hold fhat, not its periodization, so off-node evaluation also contains ringing from the
    seam jump.  The independent review measured total error above this budget at pad <= 1 sd (factor 4.24 at pad .5 sd, order 3) and
    at most 0.49 of it from pad 2 sd up.  The engine always uses pad 8 sd.  output_halfwidth is not used: W_p always covers the output box."""
    d = W_p - np.abs(X)   # because max(W_p, output_halfwidth)=W_p here
    d = np.maximum(d, 0.0)
    pref = 1.0
    if order:
        pref = (float(d.max()) / H + 1.0 / math.sqrt(H)) ** order * math.sqrt(math.factorial(order))
    per = np.exp(-d * d / (2.0 * H))
    return 4.0 * pref * float(np.mean(per[:, 0] + per[:, 1])) / (TWO_PI * H)


@dataclass
class SpectralField:
    """A real field known at the N x N periodic nodes; evaluates values/derivatives at arbitrary points."""
    Fnodes: np.ndarray
    P: float
    H: float
    meta: dict = field(default_factory=dict)

    def __post_init__(self):
        N = self.Fnodes.shape[0]
        if N % 2:
            raise ValueError("N must be even")
        self.N = N
        self.Delta = self.P / N
        self.max_nodes = float(np.abs(self.Fnodes).max())
        c = np.fft.rfft2(self.Fnodes) / (N * N)
        # Nyquist rows/columns carry only aliasing-level mass for an adequately resolved KDE: drop them so that every
        # derivative order is treated identically.  nyquist_mass records what was dropped (QA checks it against the bound).
        ny_mass = float(np.abs(c[N // 2, :]).sum() + np.abs(c[:, N // 2]).sum())
        c[N // 2, :] = 0.0
        c[:, N // 2] = 0.0
        self.c = c
        self.nyquist_mass = ny_mass
        self.xi_p = TWO_PI * np.fft.fftfreq(N, d=1.0 / N) / self.P
        self.xi_q = TWO_PI * np.arange(N // 2 + 1) / self.P
        self.wq = np.full(N // 2 + 1, 2.0)
        self.wq[0] = 1.0
        self.wq[N // 2] = 1.0
        self._coef_cache = {}

    # shift of the node origin
    def _Ex(self, x):
        return np.exp(1j * np.outer(np.asarray(x, dtype=float) + self.P / 2.0, self.xi_p))

    def _Ey(self, y):
        return np.exp(1j * np.outer(np.asarray(y, dtype=float) + self.P / 2.0, self.xi_q))

    def _coef(self, deriv):
        got = self._coef_cache.get(deriv)
        if got is None:
            a, b = deriv
            got = self.c if a == 0 and b == 0 else self.c * ((1j * self.xi_p[:, None]) ** a) * ((1j * self.xi_q[None, :]) ** b)
            self._coef_cache[deriv] = got
        return got

    def tensor(self, x, y, deriv=(0, 0)):
        """Field or derivative on the tensor grid x X y; returns len(x) x len(y)."""
        Ex = self._Ex(x)
        Ey = self._Ey(y) * self.wq
        Z = Ex @ self._coef(deriv)
        return np.real(Z @ Ey.T)

    def tensor_many(self, x, y, derivs):
        Ex = self._Ex(x)
        Ey = (self._Ey(y) * self.wq).T
        return {d: np.real((Ex @ self._coef(d)) @ Ey) for d in derivs}

    def points(self, pts, deriv=(0, 0)):
        pts = np.atleast_2d(np.asarray(pts, dtype=float))
        Ex = self._Ex(pts[:, 0])
        Ey = self._Ey(pts[:, 1]) * self.wq
        return np.real(np.sum((Ex @ self._coef(deriv)) * Ey, axis=1))

    def points_many(self, pts, derivs):
        pts = np.atleast_2d(np.asarray(pts, dtype=float))
        Ex = self._Ex(pts[:, 0])
        Ey = self._Ey(pts[:, 1]) * self.wq
        return {d: np.real(np.sum((Ex @ self._coef(d)) * Ey, axis=1)) for d in derivs}

    def noise_allowance(self, deriv=(0, 0)):
        """Apple empirical allowance is not validated on Windows."""
        raise RuntimeError("Task76 uses measured Windows direct-sum errors, not Apple NOISE_CONSTANT")

    def spectrum_tail_check(self):
        """Mass of the top 2% of |frequency| box (a resolved field has only rounding noise there)."""
        N = self.N
        p = np.abs(np.fft.fftfreq(N, d=1.0 / N))[:, None]
        q = np.arange(N // 2 + 1)[None, :]
        mask = (p > 0.49 * N) | (q > 0.49 * N)
        return float(np.abs(self.c[mask]).max()) if mask.any() else 0.0


def choose_box(H, extent, delta_target=None, pad=None):
    """Return (W_p, N, Delta): nodes adequate for this kernel variance and this sample extent."""
    sd = math.sqrt(H)
    if delta_target is None:
        delta_target = 0.25 * sd         # xi_N = 4 pi / sd : exp(-H xi^2/2) = exp(-8 pi^2) ~ 6e-35
    if pad is None:
        pad = 8.0 * sd                   # image kernels at >= 8 sd: exp(-32) ~ 1e-14 of one kernel of weight 1/n
    W_p = extent + pad
    N = int(math.ceil(2.0 * W_p / delta_target))
    N += N % 2
    return W_p, N, 2.0 * W_p / N


def kde_field(X, H, delta_target=None, pad=None, chunk=4096, output_halfwidth=None):
    """Build the SpectralField of the full-sample KDE by direct summation.  Returns the field with an error budget."""
    X = np.asarray(X, dtype=float)
    if X.ndim != 2 or X.shape[1] != 2 or len(X) == 0:
        raise ValueError("X must be a non-empty n x 2 array")
    if not np.isfinite(X).all():
        raise ValueError("non-finite observation")
    extent = float(np.abs(X).max())
    W_p, N, Delta = choose_box(H, extent if output_halfwidth is None else max(extent, output_halfwidth), delta_target, pad)
    xn = -W_p + Delta * np.arange(N)
    F = direct_nodes(xn, X, H, chunk=chunk)
    fld = SpectralField(F, 2.0 * W_p, H)
    fld.meta = dict(kind="kde_direct_sum", n=len(X), extent=extent, W_p=W_p, N=N, Delta=Delta, chunk=chunk,
                    aliasing_bound={str(k): aliasing_bound(H, 2.0 * W_p, N, k) for k in (0, 1, 2, 3)},
                    wrap_bound={str(k): wrap_bound(X, H, W_p, extent, k) for k in (0, 1, 2, 3)},
                    nyquist_mass=fld.nyquist_mass,
                    input_points_kept=int(len(X)), input_points_dropped=0)
    return fld


def closed_form_field(func, H, W_p, delta_target=None):
    """SpectralField from a closed-form band-limited function func(x,y) (arrays).  Used only by deterministic fixtures."""
    sd = math.sqrt(H)
    if delta_target is None:
        delta_target = 0.25 * sd
    N = int(math.ceil(2.0 * W_p / delta_target))
    N += N % 2
    Delta = 2.0 * W_p / N
    xn = -W_p + Delta * np.arange(N)
    XX, YY = np.meshgrid(xn, xn, indexing="ij")
    fld = SpectralField(func(XX, YY), 2.0 * W_p, H)
    fld.meta = dict(kind="closed_form", W_p=W_p, N=N, Delta=Delta)
    return fld


def origin_jet(X, H):
    """Exact full-sample gradient and Hessian at 0 plus the radial coefficients Ubar, Vbar used in Rounds 4-6.

    grad fhat(0) = (1/n) sum phi_H(X_i) X_i / H ;   D^2 fhat(0) = (1/n) sum phi_H(X_i) (X_i X_i^T / H^2 - I / H).
    Ubar = (1/4) tr D^2 fhat(0);  Vbar = (1/n) sum (S^2-8HS+8H^2) exp(-S/(2H)) / (128 pi H^5), S=|X_i|^2."""
    X = np.asarray(X, dtype=float)
    S = np.sum(X * X, axis=1)
    phi = np.exp(-S / (2.0 * H)) / (TWO_PI * H)
    g = np.array([np.mean(phi * X[:, 0]), np.mean(phi * X[:, 1])]) / H
    h11 = float(np.mean(phi * (X[:, 0] ** 2 / H ** 2 - 1.0 / H)))
    h22 = float(np.mean(phi * (X[:, 1] ** 2 / H ** 2 - 1.0 / H)))
    h12 = float(np.mean(phi * (X[:, 0] * X[:, 1] / H ** 2)))
    U = float(np.mean((S - 2.0 * H) * np.exp(-S / (2.0 * H)))) / (8.0 * math.pi * H ** 3)
    V = float(np.mean((S * S - 8.0 * H * S + 8.0 * H * H) * np.exp(-S / (2.0 * H)))) / (128.0 * math.pi * H ** 5)
    return dict(grad=g, hess=np.array([[h11, h12], [h12, h22]]), Ubar=U, Vbar=V, f0=float(np.mean(phi)))
