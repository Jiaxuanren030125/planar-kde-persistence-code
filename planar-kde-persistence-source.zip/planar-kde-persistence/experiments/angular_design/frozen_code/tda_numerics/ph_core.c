/* ph_core.c -- zero-dimensional persistence of grid sublevel sets with a virtual exterior vertex.
 *
 *
 * Object.  Vertices are the nx*ny grid nodes with heights f.  A vertex enters at its height; an edge enters when both
 * endpoints are present (lower-star filtration of the chosen 1-skeleton).  A virtual exterior vertex is present from
 * -infinity and is adjacent to every window-boundary vertex.  Components merge by the elder rule; the exterior is always
 * the elder.  A finite bar (birth vertex u, death vertex v) has length f[v]-f[u].  Zero-length pairs are counted, not
 * reported.  The total order on vertices is the supplied `order` (the caller sorts by (height, index)).
 *
 * Adjacency modes:
 *   4 : axis neighbours.                     Dual of the cubical T-construction (top cells = pixels) of the superlevels.
 *   6 : axis neighbours and the (+1,+1) diagonal.  1-skeleton of the Kuhn/Freudenthal triangulation: lower-star
 *       persistence of the PL interpolant.  PRIMARY object of this engine.
 *   7 : axis neighbours and the (+1,-1) diagonal.  The other Kuhn triangulation (orientation sensitivity).
 *   8 : axis neighbours and both diagonals.   Dual of the cubical V-construction of the superlevels (check_theorem.py).
 */
#include <stdint.h>
#include <stdlib.h>

static inline int32_t uf_find(int32_t *parent, int32_t a)
{
    while (parent[a] != a) {
        parent[a] = parent[parent[a]];
        a = parent[a];
    }
    return a;
}

/* returns the number of positive-length bars, or -1 on allocation failure, -2 on capacity overflow, -3 on bad mode */
int64_t uf_bars(const double *f, const int64_t *order, int64_t nx, int64_t ny, int mode,
                int64_t *birth_out, int64_t *death_out, int64_t cap, int64_t *zero_pairs_out)
{
    static const int off4[4][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
    static const int off6[6][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}, {1, 1}, {-1, -1}};
    static const int off7[6][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}, {1, -1}, {-1, 1}};
    static const int off8[8][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}, {1, 1}, {-1, -1}, {1, -1}, {-1, 1}};
    const int (*off)[2];
    int deg;
    switch (mode) {
    case 4: off = off4; deg = 4; break;
    case 6: off = off6; deg = 6; break;
    case 7: off = off7; deg = 6; break;
    case 8: off = off8; deg = 8; break;
    default: return -3;
    }
    const int64_t N = nx * ny;
    const int32_t EXT = (int32_t)N;
    int32_t *parent = malloc(sizeof(int32_t) * (size_t)(N + 1));
    int32_t *eldest = malloc(sizeof(int32_t) * (size_t)(N + 1));   /* root -> birth vertex of the component */
    int32_t *rank_of = malloc(sizeof(int32_t) * (size_t)(N + 1));  /* vertex -> position in `order` */
    int32_t *size = malloc(sizeof(int32_t) * (size_t)(N + 1));
    unsigned char *present = calloc((size_t)(N + 1), 1);
    if (!parent || !eldest || !rank_of || !size || !present) {
        free(parent); free(eldest); free(rank_of); free(size); free(present);
        return -1;
    }
    for (int64_t p = 0; p < N; ++p) rank_of[order[p]] = (int32_t)p;
    rank_of[EXT] = -1;
    parent[EXT] = EXT;
    eldest[EXT] = EXT;
    size[EXT] = 1;
    present[EXT] = 1;
    int64_t bars = 0, zero = 0;

    for (int64_t pos = 0; pos < N; ++pos) {
        const int32_t v = (int32_t)order[pos];
        const int64_t i = v / ny, j = v % ny;
        parent[v] = v; eldest[v] = v; size[v] = 1; present[v] = 1;
        const double fv = f[v];
        const int boundary = (i == 0 || j == 0 || i == nx - 1 || j == ny - 1);
        for (int k = -1 + (boundary ? 0 : 1); k < deg; ++k) {
            int32_t u;
            if (k < 0) {
                u = EXT;
            } else {
                const int64_t a = i + off[k][0], c = j + off[k][1];
                if (a < 0 || a >= nx || c < 0 || c >= ny) continue;
                u = (int32_t)(a * ny + c);
                if (!present[u]) continue;
            }
            int32_t ru = uf_find(parent, u), rv = uf_find(parent, v);
            if (ru == rv) continue;
            int32_t eu = eldest[ru], ev = eldest[rv];
            int32_t young_birth, elder_birth;
            if (rank_of[eu] < rank_of[ev]) { elder_birth = eu; young_birth = ev; }
            else                           { elder_birth = ev; young_birth = eu; }
            const double len = fv - f[young_birth];
            if (len > 0.0) {
                if (bars >= cap) {
                    free(parent); free(eldest); free(rank_of); free(size); free(present);
                    return -2;
                }
                birth_out[bars] = young_birth;
                death_out[bars] = v;
                ++bars;
            } else {
                ++zero;
            }
            if (size[ru] < size[rv]) { int32_t t = ru; ru = rv; rv = t; }
            parent[rv] = ru;
            size[ru] += size[rv];
            eldest[ru] = elder_birth;
        }
    }
    *zero_pairs_out = zero;
    free(parent); free(eldest); free(rank_of); free(size); free(present);
    return bars;
}
