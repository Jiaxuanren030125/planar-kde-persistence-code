"""Task76 PL-only Windows preflight; no formal run entry point."""
ENGINE_VERSION = "task76_windows_preflight_v1"
