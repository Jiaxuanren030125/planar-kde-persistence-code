"""Recompute saved-record summaries only. No RNG, KDE or PH execution.
"""
from pathlib import Path
import argparse,csv,hashlib,json,math,os,sys,zipfile
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ.setdefault(key,'1')
def records(experiment):
    archive=ROOT/'data'/(experiment+'_records.zip')
    with zipfile.ZipFile(archive) as z:
        manifest=json.loads(z.read('MEMBER_MANIFEST.json'))['files']
        rows=[]
        for name,meta in manifest.items():
            raw=z.read(name)
            if len(raw)!=meta['bytes'] or hashlib.sha256(raw).hexdigest()!=meta['sha256']:
                raise ValueError('Changed saved member: '+name)
            if experiment=='gaussian_difference':rows.extend(json.loads(raw)['rows'])
            elif name.endswith('/result/record.json'):rows.append(json.loads(raw))
    return rows

def compare(a,b,path='root'):
    errors=[]
    if isinstance(a,dict) and isinstance(b,dict):
        if set(a)!=set(b):errors.append(path+': keys differ')
        for k in set(a)&set(b):errors.extend(compare(a[k],b[k],path+'.'+k))
    elif isinstance(a,(list,tuple)) and isinstance(b,(list,tuple)):
        if len(a)!=len(b):errors.append(path+': lengths differ')
        for i,(x,y) in enumerate(zip(a,b)):errors.extend(compare(x,y,path+'.'+str(i)))
    elif isinstance(a,(int,float)) and isinstance(b,(int,float)):
        if not math.isclose(a,b,rel_tol=2e-11,abs_tol=2e-13):errors.append(path+': numeric difference')
    elif a!=b:errors.append(path+': values differ')
    return errors

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--experiment',choices=['gaussian_difference','angular_design'],required=True)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--plots',action='store_true',help='Regenerate historical plots from saved rows only')
    args=ap.parse_args();out=args.output.resolve()
    if out.exists():ap.error('Output must be a new directory')
    protected=[ROOT/'experiments',ROOT/'data',ROOT/'tools',ROOT/'figures']
    if any(p==out or p in out.parents for p in protected):ap.error('Use work/ or another new output directory')
    out.mkdir(parents=True)
    os.environ['MPLCONFIGDIR']=str(out/'matplotlib-cache')
    rows=records(args.experiment)
    if args.experiment=='gaussian_difference':
        import gaussian_analysis_portable as a
        design=json.loads((ROOT/'experiments/gaussian_difference/frozen_code/candidate/DESIGN_CANDIDATE.json').read_text())
        expected={(c['cell'],r,design['seed_base']+10000*c['cell']+r) for c in design['cells'] for r in range(c['reps'])}
        identities=[(r['cell'],r['rep'],r['seed']) for r in rows]
        assert len(rows)==len(expected) and set(identities)==expected
        result=a.analyze(rows,design)
        reference=json.loads((ROOT/'experiments/gaussian_difference/saved_analysis/analysis_tables.json').read_text())
        differences=compare(result,reference)
        (out/'analysis_tables.json').write_text(json.dumps(result,indent=2))
        if args.plots:a.figures(result,rows,out,None)
    else:
        import angular_analysis_portable as a
        expected={(c,r,20261105800000+1000*c+r) for c in range(12) for r in range(200)}
        identities=[(r['identity']['cell'],r['identity']['rep'],r['identity']['seed']) for r in rows]
        assert len(rows)==len(expected) and set(identities)==expected
        summary={'all_rows_ready':True,'mode':'FORMAL_LIMITED_DISPLAY'}
        result=a.counts(rows,summary)
        for row in result:row.update(a.cp95_for_count(row['exceeded'],row['completed']))
        reference=list(csv.DictReader((ROOT/'experiments/angular_design/saved_analysis/threshold_counts.csv').open()))
        differences=[]
        assert len(reference)==len(result)==36
        for i,(new,old) in enumerate(zip(result,reference)):
            for key,value in new.items():
                if isinstance(value,(int,float)):
                    if not math.isclose(float(old[key]),value,rel_tol=2e-11,abs_tol=2e-13):differences.append(str(i)+':'+key)
                elif str(value or '')!=old[key]:differences.append(str(i)+':'+key)
        a.csv_write(out/'threshold_counts.csv',result,list(result[0]))
        if args.plots:
            a.ROOT=out
            a.make_plot(rows,summary,out)
    report={'experiment':args.experiment,'rows':len(rows),'identities_complete':True,'saved_summary_matches_with_numeric_tolerance':not differences,'differences':differences,'no_new_sampling_KDE_or_PH':True,'scope':'NUMERIC_SCOPE_LIMITED','note':'This recomputes saved records; omitted raw arrays are not verified.'}
    (out/'RECOMPUTATION.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))
    return 0 if not differences else 1
if __name__=='__main__':raise SystemExit(main())
