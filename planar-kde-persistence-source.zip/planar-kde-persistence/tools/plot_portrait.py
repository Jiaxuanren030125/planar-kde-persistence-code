"""Redraw first-paper figures3/4 in portrait layout from saved plot_data.json.
Standalone requirements: numpy,matplotlib. No science-code import or stochastic
operations.
Usage: python plot_portrait.py --input plot_data.json --out-dir output
"""
from pathlib import Path
import argparse,hashlib,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def nlabel(n):return r'$n=10^{%d}$'%int(np.log10(n))
def main(input_path,out):
 input_path=Path(input_path).resolve();out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True)
 data=json.loads(input_path.read_text());cells=data['cells'];ns=sorted({c['n'] for c in cells});tau=data['main_tau']
 assert len(cells)==8 and sum(len(c['primary']) for c in cells)==3200
 colors=dict(zip(ns,('#1f4e79','#c0792a')));markers=dict(zip(ns,'os'));styles=dict(zip(ns,('-','--')))
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9.5,'axes.labelsize':9.5,'axes.titlesize':10,'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42,'axes.titlepad':4,'axes.labelpad':3})
 figures=[];point_log=[];style_log=[];square_log=[]
 fig,axes=plt.subplots(3,1,figsize=(5.15,6.0),layout='constrained')
 ax=axes[0];ref=data['limit_curves']['threshold'];limit_line,=ax.plot(ref['s'],ref['rate'],color='black',ls='-',lw=1.8,label=r'Limit $\Pr(\Psi_s(G)>0.05)$')
 for ni,n in enumerate(ns):
  cc=[c for c in cells if c['n']==n];xs=np.array([c['s'] for c in cc])+.04*(ni-(len(ns)-1)/2)
  ev=[c['threshold_event'] for c in cc];rate=np.array([e['rate_nominal'] for e in ev]);lo=np.array([e['cp95_nominal'][0] for e in ev]);hi=np.array([e['cp95_nominal'][1] for e in ev]);elo=[e['sensitivity_envelope'][0] for e in ev];ehi=[e['sensitivity_envelope'][1] for e in ev]
  ax.vlines(xs,elo,ehi,color=colors[n],lw=5,alpha=.18)
  err=ax.errorbar(xs,rate,yerr=[rate-lo,hi-rate],fmt=markers[n],ms=4,capsize=2.5,lw=.9,color=colors[n],label=nlabel(n))
  assert err.lines[0].get_linestyle()=='None'
  style_log.append({'panel':'a','n':n,'color':colors[n],'data_style':'markers_and_error_bars_only','line_width':.9})
  for c in cc:point_log.append({'figure':3,'panel':'a','cell':c['cell'],'rows':400,'threshold':tau,'count':c['threshold_event']['k_nominal']})
 style_log.append({'panel':'a','curve':'limit','color':limit_line.get_color(),'line_style':limit_line.get_linestyle(),'line_width':limit_line.get_linewidth()})
 ax.legend(frameon=False,loc='upper left',fontsize=9);ax.set(xlabel=r'Local parameter $s$',ylabel='Exceedance rate',ylim=(-.03,1.03),title=r'(a) Threshold $n^{2/3}L_{\mathrm{PL}}>0.05$');ax.grid(alpha=.12)
 for k,ref in enumerate(data['limit_curves']['cdf']):
  ax=axes[k+1];s=ref['s'];chosen=[c for c in cells if c['s']==s];xmax=1.02*max([max(ref['x'])]+[max(c['primary']) for c in chosen]);xx=np.array(ref['x']);F=np.array(ref['F'])
  limit_line,=ax.plot(np.r_[0.,0.,xx,xmax],np.r_[0.,F[0],F,1.],color='black',ls='-',lw=1.8,label='Limiting CDF')
  style_log.append({'panel':'bc'[k],'curve':'limit','color':limit_line.get_color(),'line_style':limit_line.get_linestyle(),'line_width':limit_line.get_linewidth()})
  for c in chosen:
   vals=np.sort(c['primary']);assert len(vals)==400;u=np.unique(np.r_[0.,vals,xmax]);right=np.searchsorted(vals,u,side='right')/len(vals)
   # Compress repeated values without removing their mass; explicit zero jump.
   xp=np.r_[0.,u];yp=np.r_[0.,right];line,=ax.step(xp,yp,where='post',lw=.9,color=colors[c['n']],ls=styles[c['n']],label=nlabel(c['n']))
   style_log.append({'panel':'bc'[k],'n':c['n'],'color':line.get_color(),'line_style':line.get_linestyle(),'line_width':line.get_linewidth()})
   point_log.append({'figure':3,'panel':'bc'[k],'cell':c['cell'],'rows':400,'zeros':int(np.sum(vals==0)),'CDF_at_zero':float(np.mean(vals==0)),'max_observed':float(vals.max()),'plotted_xmax':xmax})
  ax.set(xlabel=r'$n^{2/3}L_{\mathrm{PL}}$',ylabel='CDF',xlim=(0,xmax),ylim=(-.03,1.03),title=r'(%s) $s=%g$'%('bc'[k],s));ax.legend(frameon=False,loc='lower right',fontsize=9);ax.grid(alpha=.12)
 for ext in ['pdf','png']:
  p=out/f'display1_threshold_rate_and_cdf_portrait.{ext}';fig.savefig(p,dpi=220);figures.append(p)
 plt.close(fig)
 # Each row uses the same range for both predictors and square plotting axes.
 positive=[c for c in cells if c['s']>0];assert len(positive)==4
 fig=plt.figure(figsize=(5.15,7.0))
 square_inches=1.20;left_inches=[.65,3.07];bottoms=[5.39,3.74,2.09,.44]
 axes=np.empty((4,2),dtype=object)
 for j in range(4):
  for i in range(2):
   axes[j,i]=fig.add_axes([left_inches[i]/5.15,bottoms[j]/7.0,square_inches/5.15,square_inches/7.0])
 for i,label in enumerate(['Tilt approximation','Full-Hessian approximation']):
  fig.text((left_inches[i]+square_inches/2)/5.15,6.94/7.0,label,ha='center',va='top',fontsize=9.5)
 for j,c in enumerate(positive):
  y=np.asarray(c['primary']);assert len(y)==400
  predictors=[np.asarray(c['comparators'][name]) for name in ['Psi_leading','L_Qtilde']]
  top=float(np.max(np.r_[y,predictors[0],predictors[1],.05]))*1.03
  assert np.all(y>=0) and all(np.all(v>=0) for v in predictors)
  for i,name in enumerate(['Psi_leading','L_Qtilde']):
   ax=axes[j,i];v=predictors[i];assert len(v)==400 and np.all(np.isfinite(v)) and np.all(np.isfinite(y))
   points,=ax.plot(v,y,'.',ms=2.6,color=colors[c['n']],rasterized=False)
   assert np.array_equal(points.get_xdata(),v) and np.array_equal(points.get_ydata(),y)
   assert np.max(v)<top and np.max(y)<top
   ax.plot([0,top],[0,top],color='black',lw=.8)
   e=c['errors'][name]
   title=r'$n=10^{%d}, s=%g$'%(int(np.log10(c['n'])),c['s'])
   metrics='MAE %.3f\nRMSE %.3f'%(e['mae'],e['rmse'])
   ax.text(1.055,.96,metrics,transform=ax.transAxes,va='top',fontsize=9,linespacing=1.1)
   ax.set(xlim=(0,top),ylim=(0,top));ax.set_title(title,fontsize=9,pad=2)
   ax.set_aspect('equal',adjustable='box')
   ax.xaxis.set_major_locator(MaxNLocator(nbins=3));ax.yaxis.set_major_locator(MaxNLocator(nbins=3));ax.tick_params(labelsize=9,pad=1.5)
   if i==0:ax.set_ylabel(r'$n^{2/3}L_{\mathrm{PL}}$',fontsize=9,labelpad=3)
   if j==3:ax.set_xlabel(r'$\Psi_s(G_n)$' if i==0 else r'$L(\widetilde Q_n)$',fontsize=9.5,labelpad=2)
   pairs=np.ascontiguousarray(np.column_stack((v,y)),dtype='<f8')
   point_log.append({'figure':4,'old_row':i,'old_column':j,'new_row':j,'new_column':i,'cell':c['cell'],'n':c['n'],'s':c['s'],'comparator':name,'points':400,'primary_zeros':int(np.sum(y==0)),'comparator_zeros':int(np.sum(v==0)),'paired_zero_zero':int(np.sum((y==0)&(v==0))),'axis_upper':top,'range_source':'max(primary, both predictors, 0.05) times 1.03','all_points_in_bounds':True,'plotted_pairs_sha256':hashlib.sha256(pairs.tobytes()).hexdigest(),'mae':e['mae'],'rmse':e['rmse']})
 fig.canvas.draw();renderer=fig.canvas.get_renderer()
 for j in range(4):
  assert axes[j,0].get_xlim()==axes[j,1].get_xlim()==axes[j,0].get_ylim()==axes[j,1].get_ylim()
  for i in range(2):
   ax=axes[j,i];box=ax.get_window_extent(renderer);width=box.width/fig.dpi;height=box.height/fig.dpi
   assert abs(width-height)<1e-10 and abs(width-square_inches)<1e-10
   tight=ax.get_tightbbox(renderer);assert tight.x0>=0 and tight.y0>=0 and tight.x1<=fig.bbox.width and tight.y1<=fig.bbox.height, (j,i,list(tight.extents),list(fig.bbox.extents))
   square_log.append({'row':j,'column':i,'width_inches':width,'height_inches':height,'screen_aspect':width/height,'xlim':list(ax.get_xlim()),'ylim':list(ax.get_ylim()),'all_decorations_in_figure':True})
 for j in range(3):
  for i in range(2):
   upper=axes[j,i].get_tightbbox(renderer);lower=axes[j+1,i].get_tightbbox(renderer)
   assert upper.y0>lower.y1, ('Adjacent row labels overlap',j,i,upper.y0-lower.y1)
 for ext in ['pdf','png']:
  p=out/f'display2_same_sample_errors_portrait.{ext}';fig.savefig(p,dpi=220);figures.append(p)
 plt.close(fig)
 (out/'PLOT_CHECK.json').write_text(json.dumps({'status':'PASS','scope':'Layout-only plotting of supplied saved values. No RNG/KDE/PH. All zero values and all400 paired observations retained. Plotting all points may overlap markers but does not remove rows.','input_sha256':sha(input_path),'script_sha256':sha(__file__),'font_sizes_pt':{'labels':9.5,'ticks':9,'legends':9,'statistics':9,'titles':9},'physical_size_inches':{'figure3':[5.15,6.0],'figure4':[5.15,7.0]},'figure3_styles':style_log,'figure4_square_axes':square_log,'panel_mapping':point_log,'outputs':[{'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in figures]},indent=2)+'\n')
 print('PASS portrait figures; all plotted values come from',input_path)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--input',type=Path,default=Path(__file__).resolve().parent/'plot_data.json');a.add_argument('--out-dir',type=Path,default=Path(__file__).resolve().parent);args=a.parse_args();main(args.input,args.out_dir)
