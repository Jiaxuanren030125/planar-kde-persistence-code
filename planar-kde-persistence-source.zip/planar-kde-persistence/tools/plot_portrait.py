"""Redraw first-paper figures3/4 in portrait layout from saved plot_data.json.
Standalone requirements: numpy,matplotlib. No science-code import or stochastic
operations.
Usage: python plot_portrait.py --input plot_data.json --out-dir output
"""
from pathlib import Path
import argparse,hashlib,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def nlabel(n):return r'$n=10^{%d}$'%int(np.log10(n))
def main(input_path,out):
 input_path=Path(input_path).resolve();out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True)
 data=json.loads(input_path.read_text());cells=data['cells'];ns=sorted({c['n'] for c in cells});tau=data['main_tau']
 assert len(cells)==8 and sum(len(c['primary']) for c in cells)==3200
 colors=dict(zip(ns,('#1f4e79','#c0792a')));markers=dict(zip(ns,'os'));styles=dict(zip(ns,('-','--')))
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9.5,'axes.labelsize':9.5,'axes.titlesize':10,'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42,'axes.titlepad':4,'axes.labelpad':3})
 figures=[];point_log=[]
 fig,axes=plt.subplots(3,1,figsize=(5.15,6.0),layout='constrained')
 ax=axes[0];ref=data['limit_curves']['threshold'];ax.plot(ref['s'],ref['rate'],color='black',lw=1.2,label=r'Limit $\Pr(\Psi_s(G)>0.05)$')
 for ni,n in enumerate(ns):
  cc=[c for c in cells if c['n']==n];xs=np.array([c['s'] for c in cc])+.04*(ni-(len(ns)-1)/2)
  ev=[c['threshold_event'] for c in cc];rate=np.array([e['rate_nominal'] for e in ev]);lo=np.array([e['cp95_nominal'][0] for e in ev]);hi=np.array([e['cp95_nominal'][1] for e in ev]);elo=[e['sensitivity_envelope'][0] for e in ev];ehi=[e['sensitivity_envelope'][1] for e in ev]
  ax.vlines(xs,elo,ehi,color=colors[n],lw=5,alpha=.18)
  ax.errorbar(xs,rate,yerr=[rate-lo,hi-rate],fmt=markers[n],ms=4,capsize=2.5,lw=.9,color=colors[n],label=nlabel(n))
  for c in cc:point_log.append({'figure':3,'panel':'a','cell':c['cell'],'rows':400,'threshold':tau,'count':c['threshold_event']['k_nominal']})
 ax.legend(frameon=False,loc='upper left',fontsize=9);ax.set(xlabel=r'Local parameter $s$',ylabel='Exceedance rate',ylim=(-.03,1.03),title=r'(a) Threshold $n^{2/3}L_{\mathrm{PL}}>0.05$');ax.grid(alpha=.12)
 for k,ref in enumerate(data['limit_curves']['cdf']):
  ax=axes[k+1];s=ref['s'];chosen=[c for c in cells if c['s']==s];xmax=1.02*max([max(ref['x'])]+[max(c['primary']) for c in chosen]);xx=np.array(ref['x']);F=np.array(ref['F'])
  ax.plot(np.r_[0.,0.,xx,xmax],np.r_[0.,F[0],F,1.],color='black',lw=1.2,label='Limiting CDF')
  for c in chosen:
   vals=np.sort(c['primary']);assert len(vals)==400;u=np.unique(np.r_[0.,vals,xmax]);right=np.searchsorted(vals,u,side='right')/len(vals)
   # Compress repeated values without removing their mass; explicit zero jump.
   xp=np.r_[0.,u];yp=np.r_[0.,right];ax.step(xp,yp,where='post',lw=1.15,color=colors[c['n']],ls=styles[c['n']],label=nlabel(c['n']))
   point_log.append({'figure':3,'panel':'bc'[k],'cell':c['cell'],'rows':400,'zeros':int(np.sum(vals==0)),'CDF_at_zero':float(np.mean(vals==0)),'max_observed':float(vals.max()),'plotted_xmax':xmax})
  ax.set(xlabel=r'$n^{2/3}L_{\mathrm{PL}}$',ylabel='CDF',xlim=(0,xmax),ylim=(-.03,1.03),title=r'(%s) $s=%g$'%('bc'[k],s));ax.legend(frameon=False,loc='lower right',fontsize=9);ax.grid(alpha=.12)
 for ext in ['pdf','png']:
  p=out/f'display1_threshold_rate_and_cdf_portrait.{ext}';fig.savefig(p,dpi=220);figures.append(p)
 plt.close(fig)
 # The old four columns become four rows; comparator axis order is transposed.
 positive=[c for c in cells if c['s']>0];assert len(positive)==4
 fig,axes=plt.subplots(4,2,figsize=(5.15,6.5),layout='constrained')
 for j,c in enumerate(positive):
  y=np.asarray(c['primary']);assert len(y)==400
  for i,name in enumerate(['Psi_leading','L_Qtilde']):
   ax=axes[j,i];v=np.asarray(c['comparators'][name]);assert len(v)==400 and np.all(np.isfinite(v)) and np.all(np.isfinite(y))
   ax.plot(v,y,'.',ms=2.6,color=colors[c['n']],rasterized=False)
   top=float(np.max(np.r_[y,v,.05]))*1.03;ax.plot([0,top],[0,top],color='black',lw=.8)
   e=c['errors'][name]
   title=r'$n=10^{%d},\ s=%g$'%(int(np.log10(c['n'])),c['s'])
   title+='\nMAE %.3f; RMSE %.3f'%(e['mae'],e['rmse'])
   if j==0:title=('Tilt approximation' if i==0 else 'Full-Hessian approximation')+'\n'+title
   ax.set(xlim=(0,top),ylim=(0,top),title=title)
   ax.xaxis.set_major_locator(MaxNLocator(nbins=3));ax.yaxis.set_major_locator(MaxNLocator(nbins=3));ax.tick_params(labelsize=9)
   if i==0:ax.set_ylabel(r'$n^{2/3}L_{\mathrm{PL}}$',fontsize=9.5)
   if j==3:ax.set_xlabel(r'$\Psi_s(G_n)$' if i==0 else r'$L(\widetilde Q_n)$',fontsize=10)
   point_log.append({'figure':4,'old_row':i,'old_column':j,'new_row':j,'new_column':i,'cell':c['cell'],'n':c['n'],'s':c['s'],'comparator':name,'points':400,'primary_zeros':int(np.sum(y==0)),'comparator_zeros':int(np.sum(v==0)),'paired_zero_zero':int(np.sum((y==0)&(v==0))),'axis_upper':top,'mae':e['mae'],'rmse':e['rmse']})
 for ext in ['pdf','png']:
  p=out/f'display2_same_sample_errors_portrait.{ext}';fig.savefig(p,dpi=220);figures.append(p)
 plt.close(fig)
 (out/'PLOT_CHECK.json').write_text(json.dumps({'status':'PASS','scope':'Layout-only plotting of supplied saved values. No RNG/KDE/PH. All zero values and all400 paired observations retained. Plotting all points may overlap markers but does not remove rows.','input_sha256':sha(input_path),'script_sha256':sha(__file__),'font_sizes_pt':{'labels':9.5,'ticks':9,'legends':9,'statistics':10,'titles':10},'physical_size_inches':{'figure3':[5.15,6.0],'figure4':[5.15,6.5]},'panel_mapping':point_log,'outputs':[{'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in figures]},indent=2)+'\n')
 print('PASS portrait figures; all plotted values come from',input_path)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--input',type=Path,default=Path(__file__).resolve().parent/'plot_data.json');a.add_argument('--out-dir',type=Path,default=Path(__file__).resolve().parent);args=a.parse_args();main(args.input,args.out_dir)
