"""Export immutable saved numerical results and the original analytic curves.
No sampling, KDE, persistence computation or outcome-based row selection.
"""
from pathlib import Path
import argparse,hashlib,importlib.util,json,math
import numpy as np

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def finite(v):return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)
def primary(r):
 v=r.get('rescaled_L_primary');assert r['status']=='ok' and finite(v);return float(v)
def comparator(r,name):
 v=r[name];v=v['L'] if isinstance(v,dict) else v;assert finite(v);return float(v)
def main(run,code,out):
 run=Path(run).resolve();code=Path(code).resolve();out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True)
 target=out/'plot_data.json';assert not target.exists(), 'Do not overwrite exported plotting data'
 tablefile=run/'analysis/analysis_tables.json';tables=json.loads(tablefile.read_text())
 modelpath=code/'src/tda_numerics/model.py';spec=importlib.util.spec_from_file_location('original_analytic_model',modelpath)
 import sys
 module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
 model=module.Model(q=tables['q'],H=tables['H'])
 records=[];inputs=[]
 for p in sorted((run/'blocks').glob('*.json')):
  b=json.loads(p.read_text());inputs.append({'role':'saved_row_block','path':'run/blocks/'+p.name,'bytes':p.stat().st_size,'sha256':sha(p)})
  records.extend(b['rows'])
 assert len(records)==3200 and len({(r['cell'],r['rep']) for r in records})==3200
 checks=[];cells=[]
 for c in tables['cells']:
  rr=sorted([r for r in records if r['cell']==c['cell']],key=lambda r:r['rep']);assert len(rr)==c['planned']==400
  assert [r['rep'] for r in rr]==list(range(400));assert all(r['n']==c['n'] and r['s']==c['s'] for r in rr)
  y=np.array([primary(r) for r in rr]);assert np.all(y>=0)
  event=c['threshold_events']['0.05'];assert int(np.sum(y>.05))==event['k_nominal'];assert int(np.sum(y==0))==c['zero_atom']['k_zero']
  assert len(y)==event['m_with_value']==c['with_primary_value'];assert float(np.mean(y>.05))==event['rate_nominal']
  assert abs(model.limit_tail(c['s'],.05)-event['limit'])<1e-14
  comp={};errors={}
  for name in ['Psi_leading','L_Qtilde']:
   v=np.array([comparator(r,name) for r in rr]);e=c['same_sample_errors'][name];assert len(v)==e['m_used']==e['m_planned']==400
   mae=float(np.mean(np.abs(y-v)));rmse=float(np.sqrt(np.mean((y-v)**2)))
   assert abs(mae-e['mae'])<1e-13 and abs(rmse-e['rmse'])<1e-13
   comp[name]=v.tolist();errors[name]={'m_used':e['m_used'],'m_planned':e['m_planned'],'mae':e['mae'],'rmse':e['rmse']}
  cells.append({'cell':c['cell'],'n':c['n'],'s':c['s'],'planned':c['planned'],'rep':list(range(400)),'primary':y.tolist(),'primary_zero_count':int(np.sum(y==0)),'threshold_event':event,'comparators':comp,'errors':errors})
  checks.append({'cell':c['cell'],'n':c['n'],'s':c['s'],'rows':len(rr),'zeros_retained':int(np.sum(y==0)),'main_threshold_count':int(np.sum(y>.05)),'paired_each_comparator':400,'mae_rmse_match_saved_tables':True})
 sv=np.linspace(min(c['s'] for c in cells)-.2,max(c['s'] for c in cells)+.5,400)
 curves={'threshold':{'s':sv.tolist(),'rate':[model.limit_tail(float(s),.05) for s in sv]},'cdf':[]}
 for s in sorted({c['s'] for c in cells if c['s']>0}):
  x,F=model.limit_cdf_curve(s);curves['cdf'].append({'s':s,'x':x.tolist(),'F':F.tolist()})
 for p,role,logical in [(tablefile,'saved_analysis_table','run/analysis/analysis_tables.json'),(run/'analysis/analysis_summary.json','saved_analysis_binding','run/analysis/analysis_summary.json'),(modelpath,'original_analytic_curves','code/src/tda_numerics/model.py'),(code/'scripts/analyze_candidate.py','original_plot_function','code/scripts/analyze_candidate.py')]:
  inputs.append({'role':role,'path':logical,'bytes':p.stat().st_size,'sha256':sha(p)})
 for name in ['display1_threshold_rate_and_cdf.png','display2_same_sample_errors.png']:
  p=run/'analysis'/name;inputs.append({'role':'original_figure','path':'run/analysis/'+name,'bytes':p.stat().st_size,'sha256':sha(p)})
 data={'schema':'jact_portrait_plot_data_v1','attribution':'Original saved numerical results and analytic curves; portrait plot export dated 2026-11-11.','q':tables['q'],'H':tables['H'],'main_tau':tables['main_tau'],'primary_statistic':'rescaled_L_primary, including every saved zero; no changes to noise-floor convention','cells':cells,'limit_curves':curves}
 target.write_text(json.dumps(data,separators=(',',':'))+'\n')
 (out/'INPUTS.json').write_text(json.dumps({'source_run':str(run),'source_code':str(code),'files':inputs},indent=2)+'\n')
 (out/'DATA_CHECK.json').write_text(json.dumps({'status':'PASS','operations':'Read saved3200rows, check identities/counts/zero counts and saved MAE/RMSE; evaluate only original deterministic analytic plot curves. No RNG, KDE, PH, fitting or simulation.','all_rows':3200,'unique_cell_rep_identities':3200,'cells':checks,'plot_data_sha256':sha(target),'display1':'8 threshold points +4 empirical CDFs,400 observations each; analytic curves same original function/sampling grid.','display2':'4 positive-s cells ×2 comparators,400 points in each panel including all zero-valued pairs; original columns become rows.','export_script_sha256':sha(__file__)},indent=2)+'\n')
 print('PASS exported',target,'3200rows; no filtering')
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--run-dir',required=True);a.add_argument('--code-dir',required=True);a.add_argument('--out-dir',required=True);args=a.parse_args();main(args.run_dir,args.code_dir,args.out_dir)
