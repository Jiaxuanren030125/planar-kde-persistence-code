"""Verify distributed file hashes, without running any experiment."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[1]
m=json.loads((R/'FILE_MANIFEST.json').read_text())['files']
for name,v in m.items():
    raw=(R/name).read_bytes()
    if len(raw)!=v['bytes'] or hashlib.sha256(raw).hexdigest()!=v['sha256']:raise ValueError('Mismatch: '+name)
print('PASS:',len(m),'distributed files verified; no scientific computation.')
