"""Saved-data functions from the frozen angular analysis.
Only record analysis and analytic plotting; no RNG, KDE or PH.
"""
from pathlib import Path
from fractions import Fraction as Q
import csv
import json
import math
import os
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'experiments/angular_design/frozen_code'))
FIXTURE='NONSCIENTIFIC_FIXTURE'
def need(ok,message):
    if not ok: raise ValueError(message)
def design():
    return json.loads((Path(__file__).resolve().parents[1]/'experiments/angular_design/frozen_reference/provenance/DESIGN_CANDIDATE.json').read_text())


def counts(rows, summary):
    d = design()
    tables = []
    for cell in d['pilot_cells']:
        subset = [r for r in rows if r['identity']['cell'] == cell['cell']]
        m, ms = len(subset), d['regimes'][cell['regime']]['max_limit_length']
        for relative in (Q(1, 10), Q(1, 4), Q(1, 2)):
            tau = relative * Q.from_float(ms)
            k = sum(Q.from_float(float(r['Ynum'])) > tau for r in subset)
            missing = sum(r['E_T_upper'] is None for r in subset)
            ambiguous = sum(Q.from_float(float(r['Ynum'])) - Q.from_float(float(r['E_T_upper'])) <= tau
                            < Q.from_float(float(r['Ynum'])) + Q.from_float(float(r['E_T_upper']))
                            for r in subset if r['E_T_upper'] is not None)
            tables.append(dict(cell=cell['cell'], angular_law=cell['angular_law'], n=cell['n'], regime=cell['regime'],
                               threshold_relative=str(relative), threshold=float(tau), planned=200, completed=m,
                               unknown=200-m, exceeded=k, planned_proportion_low=k/200,
                               planned_proportion_high=(k+200-m)/200, interpolation_only_ambiguous=ambiguous,
                               completed_budget_missing=missing, cp95_low=None, cp95_high=None,
                               cp_status='NOT_APPLICABLE_INCOMPLETE' if m != 200 else 'NOT_COMPUTED',
                               curve_label=('COMPLETE 200/200' if m == 200 else 'CONDITIONAL %d/200' % m)))
    return tables

def csv_write(path, records, fields):
    with Path(path).open('x', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader(); writer.writerows(records)

def cp95_for_count(k, m):
    """Production CP95; task86 also checks this same function with hand counts."""
    need(type(k) is int and type(m) is int and 0 <= k <= m <= 200, 'INVALID_CP_COUNTS')
    if m != 200:
        return dict(cp95_low=None, cp95_high=None, cp_status='NOT_APPLICABLE_INCOMPLETE')
    from scipy.stats import beta
    return dict(cp95_low=0.0 if k == 0 else float(beta.ppf(.025, k, 201-k)),
                cp95_high=1.0 if k == 200 else float(beta.ppf(.975, k+1, 200-k)),
                cp_status='NOMINAL_DESCRIPTIVE_CP95')

def make_plot(rows, summary, out):
    """Original production 2x2 plot; hand smoke uses this exact code, visibly marked."""
    need(all(r['E_T_upper'] is not None for r in rows), 'MISSING_BUDGET_FOR_PUBLIC_XLIMIT')
    os.environ['MPLCONFIGDIR'] = str(ROOT / 'runtime_cache/matplotlib')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    from tda_numerics.model import psi_ray
    d = design()
    fig, axes = plt.subplots(2, 2, figsize=(10, 7.8), sharex='row', sharey=True)
    curves = []
    for regime in (0, 1):
        ms = d['regimes'][regime]['max_limit_length']
        selected = [r for r in rows if d['pilot_cells'][r['identity']['cell']]['regime'] == regime]
        xmax = max([1.05] + [(r['Ynum'] + r['E_T_upper']) / ms for r in selected])
        U = d['constants']['a'] * d['regimes'][regime]['s']
        b, sigma2 = d['constants']['b'], d['constants']['sigma2']
        tc = 4 * U**1.5 / (3 * math.sqrt(6*b))
        ts = np.linspace(tc, 0., 1001)
        axx = [psi_ray(U, b, float(t))/ms for t in ts]
        cdf = [math.exp(-float(t)**2/(2*sigma2)) for t in ts]
        axx[0], axx[-1], cdf[0], cdf[-1] = 0., 1., 1-d['regimes'][regime]['target_limit_occurrence'], 1.
        for col, n in enumerate((10000, 100000)):
            ax = axes[regime, col]
            for law in ('circle', 'regular6', 'regular8'):
                group = [r for r in rows if d['pilot_cells'][r['identity']['cell']]['regime'] == regime
                         and d['pilot_cells'][r['identity']['cell']]['n'] == n
                         and d['pilot_cells'][r['identity']['cell']]['angular_law'] == law]
                vals = sorted(r['Ynum']/ms for r in group)
                m = len(vals)
                label = law + (' 200/200' if m == 200 else ' CONDITIONAL %d/200' % m)
                if m:
                    xx = [0.] + vals + [xmax]
                    yy = [0.] + [(i+1)/m for i in range(m)] + [1.]
                    ax.step(xx, yy, where='post', linewidth=1.2, label=label)
                    curves.extend(dict(regime=regime, n=n, series=law, x=x, cdf=y, completed=m, planned=200,
                                       conditional=m != 200) for x, y in zip(xx, yy))
                else:
                    ax.plot([], [], label=label + ' (no curve)')
            ax.plot(axx + [xmax], cdf + [1.], color='black', linewidth=1.4, label='Common analytic CDF')
            ax.vlines(0, 0, cdf[0], color='black', linewidth=1.4)
            curves.extend(dict(regime=regime, n=n, series='analytic', x=x, cdf=y, completed='', planned='', conditional=False)
                          for x, y in zip(axx + [xmax], cdf + [1.]))
            ax.set(xlim=(0, xmax), ylim=(0, 1.02), title='regime %d, n=%d' % (regime, n), xlabel='Ynum / Ms', ylabel='CDF')
            ax.legend(fontsize=7)
    label = 'COMPLETE' if summary['all_rows_ready'] else 'PENDING - incomplete cells show conditional m/200 ECDFs'
    if summary['mode'] == FIXTURE:
        label = 'NONSCIENTIFIC_SMOKE - hand values only\n' + label
    fig.suptitle(label, fontsize=10)
    fig.text(.02, .01, 'NUMERIC_SCOPE_LIMITED. Ynum=n^(2/3) raw longest positive mode6 PL bar. PL zero is not a continuous-plane absence.\n'
             'All values, including >1, retained. Row xmax=max(1.05, max((Ynum+E_T)/Ms)); E_T is interpolation only.', fontsize=7)
    fig.tight_layout(rect=(0, .055, 1, .96))
    fig.savefig(out / 'angular_display.pdf')
    fig.savefig(out / 'angular_display.svg')
    plt.close(fig)
    csv_write(out / 'curves.csv', curves, ['regime', 'n', 'series', 'x', 'cdf', 'completed', 'planned', 'conditional'])
