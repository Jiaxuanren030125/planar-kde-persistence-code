"""Extract original JSON records to a new directory; verify paths and member hashes.
"""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,zipfile,shutil
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--experiment',choices=['gaussian_difference','angular_design'],required=True)
p.add_argument('--output',required=True,type=Path)
a=p.parse_args()
if a.output.exists():p.error('Output directory must be new')
with zipfile.ZipFile(ROOT/'data'/(a.experiment+'_records.zip')) as z:
    manifest=json.loads(z.read('MEMBER_MANIFEST.json'))['files']
    for name,meta in manifest.items():
        parts=PurePosixPath(name)
        if parts.is_absolute() or '..' in parts.parts:raise ValueError('Unsafe member')
        raw=z.read(name)
        if len(raw)!=meta['bytes'] or hashlib.sha256(raw).hexdigest()!=meta['sha256']:raise ValueError('Member mismatch')
        f=a.output/parts;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw)
if a.experiment=='gaussian_difference':
    dst=a.output/'analysis';dst.mkdir(parents=True,exist_ok=True)
    for name in ['analysis_tables.json','analysis_summary.json','display1_threshold_rate_and_cdf.png','display2_same_sample_errors.png']:
        shutil.copyfile(ROOT/'experiments/gaussian_difference/saved_analysis'/name,dst/name)
print('Extracted',len(manifest),'JSON records. Raw NPZ arrays are not included.')
